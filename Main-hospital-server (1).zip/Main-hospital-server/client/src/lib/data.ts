import { format } from "date-fns";

// Get formatted time (HH:MM AM/PM) from time object
export function formatTime(time: { hours: number; minutes: number }): string {
  const date = new Date();
  date.setHours(time.hours);
  date.setMinutes(time.minutes);
  return format(date, "h:mm a");
}

// Convert Date object to time object
export function dateToTimeObject(date: Date): { hours: number; minutes: number } {
  return {
    hours: date.getHours(),
    minutes: date.getMinutes()
  };
}

// Get status color class
export function getStatusColorClass(status: string): string {
  const statusMap: Record<string, string> = {
    // Patient statuses
    critical: "bg-win-red bg-opacity-10 text-win-red",
    stable: "bg-win-green bg-opacity-10 text-win-green",
    observation: "bg-win-orange bg-opacity-10 text-win-orange",
    treatment: "bg-win-blue bg-opacity-10 text-win-blue",
    discharged: "bg-win-gray-300 bg-opacity-40 text-win-gray-500",
    
    // Appointment statuses
    confirmed: "bg-win-green bg-opacity-10 text-win-green",
    cancelled: "bg-win-red bg-opacity-10 text-win-red",
    waiting: "bg-win-orange bg-opacity-10 text-win-orange",
    "in progress": "bg-win-blue bg-opacity-10 text-win-blue",
    completed: "bg-win-gray-300 bg-opacity-40 text-win-gray-500",
    
    // Department statuses
    "high load": "bg-win-red bg-opacity-10 text-win-red",
    moderate: "bg-win-orange bg-opacity-10 text-win-orange",
    normal: "bg-win-green bg-opacity-10 text-win-green",
    
    // Notification types
    alert: "bg-win-red bg-opacity-10 text-win-red",
    warning: "bg-win-orange bg-opacity-10 text-win-orange",
    info: "bg-win-blue bg-opacity-10 text-win-blue",
    success: "bg-win-green bg-opacity-10 text-win-green",
  };
  
  return statusMap[status.toLowerCase()] || "bg-win-gray-300 bg-opacity-40 text-win-gray-500";
}

export function getNotificationIcon(type: string): string {
  const iconMap: Record<string, string> = {
    alert: "fas fa-exclamation-circle",
    warning: "fas fa-pills",
    info: "fas fa-calendar-alt",
    success: "fas fa-user-plus",
  };
  
  return iconMap[type.toLowerCase()] || "fas fa-clipboard-check";
}

export function getInitials(firstName: string, lastName: string): string {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`;
}

export function formatDate(date: Date): string {
  return format(new Date(date), "MM/dd/yyyy");
}

export function formatRelativeTime(date: Date): string {
  const now = new Date();
  const diffInMinutes = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60));
  
  if (diffInMinutes < 1) {
    return "just now";
  } else if (diffInMinutes < 60) {
    return `${diffInMinutes} ${diffInMinutes === 1 ? "minute" : "minutes"} ago`;
  } else if (diffInMinutes < 1440) {
    const hours = Math.floor(diffInMinutes / 60);
    return `${hours} ${hours === 1 ? "hour" : "hours"} ago`;
  } else {
    const days = Math.floor(diffInMinutes / 1440);
    return `${days} ${days === 1 ? "day" : "days"} ago`;
  }
}

// Get day name from date
export function getDayName(date: Date): string {
  return format(new Date(date), "EEEE");
}

// Get month name from date
export function getMonthName(date: Date): string {
  return format(new Date(date), "MMMM");
}

// Get formatted date (Month day, year) from date
export function getFormattedDate(date: Date): string {
  return format(new Date(date), "MMMM d, yyyy");
}
