import { ReactNode } from "react";
import { User, Patient, Appointment, Inventory, Department, Notification } from "@shared/schema";

export interface WindowProps {
  id: string;
  title: string;
  icon: string;
  isOpen: boolean;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
  width?: string;
  height?: string;
  x?: number;
  y?: number;
  children: ReactNode;
  onClose: () => void;
  onMinimize: () => void;
  onMaximize: () => void;
  onFocus: () => void;
}

export interface DesktopIconProps {
  id: string;
  icon: string;
  label: string;
  bgColor: string;
  onClick: () => void;
}

export interface StatsCardProps {
  icon: string;
  iconBgColor: string;
  title: string;
  value: string;
  trend: {
    value: string;
    isPositive: boolean;
  };
  subtext: string;
}

export interface StatusBadgeProps {
  status: string;
}

export interface TimeFormatted {
  hours: number;
  minutes: number;
}

export interface AppointmentWithNames extends Appointment {
  patientName?: string;
  doctorName?: string;
}

export interface PatientWithDoctor extends Patient {
  doctorName?: string;
}

export interface UserWithRole extends User {
  roleName?: string;
}

export interface WindowContextType {
  windows: WindowState[];
  activeWindowId: string | null;
  openWindow: (id: string) => void;
  closeWindow: (id: string) => void;
  minimizeWindow: (id: string) => void;
  maximizeWindow: (id: string) => void;
  focusWindow: (id: string) => void;
  addWindowIfNotExists: (id: WindowComponents) => boolean;
  desktopIcons: WindowComponents[];
  setDesktopIcons: React.Dispatch<React.SetStateAction<WindowComponents[]>>;
}

export interface WindowState {
  id: string;
  title: string;
  icon: string;
  component: ReactNode;
  isOpen: boolean;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
  width?: string;
  height?: string;
  x?: number;
  y?: number;
}

export interface TaskbarItemProps {
  id: string;
  icon: string;
  label: string;
  isActive: boolean;
  bgColor: string;
  onClick: () => void;
}

export interface StartMenuItemProps {
  icon: string;
  label: string;
  bgColor: string;
  onClick: () => void;
}

export interface DepartmentStatusProps {
  name: string;
  status: string;
  currentLoad: number;
  capacity: number;
  numDoctors: number;
  numNurses: number;
}

export interface NotificationItemProps {
  id: number;
  title: string;
  message: string;
  type: string;
  timestamp: Date;
  isRead: boolean;
  onRead: (id: number) => void;
}

export type WindowComponents = 
  | "dashboard" 
  | "patients" 
  | "appointments" 
  | "staff" 
  | "inventory" 
  | "reports"
  | "terminal"
  | "settings"
  | "adminpanel"
  | "taskmanager"
  | "emergency"
  | "lab"
  | "patientform"
  | "files";
  
export interface TerminalCommandProps {
  command: string;
  output: string;
  isError?: boolean;
}

export interface TerminalLoginState {
  isLoggedIn: boolean;
  username: string;
  password: string;
  attempts: number;
  showLoginError: boolean;
}

export interface PasswordEntry {
  id: string;
  name: string;
  password: string;
  description: string;
}

export interface DevicePreference {
  selectedDevice: 'mobile' | 'laptop';
}
