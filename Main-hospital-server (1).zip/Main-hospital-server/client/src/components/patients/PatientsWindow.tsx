import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Patient, User } from '@shared/schema';
import { getStatusColorClass, formatDate } from '@/lib/data';
import PatientForm from './PatientForm';

export default function PatientsWindow() {
  const queryClient = useQueryClient();
  const [isAddingPatient, setIsAddingPatient] = useState(false);
  const [currentPatient, setCurrentPatient] = useState<Patient | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'all' | 'active' | 'discharged' | 'critical'>('all');

  // Fetch patients
  const { data: patients, isLoading } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });

  // Fetch doctors for assigned doctor dropdown
  const { data: doctors } = useQuery<User[]>({
    queryKey: ['/api/users'],
    select: (users) => users.filter(user => user.role === 'doctor'),
  });

  const deletePatientMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/patients/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients'] });
    }
  });

  const handleAddNew = () => {
    setCurrentPatient(null);
    setIsAddingPatient(true);
  };

  const handleEdit = (patient: Patient) => {
    setCurrentPatient(patient);
    setIsAddingPatient(true);
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this patient?')) {
      deletePatientMutation.mutate(id);
    }
  };

  const handleFormClose = () => {
    setIsAddingPatient(false);
    setCurrentPatient(null);
  };

  const handleFormSubmit = () => {
    setIsAddingPatient(false);
    setCurrentPatient(null);
    queryClient.invalidateQueries({ queryKey: ['/api/patients'] });
  };

  // Filter patients based on search and view mode
  const filteredPatients = patients?.filter(patient => {
    const matchesSearch = 
      searchTerm === '' || 
      patient.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.patientId.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!matchesSearch) return false;
    
    switch (viewMode) {
      case 'active':
        return patient.status === 'active' || patient.status === 'stable' || patient.status === 'treatment';
      case 'discharged':
        return patient.status === 'discharged';
      case 'critical':
        return patient.status === 'critical';
      default:
        return true;
    }
  }) || [];

  // Find doctor names for each patient
  const patientsWithDoctors = filteredPatients.map(patient => {
    const doctor = doctors?.find(d => d.id === patient.assignedDoctorId);
    return {
      ...patient,
      doctorName: doctor ? doctor.name : 'Not Assigned'
    };
  });

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <div className="w-56 bg-win-gray-100 border-r border-win-gray-300 p-2">
        <div className="mb-6">
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">PATIENT MANAGEMENT</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={() => setViewMode('all')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${viewMode === 'all' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-users w-5"></i>
                <span>All Patients</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setViewMode('active')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${viewMode === 'active' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-bed w-5"></i>
                <span>Active Patients</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setViewMode('critical')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${viewMode === 'critical' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-heartbeat w-5"></i>
                <span>Critical Patients</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setViewMode('discharged')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${viewMode === 'discharged' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-hospital-user w-5"></i>
                <span>Discharged Patients</span>
              </button>
            </li>
          </ul>
        </div>
        
        <div>
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">TOOLS</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={handleAddNew} 
                className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200"
              >
                <i className="fas fa-user-plus w-5"></i>
                <span>Add New Patient</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-file-export w-5"></i>
                <span>Export Patient List</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-chart-pie w-5"></i>
                <span>Patient Statistics</span>
              </button>
            </li>
          </ul>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 p-4 overflow-auto scrollbar">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold mb-1">Patient Records</h1>
            <p className="text-win-gray-500">Manage patient information, medical history, and status</p>
          </div>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search patients..." 
              className="pl-10 pr-4 py-2 rounded border border-win-gray-300 focus:outline-none focus:border-win-blue focus:ring-1 focus:ring-win-blue w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-win-gray-500"></i>
          </div>
        </div>
        
        {/* Patient List */}
        <div className="bg-white rounded shadow-sm border border-win-gray-200">
          <div className="px-4 py-3 border-b border-win-gray-200 flex justify-between items-center">
            <h2 className="font-semibold">
              {viewMode === 'all' ? 'All Patients' : 
               viewMode === 'active' ? 'Active Patients' : 
               viewMode === 'critical' ? 'Critical Patients' : 
               'Discharged Patients'}
            </h2>
            <div className="flex space-x-2">
              <button 
                onClick={handleAddNew}
                className="px-3 py-1 text-sm rounded bg-win-blue text-white"
              >
                <i className="fas fa-plus mr-1"></i> Add New
              </button>
              <button className="px-3 py-1 text-sm rounded border border-win-gray-300 hover:bg-win-gray-100">
                <i className="fas fa-filter"></i>
              </button>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-win-blue"></div>
            </div>
          ) : patientsWithDoctors.length === 0 ? (
            <p className="text-center py-8 text-win-gray-500">No patients found</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="text-left text-sm text-win-gray-500 border-b border-win-gray-200">
                    <th className="px-4 py-3 font-medium">Patient ID</th>
                    <th className="px-4 py-3 font-medium">Name</th>
                    <th className="px-4 py-3 font-medium">Gender</th>
                    <th className="px-4 py-3 font-medium">Date of Birth</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                    <th className="px-4 py-3 font-medium">Room</th>
                    <th className="px-4 py-3 font-medium">Doctor</th>
                    <th className="px-4 py-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {patientsWithDoctors.map(patient => (
                    <tr key={patient.id} className="border-b border-win-gray-200 hover:bg-win-gray-50 text-sm">
                      <td className="px-4 py-3">{patient.patientId}</td>
                      <td className="px-4 py-3">{patient.firstName} {patient.lastName}</td>
                      <td className="px-4 py-3">{patient.gender}</td>
                      <td className="px-4 py-3">{formatDate(new Date(patient.dateOfBirth))}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs ${getStatusColorClass(patient.status)}`}>
                          {patient.status.charAt(0).toUpperCase() + patient.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-4 py-3">{patient.roomNumber || 'N/A'}</td>
                      <td className="px-4 py-3">{patient.doctorName}</td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => handleEdit(patient)} 
                            className="text-win-blue hover:underline"
                          >
                            <i className="fas fa-edit"></i>
                          </button>
                          <button 
                            onClick={() => handleDelete(patient.id)} 
                            className="text-win-red hover:underline"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      
      {/* Patient Form Modal */}
      {isAddingPatient && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-md w-[800px] max-h-[90vh] overflow-auto">
            <PatientForm 
              patient={currentPatient}
              doctors={doctors || []}
              onClose={handleFormClose}
              onSubmit={handleFormSubmit}
            />
          </div>
        </div>
      )}
    </div>
  );
}
