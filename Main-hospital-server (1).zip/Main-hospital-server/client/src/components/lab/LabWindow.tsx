import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Patient, Inventory } from '@shared/schema';

interface LabTest {
  id: string;
  patientId: number;
  patientName: string;
  testType: string;
  orderDate: string;
  status: 'Pending' | 'In Progress' | 'Completed';
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  results?: string;
  resultDate?: string;
  technician?: string;
}

export default function LabWindow() {
  const [activeTab, setActiveTab] = useState<'tests' | 'results' | 'equipment'>('tests');
  const [selectedTest, setSelectedTest] = useState<LabTest | null>(null);
  const [testViewOpen, setTestViewOpen] = useState(false);
  
  const { data: patients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });
  
  const { data: inventory } = useQuery<Inventory[]>({
    queryKey: ['/api/inventory'],
  });
  
  // Filter inventory to get only lab equipment
  const labEquipment = inventory?.filter(item => 
    item.category === 'equipment' && 
    (item.itemName.toLowerCase().includes('lab') || 
     item.itemName.toLowerCase().includes('test') ||
     item.itemName.toLowerCase().includes('analyzer'))
  ) || [];
  
  // Lab Tests Data (Mocked for now)
  const labTests: LabTest[] = [
    {
      id: 'LT-1001',
      patientId: 1,
      patientName: 'John Smith',
      testType: 'Complete Blood Count (CBC)',
      orderDate: '2025-03-26',
      status: 'Completed',
      priority: 'Medium',
      results: 'WBC: 7.2 K/uL, RBC: 4.8 M/uL, Hemoglobin: 14.2 g/dL, Hematocrit: 42%',
      resultDate: '2025-03-27',
      technician: 'Dr. Karen Wu'
    },
    {
      id: 'LT-1002',
      patientId: 2,
      patientName: 'Sarah Johnson',
      testType: 'Comprehensive Metabolic Panel',
      orderDate: '2025-03-26',
      status: 'In Progress',
      priority: 'Medium'
    },
    {
      id: 'LT-1003',
      patientId: 3,
      patientName: 'Michael Brown',
      testType: 'Lipid Panel',
      orderDate: '2025-03-25',
      status: 'Completed',
      priority: 'Low',
      results: 'Total Cholesterol: 195 mg/dL, HDL: 55 mg/dL, LDL: 120 mg/dL, Triglycerides: 150 mg/dL',
      resultDate: '2025-03-26',
      technician: 'Dr. James Wilson'
    },
    {
      id: 'LT-1004',
      patientId: 4,
      patientName: 'Emily Davis',
      testType: 'COVID-19 PCR Test',
      orderDate: '2025-03-27',
      status: 'Pending',
      priority: 'High'
    },
    {
      id: 'LT-1005',
      patientId: 5,
      patientName: 'Robert Wilson',
      testType: 'Thyroid Function Panel',
      orderDate: '2025-03-24',
      status: 'Completed',
      priority: 'Medium',
      results: 'TSH: 2.1 mIU/L, T4: 8.2 ug/dL, T3: 120 ng/dL',
      resultDate: '2025-03-26',
      technician: 'Dr. Lisa Chen'
    },
    {
      id: 'LT-1006',
      patientId: 1,
      patientName: 'John Smith',
      testType: 'Urinalysis',
      orderDate: '2025-03-26',
      status: 'Pending',
      priority: 'Urgent'
    }
  ];
  
  // Get status color class
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed': return 'bg-green-100 text-green-800';
      case 'In Progress': return 'bg-blue-100 text-blue-800';
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Get priority color class
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Urgent': return 'bg-red-100 text-red-800';
      case 'High': return 'bg-orange-100 text-orange-800';
      case 'Medium': return 'bg-blue-100 text-blue-800';
      case 'Low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Filter tests based on tab
  const filteredTests = activeTab === 'results' 
    ? labTests.filter(test => test.status === 'Completed')
    : labTests;
  
  // View test details
  const viewTestDetails = (test: LabTest) => {
    setSelectedTest(test);
    setTestViewOpen(true);
  };
  
  return (
    <div className="h-full flex flex-col bg-white overflow-hidden">
      {/* Lab Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-3 flex items-center justify-between">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center mr-3">
            <i className="fas fa-microscope text-blue-600 text-xl"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Laboratory Information System</h1>
            <p className="text-white text-opacity-80 text-sm">Test Management & Results</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button className="bg-white text-blue-600 px-4 py-2 rounded-md font-medium flex items-center">
            <i className="fas fa-plus mr-2"></i>
            New Test
          </button>
          <button className="bg-white bg-opacity-20 text-white px-4 py-2 rounded-md font-medium flex items-center">
            <i className="fas fa-print mr-2"></i>
            Print
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-blue-800 text-white p-1 flex border-b border-blue-900">
        <button 
          className={`px-4 py-2 font-medium rounded-t ${activeTab === 'tests' ? 'bg-white text-blue-800' : 'hover:bg-blue-700'}`}
          onClick={() => setActiveTab('tests')}
        >
          <i className="fas fa-vial mr-2"></i>Tests
        </button>
        <button 
          className={`px-4 py-2 font-medium rounded-t ${activeTab === 'results' ? 'bg-white text-blue-800' : 'hover:bg-blue-700'}`}
          onClick={() => setActiveTab('results')}
        >
          <i className="fas fa-clipboard-list mr-2"></i>Results
        </button>
        <button 
          className={`px-4 py-2 font-medium rounded-t ${activeTab === 'equipment' ? 'bg-white text-blue-800' : 'hover:bg-blue-700'}`}
          onClick={() => setActiveTab('equipment')}
        >
          <i className="fas fa-tools mr-2"></i>Equipment
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto p-4">
        {(activeTab === 'tests' || activeTab === 'results') && (
          <div>
            {/* Search and Filters */}
            <div className="flex justify-between items-center mb-4">
              <div className="relative w-64">
                <input 
                  type="text" 
                  placeholder="Search tests..."
                  className="w-full pl-10 pr-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <div className="absolute left-3 top-2.5 text-gray-400">
                  <i className="fas fa-search"></i>
                </div>
              </div>
              <div className="flex space-x-2">
                <select className="rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option>All Priorities</option>
                  <option>Urgent</option>
                  <option>High</option>
                  <option>Medium</option>
                  <option>Low</option>
                </select>
                <select className="rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option>All Statuses</option>
                  <option>Pending</option>
                  <option>In Progress</option>
                  <option>Completed</option>
                </select>
              </div>
            </div>
            
            {/* Tests Table */}
            <div className="bg-white shadow rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Test ID
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Patient
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Test Type
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Order Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Priority
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredTests.map((test) => (
                    <tr key={test.id} className="hover:bg-gray-50 cursor-pointer" onClick={() => viewTestDetails(test)}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-blue-600">{test.id}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>{test.patientName}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div>{test.testType}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>{test.orderDate}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(test.status)}`}>
                          {test.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(test.priority)}`}>
                          {test.priority}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button 
                            className="text-blue-600 hover:text-blue-900"
                            onClick={(e) => {
                              e.stopPropagation();
                              viewTestDetails(test);
                            }}
                          >
                            <i className="fas fa-eye"></i>
                          </button>
                          <button 
                            className="text-gray-600 hover:text-gray-900"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <i className="fas fa-print"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {activeTab === 'equipment' && (
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-medium">Laboratory Equipment</h2>
              <button className="bg-blue-600 text-white px-4 py-2 rounded flex items-center">
                <i className="fas fa-plus mr-2"></i>
                New Equipment
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {labEquipment.map((item, index) => (
                <div key={index} className="bg-white shadow rounded-lg overflow-hidden border border-gray-200">
                  <div className="p-4">
                    <div className="flex items-center mb-3">
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                        <i className="fas fa-microscope text-blue-600"></i>
                      </div>
                      <div>
                        <h3 className="font-medium">{item.itemName}</h3>
                        <p className="text-sm text-gray-500">ID: {item.id}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Status:</span>
                        <span className="font-medium text-green-600">Operational</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Quantity:</span>
                        <span>{item.quantity}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Last Maintenance:</span>
                        <span>2025-03-15</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Next Maintenance:</span>
                        <span>2025-04-15</span>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex justify-between">
                      <button className="text-blue-600 text-sm font-medium hover:underline">
                        View Details
                      </button>
                      <button className="text-gray-600 text-sm font-medium hover:underline">
                        Schedule Maintenance
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Show a message if no equipment found */}
              {labEquipment.length === 0 && (
                <div className="col-span-3 text-center p-8 bg-gray-50 rounded-lg">
                  <div className="text-gray-400 text-5xl mb-3">
                    <i className="fas fa-microscope"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-600 mb-1">No Laboratory Equipment Found</h3>
                  <p className="text-gray-500">Add new equipment to manage and track your lab inventory.</p>
                  <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded inline-flex items-center">
                    <i className="fas fa-plus mr-2"></i>
                    Add Equipment
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
      
      {/* Test Details Modal */}
      {testViewOpen && selectedTest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-4/5 max-w-4xl max-h-[90vh] overflow-auto">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gradient-to-r from-blue-600 to-blue-800 text-white rounded-t-lg">
              <h2 className="text-xl font-bold">Test Details</h2>
              <button 
                className="text-white hover:text-gray-200"
                onClick={() => setTestViewOpen(false)}
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Test Information</h3>
                  <div className="space-y-3">
                    <div className="flex">
                      <span className="font-medium w-32">Test ID:</span>
                      <span>{selectedTest.id}</span>
                    </div>
                    <div className="flex">
                      <span className="font-medium w-32">Test Type:</span>
                      <span>{selectedTest.testType}</span>
                    </div>
                    <div className="flex">
                      <span className="font-medium w-32">Order Date:</span>
                      <span>{selectedTest.orderDate}</span>
                    </div>
                    <div className="flex">
                      <span className="font-medium w-32">Status:</span>
                      <span className={`px-2 py-1 text-xs leading-5 font-semibold rounded-full ${getStatusColor(selectedTest.status)}`}>
                        {selectedTest.status}
                      </span>
                    </div>
                    <div className="flex">
                      <span className="font-medium w-32">Priority:</span>
                      <span className={`px-2 py-1 text-xs leading-5 font-semibold rounded-full ${getPriorityColor(selectedTest.priority)}`}>
                        {selectedTest.priority}
                      </span>
                    </div>
                    {selectedTest.technician && (
                      <div className="flex">
                        <span className="font-medium w-32">Technician:</span>
                        <span>{selectedTest.technician}</span>
                      </div>
                    )}
                    {selectedTest.resultDate && (
                      <div className="flex">
                        <span className="font-medium w-32">Result Date:</span>
                        <span>{selectedTest.resultDate}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Patient Information</h3>
                  <div className="space-y-3">
                    <div className="flex">
                      <span className="font-medium w-32">Patient ID:</span>
                      <span>{selectedTest.patientId}</span>
                    </div>
                    <div className="flex">
                      <span className="font-medium w-32">Patient Name:</span>
                      <span>{selectedTest.patientName}</span>
                    </div>
                    <div className="flex">
                      <span className="font-medium w-32">Age:</span>
                      <span>48</span>
                    </div>
                    <div className="flex">
                      <span className="font-medium w-32">Gender:</span>
                      <span>Male</span>
                    </div>
                    <div className="flex">
                      <span className="font-medium w-32">Room:</span>
                      <span>203</span>
                    </div>
                    <div className="flex">
                      <span className="font-medium w-32">Attending:</span>
                      <span>Dr. Lisa Chen</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {selectedTest.results && (
                <div className="mt-6">
                  <h3 className="text-lg font-medium mb-4">Test Results</h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <pre className="whitespace-pre-wrap">{selectedTest.results}</pre>
                  </div>
                </div>
              )}
              
              {!selectedTest.results && selectedTest.status !== 'Completed' && (
                <div className="mt-6">
                  <h3 className="text-lg font-medium mb-4">Add Test Results</h3>
                  
                  {selectedTest.status === 'Pending' ? (
                    <div className="text-center p-8 bg-yellow-50 rounded-lg">
                      <div className="text-yellow-400 text-3xl mb-3">
                        <i className="fas fa-exclamation-triangle"></i>
                      </div>
                      <h3 className="text-lg font-medium text-yellow-800 mb-1">Test is Pending</h3>
                      <p className="text-yellow-700">This test needs to be started before results can be added.</p>
                      <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded inline-flex items-center">
                        <i className="fas fa-play mr-2"></i>
                        Start Test
                      </button>
                    </div>
                  ) : (
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <textarea 
                        placeholder="Enter test results here..."
                        className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[100px]"
                      ></textarea>
                      <div className="mt-4 flex justify-end">
                        <button className="bg-blue-600 text-white px-4 py-2 rounded flex items-center">
                          <i className="fas fa-save mr-2"></i>
                          Save Results
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
              
              <div className="mt-6 flex justify-end space-x-4">
                <button 
                  className="px-4 py-2 border border-gray-300 rounded text-gray-700 hover:bg-gray-50"
                  onClick={() => setTestViewOpen(false)}
                >
                  Close
                </button>
                <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                  <i className="fas fa-print mr-2"></i>
                  Print Report
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}