import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { Patient, Department } from '@shared/schema';

export default function EmergencyWindow() {
  const [activeTab, setActiveTab] = useState<'overview' | 'alerts' | 'resources'>('overview');
  const [emergencyLevel, setEmergencyLevel] = useState<'green' | 'yellow' | 'orange' | 'red'>('green');

  const { data: patients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });

  const { data: departments } = useQuery<Department[]>({
    queryKey: ['/api/departments'],
  });

  // ER Capacity Data
  const erDepartment = departments?.find(dept => dept.name === 'Emergency Room');
  const erCapacityData = {
    currentLoad: erDepartment?.currentLoad || 0,
    capacity: erDepartment?.capacity || 0,
    percentage: erDepartment ? Math.round((erDepartment.currentLoad / erDepartment.capacity) * 100) : 0
  };

  // Emergency Response Time Data
  const responseTimeData = [
    { name: 'Critical', time: 2.5 },
    { name: 'Urgent', time: 5.8 },
    { name: 'Standard', time: 12.3 },
    { name: 'Non-urgent', time: 25.1 }
  ];

  // Patient Triage Distribution
  const triageData = [
    { name: 'Critical (Red)', value: 3, color: '#FF0000' },
    { name: 'Urgent (Orange)', value: 7, color: '#FFA500' },
    { name: 'Standard (Yellow)', value: 12, color: '#FFFF00' },
    { name: 'Non-urgent (Green)', value: 8, color: '#008000' }
  ];

  // Emergency Team Status
  const teamStatusData = [
    { name: 'Doctors', available: 4, total: 6 },
    { name: 'Nurses', available: 8, total: 12 },
    { name: 'Paramedics', available: 3, total: 5 },
    { name: 'Ambulances', available: 2, total: 3 }
  ];

  // Recent Emergency Alerts
  const emergencyAlerts = [
    {
      id: 'EA001',
      timestamp: '10:45 AM',
      level: 'high',
      message: 'Code Blue - Cardiac Arrest in Room 203',
      status: 'active'
    },
    {
      id: 'EA002',
      timestamp: '09:30 AM',
      level: 'medium',
      message: 'Multiple Trauma Patients - ETA 5 minutes',
      status: 'handled'
    },
    {
      id: 'EA003',
      timestamp: '08:15 AM',
      level: 'medium',
      message: 'Shortage of O- Blood Type - Immediate Request Sent',
      status: 'active'
    },
    {
      id: 'EA004',
      timestamp: 'Yesterday',
      level: 'low',
      message: 'Power Outage - Backup Generators Active',
      status: 'resolved'
    }
  ];

  // Get alert level color
  const getAlertLevelColor = (level: string) => {
    switch (level) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-orange-500';
      case 'low': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  // Get alert status style
  const getAlertStatusStyle = (status: string) => {
    switch (status) {
      case 'active': return 'text-red-500 font-bold';
      case 'handled': return 'text-orange-500';
      case 'resolved': return 'text-green-500';
      default: return 'text-gray-500';
    }
  };

  return (
    <div className="h-full flex flex-col bg-white overflow-hidden">
      {/* Emergency Response Header */}
      <div className="bg-gradient-to-r from-red-600 to-red-800 p-3 flex items-center justify-between">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center mr-3">
            <i className="fas fa-ambulance text-red-600 text-xl"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Emergency Response System</h1>
            <p className="text-white text-opacity-80 text-sm">Live Status and Coordination</p>
          </div>
        </div>
        <div className="flex items-center bg-white bg-opacity-20 rounded-lg p-2">
          <div className="text-white mr-2">Emergency Level:</div>
          <select 
            value={emergencyLevel}
            onChange={(e) => setEmergencyLevel(e.target.value as any)}
            className="bg-transparent text-white font-bold border border-white border-opacity-50 rounded px-2 py-1"
          >
            <option value="green" className="text-black">GREEN (Normal)</option>
            <option value="yellow" className="text-black">YELLOW (Elevated)</option>
            <option value="orange" className="text-black">ORANGE (High)</option>
            <option value="red" className="text-black">RED (Critical)</option>
          </select>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-red-800 text-white p-1 flex border-b border-red-900">
        <button 
          className={`px-4 py-2 font-medium rounded-t ${activeTab === 'overview' ? 'bg-white text-red-800' : 'hover:bg-red-700'}`}
          onClick={() => setActiveTab('overview')}
        >
          <i className="fas fa-chart-pie mr-2"></i>Overview
        </button>
        <button 
          className={`px-4 py-2 font-medium rounded-t ${activeTab === 'alerts' ? 'bg-white text-red-800' : 'hover:bg-red-700'}`}
          onClick={() => setActiveTab('alerts')}
        >
          <i className="fas fa-bell mr-2"></i>Alerts
        </button>
        <button 
          className={`px-4 py-2 font-medium rounded-t ${activeTab === 'resources' ? 'bg-white text-red-800' : 'hover:bg-red-700'}`}
          onClick={() => setActiveTab('resources')}
        >
          <i className="fas fa-ambulance mr-2"></i>Resources
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto p-4">
        {activeTab === 'overview' && (
          <div className="grid grid-cols-2 gap-4">
            {/* ER Capacity */}
            <div className="bg-gray-50 rounded-lg p-4 shadow">
              <h2 className="text-lg font-medium mb-2 flex items-center">
                <i className="fas fa-hospital-alt text-red-600 mr-2"></i>
                ER Capacity
              </h2>
              <div className="flex items-center justify-center mb-2">
                <div className="w-32 h-32 rounded-full border-8 border-gray-200 flex items-center justify-center relative">
                  <div 
                    className="absolute inset-0 rounded-full"
                    style={{
                      background: `conic-gradient(
                        ${erCapacityData.percentage > 90 ? '#ef4444' : 
                          erCapacityData.percentage > 70 ? '#f97316' : 
                          erCapacityData.percentage > 50 ? '#eab308' : '#22c55e'} 
                        ${erCapacityData.percentage}%, 
                        #e5e7eb ${erCapacityData.percentage}% 100%
                      )`,
                      clipPath: 'circle(50% at center)'
                    }}
                  ></div>
                  <div className="bg-white rounded-full w-24 h-24 flex items-center justify-center z-10">
                    <div className="text-center">
                      <div className="text-2xl font-bold">
                        {erCapacityData.percentage}%
                      </div>
                      <div className="text-xs text-gray-500">Occupied</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-center">
                <p className="font-medium">{erCapacityData.currentLoad} / {erCapacityData.capacity} beds in use</p>
                <p className={`text-sm font-medium ${
                  erCapacityData.percentage > 90 ? 'text-red-600' : 
                  erCapacityData.percentage > 70 ? 'text-orange-500' : 
                  erCapacityData.percentage > 50 ? 'text-yellow-500' : 'text-green-500'
                }`}>
                  {erCapacityData.percentage > 90 ? 'Critical Capacity' : 
                   erCapacityData.percentage > 70 ? 'High Capacity' : 
                   erCapacityData.percentage > 50 ? 'Moderate Capacity' : 'Normal Capacity'}
                </p>
              </div>
            </div>

            {/* Patient Triage */}
            <div className="bg-gray-50 rounded-lg p-4 shadow">
              <h2 className="text-lg font-medium mb-2 flex items-center">
                <i className="fas fa-procedures text-red-600 mr-2"></i>
                Patient Triage Distribution
              </h2>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={triageData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={80}
                      fill="#8884d8"
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                    >
                      {triageData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center mt-2">
                <div className="text-sm">
                  <span className="font-medium">Total Patients: </span>
                  {triageData.reduce((sum, item) => sum + item.value, 0)}
                </div>
              </div>
            </div>

            {/* Response Time */}
            <div className="bg-gray-50 rounded-lg p-4 shadow">
              <h2 className="text-lg font-medium mb-2 flex items-center">
                <i className="fas fa-clock text-red-600 mr-2"></i>
                Average Response Time (minutes)
              </h2>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={responseTimeData}
                    margin={{ top: 10, right: 30, left: 0, bottom: 5 }}
                  >
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => [`${value} min`, 'Response Time']}
                    />
                    <Bar dataKey="time" fill="#ef4444" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Emergency Team Status */}
            <div className="bg-gray-50 rounded-lg p-4 shadow">
              <h2 className="text-lg font-medium mb-2 flex items-center">
                <i className="fas fa-user-md text-red-600 mr-2"></i>
                Emergency Team Status
              </h2>
              <div className="space-y-4 mt-4">
                {teamStatusData.map((team, index) => (
                  <div key={index}>
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium">{team.name}</span>
                      <span>{team.available} / {team.total} Available</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div 
                        className={`h-2.5 rounded-full ${team.available / team.total < 0.3 ? 'bg-red-600' : 'bg-green-600'}`}
                        style={{ width: `${(team.available / team.total) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'alerts' && (
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-medium">Emergency Alerts</h2>
              <button className="bg-red-600 text-white px-4 py-2 rounded flex items-center">
                <i className="fas fa-plus mr-2"></i>
                New Alert
              </button>
            </div>
            
            <div className="bg-white shadow rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Alert ID
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Time
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Level
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Message
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {emergencyAlerts.map((alert) => (
                    <tr key={alert.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium">{alert.id}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>{alert.timestamp}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getAlertLevelColor(alert.level)} text-white`}>
                          {alert.level.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm">{alert.message}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`${getAlertStatusStyle(alert.status)}`}>
                          {alert.status.charAt(0).toUpperCase() + alert.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button className="text-blue-600 hover:text-blue-900">
                            <i className="fas fa-edit"></i>
                          </button>
                          <button className="text-red-600 hover:text-red-900">
                            <i className="fas fa-trash-alt"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'resources' && (
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white shadow rounded-lg p-4">
              <h2 className="text-lg font-medium mb-4 border-b pb-2">Ambulance Fleet Status</h2>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center mr-3">
                      <i className="fas fa-ambulance text-white"></i>
                    </div>
                    <div>
                      <div className="font-medium">Ambulance #1</div>
                      <div className="text-sm text-gray-500">Driver: John Davis</div>
                    </div>
                  </div>
                  <div className="text-green-600 font-medium">Available</div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-red-500 flex items-center justify-center mr-3">
                      <i className="fas fa-ambulance text-white"></i>
                    </div>
                    <div>
                      <div className="font-medium">Ambulance #2</div>
                      <div className="text-sm text-gray-500">Driver: Sarah Johnson</div>
                    </div>
                  </div>
                  <div className="text-red-600 font-medium">On Call - ETA 15 min</div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center mr-3">
                      <i className="fas fa-ambulance text-white"></i>
                    </div>
                    <div>
                      <div className="font-medium">Ambulance #3</div>
                      <div className="text-sm text-gray-500">Driver: Michael Chen</div>
                    </div>
                  </div>
                  <div className="text-green-600 font-medium">Available</div>
                </div>
              </div>
            </div>
            
            <div className="bg-white shadow rounded-lg p-4">
              <h2 className="text-lg font-medium mb-4 border-b pb-2">Emergency Contacts</h2>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 border border-gray-200 rounded-lg">
                  <div>
                    <div className="font-medium">Dr. Elizabeth Thompson</div>
                    <div className="text-sm text-gray-500">Emergency Department Head</div>
                  </div>
                  <button className="text-blue-600 hover:text-blue-800">
                    <i className="fas fa-phone"></i>
                  </button>
                </div>
                
                <div className="flex justify-between items-center p-3 border border-gray-200 rounded-lg">
                  <div>
                    <div className="font-medium">Dr. James Wilson</div>
                    <div className="text-sm text-gray-500">Trauma Surgeon on Call</div>
                  </div>
                  <button className="text-blue-600 hover:text-blue-800">
                    <i className="fas fa-phone"></i>
                  </button>
                </div>
                
                <div className="flex justify-between items-center p-3 border border-gray-200 rounded-lg">
                  <div>
                    <div className="font-medium">Regional Blood Bank</div>
                    <div className="text-sm text-gray-500">Emergency Blood Supply</div>
                  </div>
                  <button className="text-blue-600 hover:text-blue-800">
                    <i className="fas fa-phone"></i>
                  </button>
                </div>
                
                <div className="flex justify-between items-center p-3 border border-gray-200 rounded-lg">
                  <div>
                    <div className="font-medium">City Police Department</div>
                    <div className="text-sm text-gray-500">Emergency Services</div>
                  </div>
                  <button className="text-blue-600 hover:text-blue-800">
                    <i className="fas fa-phone"></i>
                  </button>
                </div>
              </div>
            </div>
            
            <div className="bg-white shadow rounded-lg p-4 col-span-2">
              <h2 className="text-lg font-medium mb-4 border-b pb-2">Emergency Protocols</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 border border-red-200 bg-red-50 rounded-lg">
                  <h3 className="font-medium text-red-700 mb-2">Code Blue - Cardiac Arrest</h3>
                  <p className="text-sm text-gray-700">Immediate response for patient experiencing cardiac arrest. Page on-call cardiologist and bring crash cart to patient location.</p>
                  <button className="mt-3 text-sm text-red-700 font-medium hover:underline">View Full Protocol</button>
                </div>
                
                <div className="p-3 border border-orange-200 bg-orange-50 rounded-lg">
                  <h3 className="font-medium text-orange-700 mb-2">Code Red - Fire Emergency</h3>
                  <p className="text-sm text-gray-700">Evacuation protocol for fire incidents. Secure critical patients first, then proceed with orderly evacuation following marked routes.</p>
                  <button className="mt-3 text-sm text-orange-700 font-medium hover:underline">View Full Protocol</button>
                </div>
                
                <div className="p-3 border border-yellow-200 bg-yellow-50 rounded-lg">
                  <h3 className="font-medium text-yellow-700 mb-2">Mass Casualty Protocol</h3>
                  <p className="text-sm text-gray-700">Triage and treatment protocol for handling multiple trauma patients simultaneously. Establish command center in Conference Room A.</p>
                  <button className="mt-3 text-sm text-yellow-700 font-medium hover:underline">View Full Protocol</button>
                </div>
                
                <div className="p-3 border border-purple-200 bg-purple-50 rounded-lg">
                  <h3 className="font-medium text-purple-700 mb-2">Code Purple - Violent Patient</h3>
                  <p className="text-sm text-gray-700">Safety protocol for managing violent or aggressive patients. Contact security immediately and clear the immediate area.</p>
                  <button className="mt-3 text-sm text-purple-700 font-medium hover:underline">View Full Protocol</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}