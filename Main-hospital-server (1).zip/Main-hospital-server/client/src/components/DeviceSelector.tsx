import React, { useState, useEffect } from 'react';
import { DevicePreference } from '@/lib/types';

interface DeviceSelectorProps {
  onDeviceSelected: (device: 'mobile' | 'laptop') => void;
}

export default function DeviceSelector({ onDeviceSelected }: DeviceSelectorProps) {
  const [selectedDevice, setSelectedDevice] = useState<'mobile' | 'laptop'>('laptop');

  // Save device preference to localStorage
  useEffect(() => {
    const savedPreference = localStorage.getItem('devicePreference');
    if (savedPreference) {
      try {
        const parsed = JSON.parse(savedPreference) as DevicePreference;
        setSelectedDevice(parsed.selectedDevice);
      } catch (e) {
        console.error('Error parsing device preference:', e);
      }
    }
  }, []);

  const handleDeviceSelect = (device: 'mobile' | 'laptop') => {
    setSelectedDevice(device);
    localStorage.setItem('devicePreference', JSON.stringify({ selectedDevice: device }));
    onDeviceSelected(device);
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-80 z-50">
      <div className="bg-white rounded-lg shadow-xl w-11/12 max-w-md p-6 text-center">
        <h2 className="text-2xl font-bold mb-4 text-gray-800">Select Device Mode</h2>
        <p className="mb-8 text-gray-600">Choose the best display option for your device</p>
        
        <div className="grid grid-cols-2 gap-4">
          <div 
            className={`border rounded-lg p-4 cursor-pointer transition-all duration-200 flex flex-col items-center 
              ${selectedDevice === 'laptop' ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-300'}`}
            onClick={() => handleDeviceSelect('laptop')}
          >
            <div className="text-4xl mb-2">💻</div>
            <h3 className="font-medium text-lg">Laptop/Desktop</h3>
            <p className="text-sm text-gray-600 mt-2">Optimized for larger screens</p>
          </div>
          
          <div 
            className={`border rounded-lg p-4 cursor-pointer transition-all duration-200 flex flex-col items-center
              ${selectedDevice === 'mobile' ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-300'}`}
            onClick={() => handleDeviceSelect('mobile')}
          >
            <div className="text-4xl mb-2">📱</div>
            <h3 className="font-medium text-lg">Mobile</h3>
            <p className="text-sm text-gray-600 mt-2">Optimized for smaller screens</p>
          </div>
        </div>
        
        <button 
          className="mt-8 bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-6 rounded-md transition-colors duration-200"
          onClick={() => onDeviceSelected(selectedDevice)}
        >
          Continue
        </button>
        
        <p className="mt-4 text-xs text-gray-500">
          You can change this setting later in the system preferences
        </p>
      </div>
    </div>
  );
}