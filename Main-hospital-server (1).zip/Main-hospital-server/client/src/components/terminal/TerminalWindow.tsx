import React, { useState, useRef, useEffect } from 'react';
import { useWindowContext } from '@/context/WindowContext';
import { TerminalCommandProps, TerminalLoginState, WindowComponents } from '@/lib/types';

interface SystemStatus {
  name: string;
  status: 'ONLINE' | 'OFFLINE' | 'RESTARTING';
}

interface SelectMenuOption {
  value: string;
  label: string;
}

interface PasswordEntry {
  id: string;
  name: string;
  password: string;
  description: string;
}

export default function TerminalWindow() {
  const { openWindow, addWindowIfNotExists } = useWindowContext();
  const [commands, setCommands] = useState<TerminalCommandProps[]>([]);
  const [currentCommand, setCurrentCommand] = useState<string>('');
  const [loginState, setLoginState] = useState<TerminalLoginState>({
    isLoggedIn: false,
    username: '',
    password: '',
    attempts: 0,
    showLoginError: false
  });
  const [systemStatuses, setSystemStatuses] = useState<SystemStatus[]>([
    { name: 'Database', status: 'ONLINE' },
    { name: 'Authentication', status: 'ONLINE' },
    { name: 'Patient Records', status: 'ONLINE' },
    { name: 'Appointment System', status: 'ONLINE' },
    { name: 'Pharmacy Management', status: 'ONLINE' },
    { name: 'Staff Directory', status: 'ONLINE' },
    { name: 'Emergency Response', status: 'ONLINE' },
    { name: 'Reporting Module', status: 'ONLINE' }
  ]);
  const [selectMenuVisible, setSelectMenuVisible] = useState<boolean>(false);
  const [selectMenuOptions, setSelectMenuOptions] = useState<SelectMenuOption[]>([]);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number>(0);
  const [selectMenuCommand, setSelectMenuCommand] = useState<string>('');
  const [inReportPasswordMode, setInReportPasswordMode] = useState<boolean>(false);
  const [inCodeEntryMode, setInCodeEntryMode] = useState<boolean>(false);
  const [accessCodeEntered, setAccessCodeEntered] = useState<boolean>(false);
  const [reportCode, setReportCode] = useState<string>('');
  const [isRebooting, setIsRebooting] = useState<boolean>(false);
  const [rebootPercentage, setRebootPercentage] = useState<number>(0);
  const [rebootTimeRemaining, setRebootTimeRemaining] = useState<number>(0);
  const [inFullControlMode, setInFullControlMode] = useState<boolean>(false);
  const [fullControlOptions, setFullControlOptions] = useState<SelectMenuOption[]>([]);
  const [fullControlSelectedIndex, setFullControlSelectedIndex] = useState<number>(0);
  const [systemUsers, setSystemUsers] = useState<{username: string, role: string, password: string}[]>([
    {username: "admin", role: "Administrator", password: "adminpass"},
    {username: "sysop", role: "System Operator", password: "syspass"},
    {username: "doctor1", role: "Doctor", password: "docpass1"},
    {username: "doctor2", role: "Doctor", password: "docpass2"},
    {username: "nurse1", role: "Nurse", password: "nursepass1"},
    {username: "nurse2", role: "Nurse", password: "nursepass2"},
    {username: "technician", role: "Technical Staff", password: "techpass"}
  ]);
  const [onlineDoctors, setOnlineDoctors] = useState<number>(10);
  
  // Password entries with descriptions and access codes
  const [passwordEntries, setPasswordEntries] = useState<PasswordEntry[]>([
    {
      id: "terminal", 
      name: "Terminal Login", 
      password: "admin",
      description: "Access to terminal commands and system control"
    },
    {
      id: "sysaccess", 
      name: "System Access Code", 
      password: "1234",
      description: "Terminal full control access code"
    },
    {
      id: "reports", 
      name: "Reports Access", 
      password: "reports123",
      description: "Access code for detailed hospital reports"
    },
    {
      id: "sysadmin", 
      name: "System Administrator", 
      password: "admin123",
      description: "Administrative access to core system functions"
    },
    {
      id: "database", 
      name: "Database Access", 
      password: "db_secure456",
      description: "Secure credentials for database management system"
    },
    {
      id: "pharmacy", 
      name: "Pharmacy Controls", 
      password: "pharm789",
      description: "Access to pharmacy inventory and medication management"
    },
    {
      id: "emergency", 
      name: "Emergency Override", 
      password: "emergency911",
      description: "Emergency access override for critical situations"
    },
    {
      id: "network", 
      name: "Network Security", 
      password: "network567",
      description: "Network infrastructure security credentials"
    }
  ]);
  
  // Current state for password changing
  const [inPasswordChangeMode, setInPasswordChangeMode] = useState<boolean>(false);
  const [passwordChangeStep, setPasswordChangeStep] = useState<'select' | 'old' | 'new' | 'confirm'>('select');
  const [selectedPasswordId, setSelectedPasswordId] = useState<string>('');
  const [oldPassword, setOldPassword] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [passwordChangeVerificationCode, setPasswordChangeVerificationCode] = useState<string>("AUTH742");
  
  // System access code
  const [systemAccessCode, setSystemAccessCode] = useState<string>("1234");
  
  // We already have newPassword defined above, no need to redefine it
  
  // System-wide password storage for different components
  const [systemPasswords, setSystemPasswords] = useState<{
    terminalLogin: string,
    reportsAccess: string,
    adminReports: string,
    databaseAccess: string,
    emergencyOverride: string
  }>({
    terminalLogin: "password", // default terminal password
    reportsAccess: "reports123", // password for reports section
    adminReports: "admin123", // password for admin reports
    databaseAccess: "db123", // database access password
    emergencyOverride: "emergency" // emergency override code
  });
  
  const terminalRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom when commands change
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [commands]);

  // Focus the input when the terminal is clicked
  useEffect(() => {
    const handleClick = () => {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    };

    if (terminalRef.current) {
      terminalRef.current.addEventListener('click', handleClick);
    }

    return () => {
      if (terminalRef.current) {
        terminalRef.current.removeEventListener('click', handleClick);
      }
    };
  }, []);
  
  // Randomly change the number of online doctors (always at least 10)
  useEffect(() => {
    const doctorChangeInterval = setInterval(() => {
      const newDoctorCount = 10 + Math.floor(Math.random() * 5);
      setOnlineDoctors(newDoctorCount);
    }, 60000); // Change every minute
    
    return () => clearInterval(doctorChangeInterval);
  }, []);

  // Handle command execution
  const executeCommand = (cmd: string) => {
    if (!cmd.trim()) return;

    // Skip command execution if in select menu mode
    if (selectMenuVisible) return;
    
    // Handle report password mode
    if (inReportPasswordMode) {
      handleReportPasswordInput(cmd);
      return;
    }
    
    // Handle access code entry mode
    if (inCodeEntryMode) {
      handleAccessCodeInput(cmd);
      return;
    }
    
    // Handle password change mode
    if (inPasswordChangeMode) {
      handlePasswordChangeInput(cmd);
      return;
    }
    
    // Handle full control mode
    if (inFullControlMode) {
      handleFullControlCommand(cmd);
      return;
    }

    // Add command to history
    const newCommand: TerminalCommandProps = {
      command: cmd,
      output: '',
      isError: false
    };

    // Process login first if not logged in
    if (!loginState.isLoggedIn) {
      handleLoginProcess(cmd, newCommand);
      return;
    }

    // Process regular commands when logged in
    handleCommand(cmd, newCommand);
  };

  // Handle login process
  const handleLoginProcess = (cmd: string, newCommand: TerminalCommandProps) => {
    if (!loginState.username) {
      // Username phase
      newCommand.output = 'Password:';
      setLoginState({
        ...loginState,
        username: cmd,
        showLoginError: false
      });
    } else if (!loginState.password) {
      // Password phase - don't show the password in terminal
      newCommand.command = '';
      
      if (cmd === 'adminpass') { // Simple hardcoded password for demo
        newCommand.output = `Welcome to Hospital Management Terminal, ${loginState.username}!\nType 'help' to see available commands.`;
        setLoginState({
          ...loginState,
          password: cmd,
          isLoggedIn: true,
          showLoginError: false
        });
      } else {
        newCommand.output = 'Login incorrect';
        newCommand.isError = true;
        setLoginState({
          ...loginState,
          password: '',
          username: '',
          attempts: loginState.attempts + 1,
          showLoginError: true
        });
        
        if (loginState.attempts >= 2) {
          setCommands([...commands, newCommand, {
            command: '',
            output: '3 incorrect password attempts. This incident will be reported.',
            isError: true
          }]);
          return;
        }
      }
    }

    setCommands([...commands, newCommand]);
    setCurrentCommand('');
  };

  // Handle report database code input
  const handleReportPasswordInput = (code: string) => {
    // The code for accessing reports is "4815162342"
    if (code === "4815162342") {
      setInReportPasswordMode(false);
      setCommands([...commands, {
        command: "",
        output: "Access granted to secure report database.\n\nREPORT DATABASE CONTENTS:\n" + generateReportDatabase(),
        isError: false
      }]);
    } else {
      setInReportPasswordMode(false);
      setCommands([...commands, {
        command: "",
        output: "Access denied. Incorrect security code.",
        isError: true
      }]);
    }
    setCurrentCommand('');
  };
  
  // Handle password change workflow
  const handlePasswordChangeInput = (input: string) => {
    if (passwordChangeStep === 'old') {
      // Verify old password
      const passwordEntry = passwordEntries.find(entry => entry.id === selectedPasswordId);
      
      if (!passwordEntry) {
        setInPasswordChangeMode(false);
        setCommands([...commands, {
          command: "",
          output: "Error: Selected password entry not found.",
          isError: true
        }]);
        return;
      }
      
      if (input !== passwordEntry.password) {
        setInPasswordChangeMode(false);
        setCommands([...commands, {
          command: "",
          output: "Access denied. Incorrect password.",
          isError: true
        }]);
        return;
      }
      
      setOldPassword(input);
      setPasswordChangeStep('new');
      setCommands([...commands, {
        command: "",
        output: "Current password verified.\nPlease enter the new password:",
        isError: false
      }]);
    } else if (passwordChangeStep === 'new') {
      // Store new password
      setNewPassword(input);
      setPasswordChangeStep('confirm');
      setCommands([...commands, {
        command: "",
        output: `Please enter verification code to confirm password change (code: ${passwordChangeVerificationCode}):`,
        isError: false
      }]);
    } else if (passwordChangeStep === 'confirm') {
      // Verify confirmation code and complete change
      if (input !== passwordChangeVerificationCode) {
        setInPasswordChangeMode(false);
        setPasswordChangeStep('select');
        setCommands([...commands, {
          command: "",
          output: "Password change aborted. Incorrect verification code.",
          isError: true
        }]);
        return;
      }
      
      // Update the password
      const entryIndex = passwordEntries.findIndex(entry => entry.id === selectedPasswordId);
      if (entryIndex !== -1) {
        const updatedEntries = [...passwordEntries];
        updatedEntries[entryIndex] = {
          ...updatedEntries[entryIndex],
          password: newPassword
        };
        
        setPasswordEntries(updatedEntries);
        
        setCommands([...commands, {
          command: "",
          output: `Password for "${updatedEntries[entryIndex].name}" has been successfully updated.`,
          isError: false
        }]);
      }
      
      // Reset password change state
      setInPasswordChangeMode(false);
      setPasswordChangeStep('select');
      setSelectedPasswordId('');
      setOldPassword('');
      setNewPassword('');
    }
    
    setCurrentCommand('');
  };
  
  // Handle system access code verification
  const handleAccessCodeInput = (code: string) => {
    // Check access code and store the result
    if (code === systemAccessCode) {
      setAccessCodeEntered(true);
      setInCodeEntryMode(false);
      setCommands([...commands, {
        command: "",
        output: "Access code verified. Launching Admin Control Panel...\n\nWARNING: This grants complete access to all system settings.",
        isError: false
      }]);
      
      // Register and open the Admin Control Panel window instead of entering full control mode
      addWindowIfNotExists('adminpanel');
      openWindow('adminpanel');
      
      // Reset terminal state
      setInFullControlMode(false);
    } else {
      setInCodeEntryMode(false);
      setCommands([...commands, {
        command: "",
        output: "Access denied. Incorrect security code.",
        isError: true
      }]);
    }
    setCurrentCommand('');
  };
  
  // Handle full control mode
  const handleFullControlCommand = (cmd: string) => {
    const cmdParts = cmd.split(' ');
    const operation = cmdParts[0].toLowerCase();
    
    switch(operation) {
      case 'user':
        if (cmdParts.length < 3) {
          setCommands([...commands, {
            command: cmd,
            output: "Invalid command. Format: user [username] [operation] [value]",
            isError: true
          }]);
          return;
        }
        
        const username = cmdParts[1];
        const action = cmdParts[2];
        const userIndex = systemUsers.findIndex(u => u.username === username);
        
        if (userIndex === -1) {
          setCommands([...commands, {
            command: cmd,
            output: `User "${username}" not found.`,
            isError: true
          }]);
          return;
        }
        
        const updatedUsers = [...systemUsers];
        
        if (action === 'password' && cmdParts.length >= 4) {
          const newPassword = cmdParts[3];
          updatedUsers[userIndex] = {...updatedUsers[userIndex], password: newPassword};
          setSystemUsers(updatedUsers);
          setCommands([...commands, {
            command: cmd,
            output: `Password updated for user "${username}".`,
            isError: false
          }]);
        } else if (action === 'role' && cmdParts.length >= 4) {
          const newRole = cmdParts[3];
          updatedUsers[userIndex] = {...updatedUsers[userIndex], role: newRole};
          setSystemUsers(updatedUsers);
          setCommands([...commands, {
            command: cmd,
            output: `Role updated for user "${username}" to "${newRole}".`,
            isError: false
          }]);
        } else {
          setCommands([...commands, {
            command: cmd,
            output: `Invalid command. Available operations: password, role`,
            isError: true
          }]);
        }
        break;
        
      case 'password':
        if (cmdParts.length < 3) {
          setCommands([...commands, {
            command: cmd,
            output: "Invalid command. Format: password [system] [new_password]",
            isError: true
          }]);
          return;
        }
        
        const system = cmdParts[1].toLowerCase();
        const newSystemPassword = cmdParts[2];
        
        // Create updated passwords object
        const updatedPasswords = {...systemPasswords};
        
        if (system === 'terminal' || system === 'login') {
          updatedPasswords.terminalLogin = newSystemPassword;
          setSystemPasswords(updatedPasswords);
          setCommands([...commands, {
            command: cmd,
            output: `Terminal login password updated to "${newSystemPassword}".`,
            isError: false
          }]);
        } else if (system === 'reports') {
          updatedPasswords.reportsAccess = newSystemPassword;
          setSystemPasswords(updatedPasswords);
          setCommands([...commands, {
            command: cmd,
            output: `Reports access password updated to "${newSystemPassword}".`,
            isError: false
          }]);
        } else if (system === 'admin') {
          updatedPasswords.adminReports = newSystemPassword;
          setSystemPasswords(updatedPasswords);
          setCommands([...commands, {
            command: cmd,
            output: `Admin reports password updated to "${newSystemPassword}".`,
            isError: false
          }]);
        } else if (system === 'database' || system === 'db') {
          updatedPasswords.databaseAccess = newSystemPassword;
          setSystemPasswords(updatedPasswords);
          setCommands([...commands, {
            command: cmd,
            output: `Database access password updated to "${newSystemPassword}".`,
            isError: false
          }]);
        } else if (system === 'emergency') {
          updatedPasswords.emergencyOverride = newSystemPassword;
          setSystemPasswords(updatedPasswords);
          setCommands([...commands, {
            command: cmd,
            output: `Emergency override code updated to "${newSystemPassword}".`,
            isError: false
          }]);
        } else {
          setCommands([...commands, {
            command: cmd,
            output: `Unknown system "${system}". Available options: terminal, reports, admin, database, emergency`,
            isError: true
          }]);
        }
        break;
        
      case 'system':
        if (cmdParts.length < 3) {
          setCommands([...commands, {
            command: cmd,
            output: "Invalid command. Format: system [service] [operation]",
            isError: true
          }]);
          return;
        }
        
        const serviceName = cmdParts[1];
        const serviceAction = cmdParts[2].toLowerCase();
        const serviceIndex = systemStatuses.findIndex(s => 
          s.name.toLowerCase().replace(' ', '_') === serviceName.toLowerCase());
        
        if (serviceIndex === -1) {
          setCommands([...commands, {
            command: cmd,
            output: `Service "${serviceName}" not found.`,
            isError: true
          }]);
          return;
        }
        
        const updatedStatuses = [...systemStatuses];
        
        if (serviceAction === 'online') {
          updatedStatuses[serviceIndex] = { ...updatedStatuses[serviceIndex], status: 'ONLINE' };
          setSystemStatuses(updatedStatuses);
          setCommands([...commands, {
            command: cmd,
            output: `Service "${systemStatuses[serviceIndex].name}" status set to ONLINE.`,
            isError: false
          }]);
        } else if (serviceAction === 'offline') {
          updatedStatuses[serviceIndex] = { ...updatedStatuses[serviceIndex], status: 'OFFLINE' };
          setSystemStatuses(updatedStatuses);
          setCommands([...commands, {
            command: cmd,
            output: `Service "${systemStatuses[serviceIndex].name}" status set to OFFLINE.`,
            isError: false
          }]);
        } else if (serviceAction === 'restart') {
          updatedStatuses[serviceIndex] = { ...updatedStatuses[serviceIndex], status: 'RESTARTING' };
          setSystemStatuses(updatedStatuses);
          setCommands([...commands, {
            command: cmd,
            output: `Restarting service "${systemStatuses[serviceIndex].name}"...`,
            isError: false
          }]);
          
          setTimeout(() => {
            const finalStatuses = [...updatedStatuses];
            finalStatuses[serviceIndex] = { ...finalStatuses[serviceIndex], status: 'ONLINE' };
            setSystemStatuses(finalStatuses);
            
            setCommands(prev => [...prev, {
              command: '',
              output: `Service "${systemStatuses[serviceIndex].name}" successfully restarted.`,
              isError: false
            }]);
          }, 3000);
        } else {
          setCommands([...commands, {
            command: cmd,
            output: `Invalid operation. Available operations: online, offline, restart`,
            isError: true
          }]);
        }
        break;
        
      case 'passwords':
        const passwordAction = cmdParts.length > 1 ? cmdParts[1].toLowerCase() : 'list';
        
        if (passwordAction === 'list') {
          // List all password entries
          const passwordList = passwordEntries.map(entry => 
            `${entry.id.padEnd(12)} | ${entry.name.padEnd(25)} | ${entry.description}`
          ).join('\n');
          
          setCommands([...commands, {
            command: cmd,
            output: `System Passwords:\n\nID          | Name                      | Description\n${'-'.repeat(80)}\n${passwordList}`,
            isError: false
          }]);
        } else if (passwordAction === 'change') {
          // Show password selection dropdown
          setSelectMenuVisible(true);
          setSelectMenuCommand('passwords_change');
          setSelectMenuOptions(
            passwordEntries.map(entry => ({
              value: entry.id,
              label: entry.name
            }))
          );
          setSelectedOptionIndex(0);
          
          setCommands([...commands, {
            command: cmd,
            output: "Select a password entry to change:",
            isError: false
          }]);
          return;
        } else if (passwordAction === 'reset') {
          // Reset all passwords to default values
          setPasswordEntries([
            {
              id: "terminal", 
              name: "Terminal Login", 
              password: "admin",
              description: "Access to terminal commands and system control"
            },
            {
              id: "sysaccess", 
              name: "System Access Code", 
              password: "1234",
              description: "Terminal full control access code"
            },
            {
              id: "reports", 
              name: "Reports Access", 
              password: "reports123",
              description: "Access code for detailed hospital reports"
            },
            {
              id: "sysadmin", 
              name: "System Administrator", 
              password: "admin123",
              description: "Administrative access to core system functions"
            },
            {
              id: "database", 
              name: "Database Access", 
              password: "db_secure456",
              description: "Secure credentials for database management system"
            },
            {
              id: "pharmacy", 
              name: "Pharmacy Controls", 
              password: "pharm789",
              description: "Access to pharmacy inventory and medication management"
            },
            {
              id: "emergency", 
              name: "Emergency Override", 
              password: "emergency911",
              description: "Emergency access override for critical situations"
            },
            {
              id: "network", 
              name: "Network Security", 
              password: "network567",
              description: "Network infrastructure security credentials"
            }
          ]);
          
          setCommands([...commands, {
            command: cmd,
            output: "All system passwords have been reset to their default values.",
            isError: false
          }]);
        } else if (passwordAction === 'code') {
          // Change the system access code
          const newCode = cmdParts.length > 2 ? cmdParts[2] : '';
          
          if (!newCode) {
            setCommands([...commands, {
              command: cmd,
              output: "Usage: passwords code [new_code]",
              isError: true
            }]);
            return;
          }
          
          setSystemAccessCode(newCode);
          setCommands([...commands, {
            command: cmd,
            output: `System access code has been updated to "${newCode}".`,
            isError: false
          }]);
        } else {
          setCommands([...commands, {
            command: cmd,
            output: "Available password commands: list, change, reset, code",
            isError: true
          }]);
        }
        break;
        
      case 'exit':
        setInFullControlMode(false);
        setCommands([...commands, {
          command: cmd,
          output: "Exiting full control mode...",
          isError: false
        }]);
        break;
        
      case 'help':
        setCommands([...commands, {
          command: cmd,
          output: `
Full Control Mode Commands:
  user [username] password [new_password] - Change user password
  
  passwords list                          - List all system passwords
  passwords change                        - Change password (dropdown selection)
  passwords reset                         - Reset all passwords to defaults
  passwords code [new_code]               - Change system access code
  
  password [system] [new_password]        - Change system passwords
    Options: terminal, reports, admin, database, emergency
    
  system [service] online                 - Set service status to ONLINE
  system [service] offline                - Set service status to OFFLINE
  system [service] restart                - Restart a service
  system restart [time]                   - Reboot entire system with countdown
  
  database backup                         - Backup hospital database
  security lockdown                       - Enable security lockdown
  exit                                    - Exit full control mode
  help                                    - Show this help message
          `,
          isError: false
        }]);
        break;
        
      default:
        setCommands([...commands, {
          command: cmd,
          output: `Command not found: ${cmd}`,
          isError: true
        }]);
    }
    
    setCurrentCommand('');
  };

  // Generate mock report database content
  const generateReportDatabase = () => {
    const reportTypes = ["Incident", "Surgery", "Admission", "Discharge", "Pharmacy", "Billing", "Audit"];
    const reports = [];

    // Generate 20 random reports
    for (let i = 0; i < 20; i++) {
      const type = reportTypes[Math.floor(Math.random() * reportTypes.length)];
      const id = `RPT-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
      const date = new Date();
      date.setDate(date.getDate() - Math.floor(Math.random() * 30));
      
      reports.push(`${id} | ${type} | ${date.toISOString().split('T')[0]} | Dr. ${["Smith", "Johnson", "Williams", "Jones", "Brown"][Math.floor(Math.random() * 5)]}`);
    }

    return reports.join('\n');
  };

  // Initiate system reboot process
  const initiateSystemReboot = () => {
    setIsRebooting(true);
    
    // Generate a random reboot time between 20-240 seconds
    const rebootTime = Math.floor(Math.random() * 220) + 20; // 20-240 seconds
    setRebootTimeRemaining(rebootTime);
    
    setCommands([...commands, {
      command: "",
      output: `Initiating system reboot...\n\nThis will take approximately ${rebootTime} seconds.`,
      isError: false
    }]);

    // Set all services to RESTARTING immediately
    const updatedStatuses = systemStatuses.map(status => ({
      ...status,
      status: 'RESTARTING' as const
    }));
    setSystemStatuses(updatedStatuses);
    
    // Update reboot progress every second
    const rebootInterval = setInterval(() => {
      setRebootTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(rebootInterval);
          
          // When complete, set all services back to ONLINE
          const onlineStatuses = systemStatuses.map(status => ({
            ...status,
            status: 'ONLINE' as const
          }));
          setSystemStatuses(onlineStatuses);
          
          setCommands(prev => [...prev, {
            command: "",
            output: "System reboot complete. All services are now ONLINE.",
            isError: false
          }]);
          
          setIsRebooting(false);
          setRebootPercentage(100);
          
          return 0;
        }
        
        // Calculate and update percentage
        const newPercentage = Math.floor(((rebootTime - prev + 1) / rebootTime) * 100);
        setRebootPercentage(newPercentage);
        
        // Only add status updates every 10 seconds to avoid spamming the terminal
        if (prev % 10 === 0 || prev === rebootTime - 1) {
          setCommands(prevCmds => [...prevCmds, {
            command: "",
            output: `Reboot in progress... ${newPercentage}% complete. ${prev - 1} seconds remaining.`,
            isError: false
          }]);
        }
        
        return prev - 1;
      });
    }, 1000);
  };

  // Process commands
  const handleCommand = (cmd: string, newCommand: TerminalCommandProps) => {
    const commandLower = cmd.toLowerCase().trim();
    const commandParts = commandLower.split(' ');
    const mainCommand = commandParts[0];

    switch (mainCommand) {
      case 'help':
        newCommand.output = `
Available commands:
  help               - Show this help message
  clear              - Clear the terminal
  status             - Show system status
  restart [service]  - Restart a specific service
  reboot             - Reboot the entire system
  users              - List all users
  reports            - Access secure report database with security code
  export [type]      - Export system data (types: users, patients, inventory)
  online             - Show current online staff
  fullcontrol        - Launch Admin Control Panel (requires code)
  taskmgr, taskmanager - Open Task Manager to control running applications
  exit               - Logout from terminal
  shutdown           - Shutdown the terminal
        `;
        break;

      case 'clear':
        setCommands([]);
        return;

      case 'status':
        const statusOutput = systemStatuses.map(system => {
          const statusIcon = system.status === 'ONLINE' ? '✅' : 
                            system.status === 'RESTARTING' ? '🔄' : '❌';
          return `  ${statusIcon} ${system.name.padEnd(20, '.')} ${system.status}`;
        }).join('\n');
        
        newCommand.output = `
Hospital System Status:
${statusOutput}

Server Health:
  Memory Usage: 42%
  CPU Load: 23%
  Disk Space: 68% free
  Uptime: 23 days, 4 hours
  Online Doctors: ${onlineDoctors}
        `;
        break;

      case 'restart':
        if (commandParts.length < 2) {
          // Show all available services for restart
          setSelectMenuVisible(true);
          setSelectMenuCommand('restart');
          setSelectMenuOptions(systemStatuses.map(system => ({
            value: system.name.toLowerCase().replace(' ', '_'),
            label: system.name
          })));
          setSelectedOptionIndex(0);
          
          newCommand.output = "Select a service to restart:";
          setCommands([...commands, newCommand]);
          return;
        } else {
          const serviceName = commandParts[1];
          const serviceIndex = systemStatuses.findIndex(s => 
            s.name.toLowerCase().replace(' ', '_') === serviceName);
          
          if (serviceIndex >= 0) {
            const service = systemStatuses[serviceIndex];
            
            // Set service to restarting
            const updatedStatuses = [...systemStatuses];
            updatedStatuses[serviceIndex] = { ...service, status: 'RESTARTING' };
            setSystemStatuses(updatedStatuses);
            
            newCommand.output = `Restarting ${service.name} service...`;
            setCommands([...commands, newCommand]);
            
            // After a delay, set it back to online
            setTimeout(() => {
              const finalStatuses = [...updatedStatuses];
              finalStatuses[serviceIndex] = { ...service, status: 'ONLINE' };
              setSystemStatuses(finalStatuses);
              
              setCommands(prev => [...prev, {
                command: '',
                output: `Service ${service.name} successfully restarted.`,
                isError: false
              }]);
            }, 3000);
            
            return;
          } else {
            newCommand.output = `Error: Service "${serviceName}" not found.`;
            newCommand.isError = true;
          }
        }
        break;

      case 'reboot':
        initiateSystemReboot();
        setCommands([...commands, newCommand]);
        return;

      case 'users':
        newCommand.output = `
Authorized System Users:
  admin (Administrator)
  sysop (System Operator)
  doctor (Medical Staff)
  nurse (Medical Staff)
  technician (Technical Staff)
        `;
        break;
        
      case 'online':
        newCommand.output = `
Currently Online Staff:
  Doctors: ${onlineDoctors} online
  Nurses: ${Math.floor(onlineDoctors * 1.5)} online
  Technicians: ${Math.floor(onlineDoctors * 0.5)} online
  Administrators: 2 online
        `;
        break;
        
      case 'reports':
        newCommand.output = "Accessing secure report database. Please enter security code:";
        setCommands([...commands, newCommand]);
        setCurrentCommand('');
        setInReportPasswordMode(true);
        return;
        
      case 'fullcontrol':
        // Require access code before launching Admin Control Panel
        if (!accessCodeEntered) {
          newCommand.output = "TERMINAL ACCESS VERIFICATION REQUIRED\n\nPlease enter system access code:";
          setInCodeEntryMode(true);
          setCommands([...commands, newCommand]);
          setCurrentCommand('');
          return;
        }
        
        // Launch the Admin Control Panel application instead of entering terminal full control mode
        newCommand.output = "Access code verified. Launching Admin Control Panel...\n\nWARNING: This grants complete access to all system settings.";
        setCommands([...commands, newCommand]);
        
        // Register and open the Admin Control Panel window
        addWindowIfNotExists('adminpanel');
        openWindow('adminpanel');
        
        // Reset terminal state
        setAccessCodeEntered(false);
        
        // Process commands directly in handleFullControlCommand from now on
        setCurrentCommand('');
        return;
        
      case 'export':
        if (commandParts.length < 2) {
          setSelectMenuVisible(true);
          setSelectMenuCommand('export');
          setSelectMenuOptions([
            { value: 'users', label: 'User Data' },
            { value: 'patients', label: 'Patient Records' },
            { value: 'inventory', label: 'Inventory Data' },
            { value: 'appointments', label: 'Appointment Schedule' },
            { value: 'reports', label: 'System Reports' }
          ]);
          setSelectedOptionIndex(0);
          
          newCommand.output = "Select data to export:";
          setCommands([...commands, newCommand]);
          return;
        } else {
          const exportType = commandParts[1];
          const validExportTypes = ['users', 'patients', 'inventory', 'appointments', 'reports'];
          
          if (validExportTypes.includes(exportType)) {
            newCommand.output = `Exporting ${exportType} data...\n\nExport complete. File saved to /exports/${exportType}_${new Date().toISOString().split('T')[0]}.csv`;
          } else {
            newCommand.output = `Error: Invalid export type "${exportType}". Valid types are: ${validExportTypes.join(', ')}`;
            newCommand.isError = true;
          }
        }
        break;

      case 'exit':
      case 'logout':
        newCommand.output = 'Logging out...';
        setCommands([...commands, newCommand]);
        
        // Reset login state after showing logout message
        setTimeout(() => {
          setCommands([...commands, newCommand, {
            command: '',
            output: 'Hospital Management Terminal [Version 3.2.1]\nLogin:',
            isError: false
          }]);
          setLoginState({
            isLoggedIn: false,
            username: '',
            password: '',
            attempts: 0,
            showLoginError: false
          });
        }, 500);
        return;

      case 'shutdown':
        newCommand.output = 'Shutting down terminal...';
        setCommands([...commands, newCommand]);
        
        // Add shutdown confirmation after a delay
        setTimeout(() => {
          setCommands([...commands, newCommand, {
            command: '',
            output: 'Terminal shutdown complete. You may close this window.',
            isError: false
          }]);
        }, 1000);
        return;
        
      case 'taskmgr':
      case 'taskmanager':
        newCommand.output = 'Launching Task Manager...';
        setCommands([...commands, newCommand]);
        
        // Register and open the Task Manager window
        addWindowIfNotExists('taskmanager');
        openWindow('taskmanager');
        return;

      default:
        newCommand.output = `Command not found: ${cmd}`;
        newCommand.isError = true;
    }

    setCommands([...commands, newCommand]);
    setCurrentCommand('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (selectMenuVisible) {
      // Handle navigation in select menu
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedOptionIndex(prev => Math.max(0, prev - 1));
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedOptionIndex(prev => Math.min(selectMenuOptions.length - 1, prev + 1));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const selected = selectMenuOptions[selectedOptionIndex];
        setSelectMenuVisible(false);
        
        if (selectMenuCommand === 'restart') {
          executeCommand(`restart ${selected.value}`);
        } else if (selectMenuCommand === 'export') {
          executeCommand(`export ${selected.value}`);
        } else if (selectMenuCommand === 'passwords_change') {
          // Start password change process
          setSelectedPasswordId(selected.value);
          setInPasswordChangeMode(true);
          setPasswordChangeStep('old');
          setCommands([...commands, {
            command: "",
            output: `Changing password for: ${selected.label}\nPlease enter the current password:`,
            isError: false
          }]);
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        setSelectMenuVisible(false);
        setCommands(prev => [...prev, {
          command: "",
          output: "Operation cancelled.",
          isError: false
        }]);
      }
    } else if (inCodeEntryMode && e.key === 'Enter') {
      // Handle system access code entry
      e.preventDefault();
      handleAccessCodeInput(currentCommand);
      setCurrentCommand('');
    } else if (inFullControlMode) {
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        // Handle arrow navigation in full control mode
        e.preventDefault();
        
        if (e.key === 'ArrowUp') {
          setFullControlSelectedIndex(prev => Math.max(0, prev - 1));
        } else {
          setFullControlSelectedIndex(prev => Math.min(fullControlOptions.length - 1, prev + 1));
        }
        
        // Show the selected option
        const selectedOption = fullControlOptions[fullControlSelectedIndex];
        if (selectedOption) {
          setCurrentCommand(`${selectedOption.value}`);
        }
      } else if (e.key === 'Enter') {
        // Execute the selected option directly when pressing Enter
        const selectedOption = fullControlOptions[fullControlSelectedIndex];
        if (selectedOption) {
          executeCommand(selectedOption.value);
        } else {
          executeCommand(currentCommand);
        }
      } else if (e.key === 'Escape') {
        // Exit full control mode on Escape key
        setInFullControlMode(false);
        setCommands(prev => [...prev, {
          command: "",
          output: "Exited Full Control Mode.",
          isError: false
        }]);
      }
      
      // Match the selected index to the current command
      if (currentCommand) {
        const commandIndex = fullControlOptions.findIndex(option => 
          option.value === currentCommand);
        if (commandIndex >= 0) {
          setFullControlSelectedIndex(commandIndex);
        }
      }
    } else if (e.key === 'Enter') {
      executeCommand(currentCommand);
    }
  };

  return (
    <div className="h-full flex flex-col terminal p-1 overflow-hidden">
      <div 
        ref={terminalRef}
        className="flex-1 overflow-y-auto pb-2 scrollbar-thin"
      >
        {/* Initial welcome message */}
        {commands.length === 0 && !loginState.isLoggedIn && (
          <div>
            <div className="text-green-400">Hospital Management Terminal [Version 3.2.1]</div>
            <div className="text-green-400">(c) 2025 Hospital Systems. All rights reserved.</div>
            <div className="mt-2">Login:</div>
          </div>
        )}

        {/* Command history */}
        {commands.map((cmd, index) => (
          <div key={index} className="whitespace-pre-wrap">
            {cmd.command && (
              <div>
                <span className="terminal-prompt">admin@hospital-os</span>
                <span className="text-white">:</span>
                <span className="text-blue-400">~</span>
                <span className="text-white">$ </span>
                <span>{cmd.command}</span>
              </div>
            )}
            <div className={cmd.isError ? 'terminal-error' : 'terminal-output'}>
              {cmd.output}
            </div>
          </div>
        ))}

        {/* Select menu */}
        {selectMenuVisible && (
          <div className="mb-2 border border-gray-700 bg-black">
            {selectMenuOptions.map((option, index) => (
              <div 
                key={index} 
                className={`p-1 ${index === selectedOptionIndex ? 'bg-blue-800' : ''}`}
              >
                {option.label}
              </div>
            ))}
            <div className="text-xs text-gray-500 p-1 border-t border-gray-700">
              Use arrow keys to navigate, Enter to select, Esc to cancel
            </div>
          </div>
        )}

        {/* Login prompt */}
        {!loginState.isLoggedIn && loginState.username && !loginState.password && (
          <div className="flex">
            <span>Password: </span>
          </div>
        )}
        
        {/* Report password prompt */}
        {inReportPasswordMode && (
          <div className="flex">
            <span>Password: </span>
            <span>{'*'.repeat(currentCommand.length)}</span>
            <span className="animate-pulse ml-px">▌</span>
          </div>
        )}
        
        {/* Access code entry prompt */}
        {inCodeEntryMode && (
          <div className="flex">
            <span>Access Code: </span>
            <span>{'*'.repeat(currentCommand.length)}</span>
            <span className="animate-pulse ml-px">▌</span>
          </div>
        )}
        
        {/* Password change process prompts */}
        {inPasswordChangeMode && passwordChangeStep === 'old' && (
          <div className="flex">
            <span>Current Password: </span>
            <span>{'*'.repeat(currentCommand.length)}</span>
            <span className="animate-pulse ml-px">▌</span>
          </div>
        )}
        
        {inPasswordChangeMode && passwordChangeStep === 'new' && (
          <div className="flex">
            <span>New Password: </span>
            <span>{'*'.repeat(currentCommand.length)}</span>
            <span className="animate-pulse ml-px">▌</span>
          </div>
        )}
        
        {inPasswordChangeMode && passwordChangeStep === 'confirm' && (
          <div className="flex">
            <span>Verification Code: </span>
            <span>{currentCommand}</span>
            <span className="animate-pulse ml-px">▌</span>
          </div>
        )}

        {/* Command prompt when logged in */}
        {loginState.isLoggedIn && !inReportPasswordMode && !inCodeEntryMode && !selectMenuVisible && !inPasswordChangeMode && (
          <div className="flex">
            <span className="terminal-prompt">admin@hospital-os</span>
            <span className="text-white">:</span>
            <span className="text-blue-400">~</span>
            <span className="text-white">$ </span>
            <span>{currentCommand}</span>
            <span className="animate-pulse ml-px">▌</span>
          </div>
        )}

        {/* Full control mode menu */}
        {inFullControlMode && (
          <div className="mb-2 mt-2 border border-gray-700 bg-gray-900 p-1">
            <div className="text-yellow-400 font-bold mb-1">FULL CONTROL MODE - ADMINISTRATIVE ACCESS</div>
            {fullControlOptions.map((option, index) => (
              <div 
                key={index} 
                className={`p-1 ${index === fullControlSelectedIndex ? 'bg-yellow-800 text-white' : 'text-yellow-300'}`}
              >
                {option.label}
              </div>
            ))}
            <div className="text-xs text-yellow-600 p-1 mt-1 border-t border-gray-700">
              Use arrow keys to navigate, Enter to select, or type a command directly
            </div>
          </div>
        )}
        
        {/* Login error message */}
        {loginState.showLoginError && (
          <div className="terminal-error">
            Login incorrect. {3 - loginState.attempts} attempts remaining.
          </div>
        )}

        {/* Initial login prompt */}
        {!loginState.isLoggedIn && !loginState.username && commands.length === 0 && (
          <div className="flex">
            <span>Login: </span>
            <span>{currentCommand}</span>
            <span className="animate-pulse ml-px">▌</span>
          </div>
        )}
      </div>

      {/* Hidden input field for capturing keyboard input */}
      <input
        ref={inputRef}
        type={(!loginState.isLoggedIn && loginState.username) || inReportPasswordMode || inCodeEntryMode || (inPasswordChangeMode && (passwordChangeStep === 'old' || passwordChangeStep === 'new')) ? 'password' : 'text'}
        className="terminal-input opacity-0 absolute"
        value={currentCommand}
        onChange={(e) => setCurrentCommand(e.target.value)}
        onKeyDown={handleKeyDown}
        autoFocus
      />
    </div>
  );
}