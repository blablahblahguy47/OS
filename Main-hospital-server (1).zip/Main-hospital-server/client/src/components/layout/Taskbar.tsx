import React from 'react';
import { format } from 'date-fns';
import { WindowState, WindowComponents } from '@/lib/types';

interface TaskbarProps {
  startMenuOpen: boolean;
  onStartButtonClick: () => void;
  onTaskbarItemClick: (id: WindowComponents) => void;
  windows: WindowState[];
}

export default function Taskbar({ startMenuOpen, onStartButtonClick, onTaskbarItemClick, windows }: TaskbarProps) {
  const [currentTime, setCurrentTime] = React.useState(new Date());
  const [wifiEnabled, setWifiEnabled] = React.useState(true);
  const [volumeLevel, setVolumeLevel] = React.useState(75);
  const [volumeMuted, setVolumeMuted] = React.useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = React.useState(true);
  const [language, setLanguage] = React.useState('ENG');
  const [securityStatus, setSecurityStatus] = React.useState('protected');
  const [showQuickSettings, setShowQuickSettings] = React.useState(false);
  const [showDateTimeMenu, setShowDateTimeMenu] = React.useState(false);
  
  const quickSettingsRef = React.useRef<HTMLDivElement>(null);
  const dateTimeMenuRef = React.useRef<HTMLDivElement>(null);
  
  // Handle click outside for menus
  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        showQuickSettings &&
        quickSettingsRef.current &&
        !quickSettingsRef.current.contains(event.target as Node)
      ) {
        const quickSettingsButton = document.getElementById('quickSettingsButton');
        if (quickSettingsButton && !quickSettingsButton.contains(event.target as Node)) {
          setShowQuickSettings(false);
        }
      }
      
      if (
        showDateTimeMenu &&
        dateTimeMenuRef.current &&
        !dateTimeMenuRef.current.contains(event.target as Node)
      ) {
        const dateTimeButton = document.getElementById('dateTimeButton');
        if (dateTimeButton && !dateTimeButton.contains(event.target as Node)) {
          setShowDateTimeMenu(false);
        }
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showQuickSettings, showDateTimeMenu]);
  
  // Update time every second when date/time menu is open, otherwise every minute
  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, showDateTimeMenu ? 1000 : 60000);
    
    return () => {
      clearInterval(timer);
    };
  }, [showDateTimeMenu]);
  
  const formattedTime = format(currentTime, 'h:mm a');
  const formattedDate = format(currentTime, 'MM/dd/yyyy');
  
  return (
    <div className="h-12 bg-[#202020] flex items-center px-2 z-10">
      {/* Start Button */}
      <button 
        id="startButton" 
        className={`h-full px-4 flex items-center justify-center hover:bg-opacity-10 hover:bg-white ${startMenuOpen ? 'bg-black bg-opacity-20' : ''}`}
        onClick={onStartButtonClick}
      >
        <i className="fab fa-windows text-white text-xl"></i>
      </button>
      
      {/* Taskbar Items */}
      <div className="h-full flex items-center">
        <button 
          className={`taskbar-item h-full w-12 flex items-center justify-center relative ${
            windows.some(w => w.id === 'dashboard' && w.isOpen && !w.isMinimized) ? 'bg-black bg-opacity-20' : ''
          }`}
          onClick={() => onTaskbarItemClick('dashboard')}
        >
          {windows.some(w => w.id === 'dashboard' && w.isOpen) && (
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-win-blue"></div>
          )}
          <div className="w-8 h-8 rounded bg-win-blue flex items-center justify-center">
            <i className="fas fa-hospital text-white"></i>
          </div>
        </button>
        
        <button 
          className={`taskbar-item h-full w-12 flex items-center justify-center relative ${
            windows.some(w => w.id === 'patients' && w.isOpen && !w.isMinimized) ? 'bg-black bg-opacity-20' : ''
          }`}
          onClick={() => onTaskbarItemClick('patients')}
        >
          {windows.some(w => w.id === 'patients' && w.isOpen) && (
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-win-green"></div>
          )}
          <div className="w-8 h-8 rounded bg-win-green flex items-center justify-center">
            <i className="fas fa-user-injured text-white"></i>
          </div>
        </button>
        
        <button 
          className={`taskbar-item h-full w-12 flex items-center justify-center relative ${
            windows.some(w => w.id === 'appointments' && w.isOpen && !w.isMinimized) ? 'bg-black bg-opacity-20' : ''
          }`}
          onClick={() => onTaskbarItemClick('appointments')}
        >
          {windows.some(w => w.id === 'appointments' && w.isOpen) && (
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-win-orange"></div>
          )}
          <div className="w-8 h-8 rounded bg-win-orange flex items-center justify-center">
            <i className="far fa-calendar-alt text-white"></i>
          </div>
        </button>
        
        <button 
          className={`taskbar-item h-full w-12 flex items-center justify-center relative ${
            windows.some(w => w.id === 'inventory' && w.isOpen && !w.isMinimized) ? 'bg-black bg-opacity-20' : ''
          }`}
          onClick={() => onTaskbarItemClick('inventory')}
        >
          {windows.some(w => w.id === 'inventory' && w.isOpen) && (
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-win-gray-500"></div>
          )}
          <div className="w-8 h-8 rounded bg-win-gray-500 flex items-center justify-center">
            <i className="fas fa-pills text-white"></i>
          </div>
        </button>
        
        <button 
          className={`taskbar-item h-full w-12 flex items-center justify-center relative ${
            windows.some(w => w.id === 'reports' && w.isOpen && !w.isMinimized) ? 'bg-black bg-opacity-20' : ''
          }`}
          onClick={() => onTaskbarItemClick('reports')}
        >
          {windows.some(w => w.id === 'reports' && w.isOpen) && (
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-win-red"></div>
          )}
          <div className="w-8 h-8 rounded bg-win-red flex items-center justify-center">
            <i className="fas fa-chart-bar text-white"></i>
          </div>
        </button>
      </div>
      
      {/* System Tray */}
      <div className="h-full ml-auto flex items-center text-white relative">
        <button 
          className="h-full px-2 flex items-center justify-center hover:bg-opacity-10 hover:bg-white"
          onClick={() => setSecurityStatus(securityStatus === 'protected' ? 'scanning' : 'protected')}
          title="Security Status"
        >
          <i className={`fas fa-shield-alt text-sm ${securityStatus === 'protected' ? 'text-green-400' : 'text-yellow-400'}`}></i>
        </button>
        
        <button 
          className="h-full px-2 flex items-center justify-center hover:bg-opacity-10 hover:bg-white"
          onClick={() => setWifiEnabled(!wifiEnabled)}
          title={wifiEnabled ? "Connected" : "Disconnected"}
        >
          <i className={`fas fa-wifi text-sm ${wifiEnabled ? 'text-white' : 'text-gray-500 opacity-50'}`}></i>
        </button>
        
        <button 
          className="h-full px-2 flex items-center justify-center hover:bg-opacity-10 hover:bg-white"
          onClick={() => setVolumeMuted(!volumeMuted)}
          title={volumeMuted ? "Unmute" : "Mute"}
        >
          <i className={`fas ${volumeMuted ? 'fa-volume-mute' : 'fa-volume-up'} text-sm`}></i>
        </button>
        
        <div className="relative">
          <button 
            className="h-full px-2 flex items-center justify-center hover:bg-opacity-10 hover:bg-white text-xs"
            onClick={() => setLanguage(language === 'ENG' ? 'ESP' : language === 'ESP' ? 'FRA' : 'ENG')}
            title="Change Language"
          >
            {language}
          </button>
        </div>
        
        <div className="relative">
          <button 
            id="dateTimeButton"
            className="h-full px-3 flex flex-col items-center justify-center hover:bg-opacity-10 hover:bg-white"
            onClick={() => {
              setShowDateTimeMenu(!showDateTimeMenu);
              if (showQuickSettings) setShowQuickSettings(false);
            }}
            title="Date and Time"
          >
            <span className="text-xs">{formattedTime}</span>
            <span className="text-xs text-gray-300">{formattedDate}</span>
          </button>
          
          {showDateTimeMenu && (
            <div ref={dateTimeMenuRef} className="absolute bottom-12 right-0 bg-[#202020] border border-[#333] rounded shadow-lg p-3 w-64 z-50">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-sm font-semibold">Date & Time</h3>
                <button 
                  onClick={() => setShowDateTimeMenu(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <i className="fas fa-times text-xs"></i>
                </button>
              </div>
              
              <div className="text-center mb-3">
                <div className="text-2xl font-light mb-1">{format(currentTime, 'h:mm:ss a')}</div>
                <div className="text-sm text-gray-400">{format(currentTime, 'EEEE, MMMM d, yyyy')}</div>
              </div>
              
              <div className="mb-3 grid grid-cols-7 gap-1 text-center">
                {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, index) => (
                  <div key={index} className="text-xs text-gray-500">{day}</div>
                ))}
                
                {Array.from({ length: new Date(currentTime.getFullYear(), currentTime.getMonth(), 1).getDay() }, (_, i) => (
                  <div key={`empty-${i}`} className="h-6"></div>
                ))}
                
                {Array.from(
                  { length: new Date(currentTime.getFullYear(), currentTime.getMonth() + 1, 0).getDate() },
                  (_, i) => {
                    const day = i + 1;
                    const isToday = day === currentTime.getDate();
                    return (
                      <div 
                        key={`day-${day}`} 
                        className={`text-xs h-6 flex items-center justify-center rounded ${
                          isToday ? 'bg-blue-600 text-white font-medium' : 'hover:bg-[#333] cursor-pointer'
                        }`}
                      >
                        {day}
                      </div>
                    );
                  }
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <button 
                  className="bg-blue-600 hover:bg-blue-700 text-white text-xs py-1.5 rounded flex items-center justify-center"
                  onClick={() => {
                    onTaskbarItemClick('appointments');
                    setShowDateTimeMenu(false);
                  }}
                >
                  <i className="fas fa-calendar-alt mr-1.5"></i>
                  Calendar
                </button>
                <button 
                  className="bg-gray-600 hover:bg-gray-700 text-white text-xs py-1.5 rounded flex items-center justify-center"
                  onClick={() => {
                    onTaskbarItemClick('terminal');
                    setShowDateTimeMenu(false);
                  }}
                >
                  <i className="fas fa-clock mr-1.5"></i>
                  Time Settings
                </button>
              </div>
            </div>
          )}
        </div>
        
        <button 
          className="h-full w-10 flex items-center justify-center hover:bg-opacity-10 hover:bg-white"
          onClick={() => setNotificationsEnabled(!notificationsEnabled)}
          title={notificationsEnabled ? "Notifications On" : "Notifications Off"}
        >
          <i className={`far fa-bell text-sm ${!notificationsEnabled && 'opacity-50'}`}></i>
          {!notificationsEnabled && (
            <div className="relative">
              <div className="absolute w-0.5 h-4 bg-red-500 transform rotate-45 -top-2 -right-2.5"></div>
            </div>
          )}
        </button>
        
        <button 
          id="quickSettingsButton"
          className="h-full w-10 flex items-center justify-center hover:bg-opacity-10 hover:bg-white"
          onClick={() => {
            setShowQuickSettings(!showQuickSettings);
            if (showDateTimeMenu) setShowDateTimeMenu(false);
          }}
          title="Quick Settings"
        >
          <i className={`fas ${showQuickSettings ? 'fa-chevron-down' : 'fa-chevron-up'} text-xs`}></i>
        </button>
        
        {showQuickSettings && (
          <div ref={quickSettingsRef} className="absolute bottom-12 right-0 bg-[#202020] border border-[#333] rounded shadow-lg p-3 min-w-64 z-50">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-semibold">Quick Settings</h3>
              <button 
                onClick={() => setShowQuickSettings(false)}
                className="text-gray-400 hover:text-white"
              >
                <i className="fas fa-times text-xs"></i>
              </button>
            </div>
            
            <div className="flex justify-between items-center mb-3 p-2 hover:bg-[#333] rounded">
              <div className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${wifiEnabled ? 'bg-blue-500' : 'bg-gray-700'}`}>
                  <i className="fas fa-wifi text-white"></i>
                </div>
                <div>
                  <span className="text-xs font-medium block">Wi-Fi</span>
                  <span className="text-xs text-gray-400">{wifiEnabled ? 'Connected' : 'Disconnected'}</span>
                </div>
              </div>
              <div 
                className={`w-10 h-6 rounded-full p-1 ${wifiEnabled ? 'bg-blue-500' : 'bg-gray-700'}`}
                onClick={() => setWifiEnabled(!wifiEnabled)}
              >
                <div className={`w-4 h-4 rounded-full bg-white transform transition-transform ${wifiEnabled ? 'translate-x-4' : 'translate-x-0'}`}></div>
              </div>
            </div>
            
            <div className="flex justify-between items-center mb-3 p-2 hover:bg-[#333] rounded">
              <div className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${notificationsEnabled ? 'bg-purple-500' : 'bg-gray-700'}`}>
                  <i className="far fa-bell text-white"></i>
                </div>
                <div>
                  <span className="text-xs font-medium block">Notifications</span>
                  <span className="text-xs text-gray-400">{notificationsEnabled ? 'Enabled' : 'Disabled'}</span>
                </div>
              </div>
              <div 
                className={`w-10 h-6 rounded-full p-1 ${notificationsEnabled ? 'bg-blue-500' : 'bg-gray-700'}`}
                onClick={() => setNotificationsEnabled(!notificationsEnabled)}
              >
                <div className={`w-4 h-4 rounded-full bg-white transform transition-transform ${notificationsEnabled ? 'translate-x-4' : 'translate-x-0'}`}></div>
              </div>
            </div>
            
            <div className="mb-3 p-2 hover:bg-[#333] rounded">
              <div className="flex items-center mb-1">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${!volumeMuted ? 'bg-green-500' : 'bg-gray-700'}`}>
                  <i className={`fas ${volumeMuted ? 'fa-volume-mute' : 'fa-volume-up'} text-white`}></i>
                </div>
                <div className="flex-grow">
                  <span className="text-xs font-medium block">Volume</span>
                  <span className="text-xs text-gray-400">{volumeMuted ? 'Muted' : `${volumeLevel}%`}</span>
                </div>
                <button
                  className="text-gray-400 hover:text-white px-1"
                  onClick={() => setVolumeMuted(!volumeMuted)}
                >
                  <i className={`fas ${volumeMuted ? 'fa-volume-up' : 'fa-volume-mute'} text-xs`}></i>
                </button>
              </div>
              <input 
                type="range" 
                min="0" 
                max="100" 
                value={volumeLevel} 
                disabled={volumeMuted}
                onChange={(e) => setVolumeLevel(parseInt(e.target.value))}
                className="w-full"
              />
            </div>
            
            <div className="mb-3 p-2 hover:bg-[#333] rounded">
              <div className="flex items-center mb-1">
                <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center mr-2">
                  <i className="fas fa-globe text-white"></i>
                </div>
                <div>
                  <span className="text-xs font-medium block">Language</span>
                  <span className="text-xs text-gray-400">
                    {language === 'ENG' ? 'English' : language === 'ESP' ? 'Spanish' : 'French'}
                  </span>
                </div>
              </div>
              <select 
                value={language} 
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full bg-[#333] text-white text-xs p-1 rounded border border-[#444]"
              >
                <option value="ENG">English</option>
                <option value="ESP">Spanish</option>
                <option value="FRA">French</option>
              </select>
            </div>
            
            <div className="mb-3 p-2 hover:bg-[#333] rounded">
              <div className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${securityStatus === 'protected' ? 'bg-green-500' : 'bg-yellow-500'}`}>
                  <i className="fas fa-shield-alt text-white"></i>
                </div>
                <div>
                  <span className="text-xs font-medium block">Security</span>
                  <span className="text-xs text-gray-400">
                    {securityStatus === 'protected' ? 'Protected' : 'Scanning...'}
                  </span>
                </div>
                <button
                  className="ml-auto text-blue-400 hover:text-blue-300 text-xs"
                  onClick={() => setSecurityStatus(securityStatus === 'protected' ? 'scanning' : 'protected')}
                >
                  {securityStatus === 'protected' ? 'Scan Now' : 'Stop'}
                </button>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-2 mt-3">
              <button 
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs py-1.5 rounded flex items-center justify-center"
                onClick={() => {
                  onTaskbarItemClick('terminal');
                  setShowQuickSettings(false);
                }}
              >
                <i className="fas fa-terminal mr-1.5"></i>
                Terminal
              </button>
              <button 
                className="bg-purple-600 hover:bg-purple-700 text-white text-xs py-1.5 rounded flex items-center justify-center"
                onClick={() => {
                  onTaskbarItemClick('dashboard');
                  setShowQuickSettings(false);
                }}
              >
                <i className="fas fa-tachometer-alt mr-1.5"></i>
                Dashboard
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
