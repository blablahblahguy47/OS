import React, { useRef, useState, useEffect } from 'react';
import { useWindowContext } from '@/context/WindowContext';
import { WindowProps } from '@/lib/types';

export default function Window({
  id,
  title,
  icon,
  isOpen,
  isMinimized,
  isMaximized,
  zIndex,
  width = '800px',
  height = '600px',
  x = 50,
  y = 50,
  children,
  onClose,
  onMinimize,
  onMaximize,
  onFocus,
}: WindowProps) {
  const { activeWindowId } = useWindowContext();
  const [position, setPosition] = useState({ x, y });
  const windowRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [preMaximizeState, setPreMaximizeState] = useState({ 
    width, 
    height, 
    x: position.x, 
    y: position.y 
  });
  
  // Don't render if the window is not open
  if (!isOpen) return null;
  
  // Create a hidden div for minimized windows instead of not rendering them at all
  // This ensures we maintain their state even when minimized
  if (isMinimized) {
    return (
      <div 
        style={{ display: 'none' }}
        data-window-id={id}
        data-minimized="true"
      >
        {children}
      </div>
    );
  }
  
  const handleMouseDown = (e: React.MouseEvent) => {
    if (headerRef.current && headerRef.current.contains(e.target as Node)) {
      setIsDragging(true);
      const rect = windowRef.current?.getBoundingClientRect();
      if (rect) {
        setDragOffset({
          x: e.clientX - rect.left,
          y: e.clientY - rect.top
        });
      }
      onFocus();
    }
  };
  
  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging && !isMaximized) {
      const newX = e.clientX - dragOffset.x;
      const newY = e.clientY - dragOffset.y;
      setPosition({ x: newX, y: newY });
    }
  };
  
  const handleMouseUp = () => {
    setIsDragging(false);
  };
  
  // Add and remove event listeners
  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragOffset, isMaximized]);
  
  // Save window state before maximizing and restore on un-maximize
  useEffect(() => {
    if (isMaximized) {
      // Save current state before maximizing
      if (windowRef.current) {
        setPreMaximizeState({
          width: width.toString(),
          height: height.toString(),
          x: position.x,
          y: position.y
        });
      }
    } else {
      // If returning from maximized state, restore previous position
      if (preMaximizeState.width) {
        // Return with a small delay to avoid flickering
        setTimeout(() => {
          setPosition({ x: preMaximizeState.x, y: preMaximizeState.y });
        }, 50);
      }
    }
  }, [isMaximized]);
  
  // Window styles
  const windowStyle: React.CSSProperties = {
    position: 'absolute',
    width: isMaximized ? '100%' : width,
    height: isMaximized ? 'calc(100% - 48px)' : height,
    top: isMaximized ? 0 : position.y,
    left: isMaximized ? 0 : position.x,
    zIndex,
    display: 'flex',
    flexDirection: 'column',
  };
  
  const isActive = activeWindowId === id;
  
  return (
    <div
      ref={windowRef}
      className={`window ${isActive ? 'ring-1 ring-blue-400' : ''}`}
      style={windowStyle}
      onMouseDown={onFocus}
    >
      <div
        ref={headerRef}
        className={`window-header flex items-center justify-between px-3 py-2 ${isActive ? 'bg-win-blue text-white' : 'bg-win-gray-200 text-win-gray-800'}`}
        onMouseDown={handleMouseDown}
        style={{ cursor: 'move' }}
      >
        <div className="flex items-center">
          <i className={`${icon} mr-2`}></i>
          <span className="font-medium">{title}</span>
        </div>
        <div className="flex">
          <button className="window-control minimize" onClick={onMinimize}>
            <i className="fas fa-minus text-sm"></i>
          </button>
          <button className="window-control maximize" onClick={onMaximize}>
            <i className={`fas ${isMaximized ? 'fa-compress' : 'fa-expand'} text-sm`}></i>
          </button>
          <button className="window-control close" onClick={onClose}>
            <i className="fas fa-times text-sm"></i>
          </button>
        </div>
      </div>
      
      <div className="flex-1 bg-white overflow-auto">
        {children}
      </div>
    </div>
  );
}
