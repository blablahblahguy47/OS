import React from 'react';
import { WindowComponents } from '@/lib/types';
import { useProfile } from '@/hooks/use-profile';

interface StartMenuProps {
  onItemClick: (id: WindowComponents) => void;
  onClose: () => void;
}

export default function StartMenu({ onItemClick, onClose }: StartMenuProps) {
  // Use profile hook to update UI when profile settings change
  useProfile();
  
  return (
    <div 
      id="startMenu" 
      className="absolute bottom-12 left-0 w-80 bg-[#202020] text-white rounded-tr-md z-20"
    >
      {/* User Profile */}
      <div className="p-4 flex items-center border-b border-gray-700">
        <div 
          className="w-10 h-10 rounded-full bg-no-repeat bg-cover bg-center mr-3"
          style={{ backgroundImage: 'var(--user-profile-image)' }}
        ></div>
        <div>
          <div className="font-medium username" data-username="var(--user-name)">
            <span id="profile-username">Admin</span>
          </div>
          <div className="text-xs text-gray-400">Hospital OS User</div>
        </div>
      </div>
      
      {/* Most Used */}
      <div className="p-2">
        <div className="text-xs text-gray-400 pl-2 pb-1">MOST USED</div>
        <div className="grid grid-cols-3 gap-1">
          <div 
            className="p-2 rounded flex flex-col items-center cursor-pointer hover:bg-white hover:bg-opacity-10"
            onClick={() => onItemClick('dashboard')}
          >
            <div className="w-10 h-10 rounded bg-win-blue flex items-center justify-center mb-1">
              <i className="fas fa-hospital text-xl"></i>
            </div>
            <span className="text-xs">Dashboard</span>
          </div>
          
          <div 
            className="p-2 rounded flex flex-col items-center cursor-pointer hover:bg-white hover:bg-opacity-10"
            onClick={() => onItemClick('patients')}
          >
            <div className="w-10 h-10 rounded bg-win-green flex items-center justify-center mb-1">
              <i className="fas fa-user-injured text-xl"></i>
            </div>
            <span className="text-xs">Patients</span>
          </div>
          
          <div 
            className="p-2 rounded flex flex-col items-center cursor-pointer hover:bg-white hover:bg-opacity-10"
            onClick={() => onItemClick('patientform')}
          >
            <div className="w-10 h-10 rounded bg-green-600 flex items-center justify-center mb-1">
              <i className="fas fa-user-plus text-xl"></i>
            </div>
            <span className="text-xs">New Patient</span>
          </div>
          
          <div 
            className="p-2 rounded flex flex-col items-center cursor-pointer hover:bg-white hover:bg-opacity-10"
            onClick={() => onItemClick('appointments')}
          >
            <div className="w-10 h-10 rounded bg-win-orange flex items-center justify-center mb-1">
              <i className="far fa-calendar-alt text-xl"></i>
            </div>
            <span className="text-xs">Schedule</span>
          </div>
          
          <div 
            className="p-2 rounded flex flex-col items-center cursor-pointer hover:bg-white hover:bg-opacity-10"
            onClick={() => onItemClick('emergency')}
          >
            <div className="w-10 h-10 rounded bg-win-red flex items-center justify-center mb-1">
              <i className="fas fa-ambulance text-xl"></i>
            </div>
            <span className="text-xs">Emergency</span>
          </div>
          
          <div 
            className="p-2 rounded flex flex-col items-center cursor-pointer hover:bg-white hover:bg-opacity-10"
            onClick={() => onItemClick('inventory')}
          >
            <div className="w-10 h-10 rounded bg-win-gray-500 flex items-center justify-center mb-1">
              <i className="fas fa-pills text-xl"></i>
            </div>
            <span className="text-xs">Pharmacy</span>
          </div>
          
          <div 
            className="p-2 rounded flex flex-col items-center cursor-pointer hover:bg-white hover:bg-opacity-10"
            onClick={() => onItemClick('lab')}
          >
            <div className="w-10 h-10 rounded bg-[#0078D7] flex items-center justify-center mb-1">
              <i className="fas fa-microscope text-xl"></i>
            </div>
            <span className="text-xs">Lab Results</span>
          </div>
          
          <div 
            className="p-2 rounded flex flex-col items-center cursor-pointer hover:bg-white hover:bg-opacity-10"
            onClick={() => onItemClick('files')}
          >
            <div className="w-10 h-10 rounded bg-yellow-500 flex items-center justify-center mb-1">
              <i className="fas fa-folder text-xl"></i>
            </div>
            <span className="text-xs">Files</span>
          </div>
        </div>
      </div>
      
      {/* All Apps Section */}
      <div className="p-2 border-t border-gray-700">
        <div className="text-xs text-gray-400 pl-2 pb-1">ALL APPS</div>
        <div className="h-48 overflow-y-auto scrollbar">
          <div className="grid grid-cols-1 gap-1">
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('dashboard')}
            >
              <div className="w-8 h-8 rounded bg-win-blue flex items-center justify-center mr-3">
                <i className="fas fa-hospital-alt"></i>
              </div>
              <span className="text-sm">Hospital Dashboard</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('patients')}
            >
              <div className="w-8 h-8 rounded bg-win-green flex items-center justify-center mr-3">
                <i className="fas fa-user-injured"></i>
              </div>
              <span className="text-sm">Patient Records</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('patientform')}
            >
              <div className="w-8 h-8 rounded bg-green-600 flex items-center justify-center mr-3">
                <i className="fas fa-user-plus"></i>
              </div>
              <span className="text-sm">New Patient Registration</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('appointments')}
            >
              <div className="w-8 h-8 rounded bg-win-orange flex items-center justify-center mr-3">
                <i className="far fa-calendar-alt"></i>
              </div>
              <span className="text-sm">Appointment Scheduler</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('staff')}
            >
              <div className="w-8 h-8 rounded bg-win-gray-500 flex items-center justify-center mr-3">
                <i className="fas fa-user-md"></i>
              </div>
              <span className="text-sm">Staff Directory</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('inventory')}
            >
              <div className="w-8 h-8 rounded bg-win-red flex items-center justify-center mr-3">
                <i className="fas fa-stethoscope"></i>
              </div>
              <span className="text-sm">Medical Equipment</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('inventory')}
            >
              <div className="w-8 h-8 rounded bg-[#0078D7] flex items-center justify-center mr-3">
                <i className="fas fa-pills"></i>
              </div>
              <span className="text-sm">Pharmacy System</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('emergency')}
            >
              <div className="w-8 h-8 rounded bg-win-green flex items-center justify-center mr-3">
                <i className="fas fa-ambulance"></i>
              </div>
              <span className="text-sm">Emergency Response</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('terminal')}
            >
              <div className="w-8 h-8 rounded bg-win-dark flex items-center justify-center mr-3">
                <i className="fas fa-terminal"></i>
              </div>
              <span className="text-sm">System Terminal</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('taskmanager')}
            >
              <div className="w-8 h-8 rounded bg-purple-600 flex items-center justify-center mr-3">
                <i className="fas fa-tasks"></i>
              </div>
              <span className="text-sm">Task Manager</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('settings')}
            >
              <div className="w-8 h-8 rounded bg-gray-500 flex items-center justify-center mr-3">
                <i className="fas fa-cog"></i>
              </div>
              <span className="text-sm">System Settings</span>
            </div>
            
            <div 
              className="flex items-center p-2 hover:bg-opacity-10 hover:bg-white rounded cursor-pointer"
              onClick={() => onItemClick('files')}
            >
              <div className="w-8 h-8 rounded bg-yellow-500 flex items-center justify-center mr-3">
                <i className="fas fa-folder"></i>
              </div>
              <span className="text-sm">File Explorer</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Bottom Controls */}
      <div className="flex border-t border-gray-700 p-2">
        <button 
          className="p-2 rounded hover:bg-opacity-10 hover:bg-white"
          onClick={() => onItemClick('settings')}
        >
          <i className="fas fa-cog"></i>
        </button>
        <button className="p-2 rounded hover:bg-opacity-10 hover:bg-white">
          <i className="fas fa-power-off"></i>
        </button>
      </div>
    </div>
  );
}
