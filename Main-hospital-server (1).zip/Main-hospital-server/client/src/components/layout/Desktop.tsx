import React, { useState, useEffect } from 'react';
import { useWindowContext } from '@/context/WindowContext';
import Taskbar from './Taskbar';
import StartMenu from './StartMenu';
import Window from './Window';
import DesktopIcon from './DesktopIcon';
import { WindowComponents } from '@/lib/types';

interface DesktopProps {
  isFirstTimeUser?: boolean;
  setupWindowOpen?: boolean;
}

export default function Desktop({ isFirstTimeUser = false, setupWindowOpen = false }: DesktopProps) {
  const { windows, openWindow, closeWindow, minimizeWindow, maximizeWindow, focusWindow, addWindowIfNotExists, desktopIcons } = useWindowContext();
  const [startMenuOpen, setStartMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [mockCode, setMockCode] = useState<string[]>([]);
  
  // Mock code generation
  const generateMockCode = () => {
    const codeLines = [
      "Initializing hospital kernel v3.15.2...",
      "Loading core dependencies...",
      "import medicalSystems from 'hospital-core'",
      "Starting patient database...",
      "MongoDB connected: hospital-db-cluster-1",
      "Loading user authentication module...",
      "Starting diagnostic subsystems...",
      "Loading staff scheduler v2.5.1...",
      "function authenticateUser(credentials) {",
      "  return secureAuth.verify(credentials);",
      "}",
      "Establishing base64 connection...",
      "Connected to secure endpoint via TLS 1.3",
      "Encryption handshake complete",
      "Base64 channel ready: dGhpcyBpcyBhbiBleGFtcGxlIGVuY3J5cHRlZCBzdHJpbmc=",
      "Importing patient data modules...",
      "class PatientRecord extends BaseRecord {",
      "  constructor(data) {",
      "    super(data);",
      "    this.medicalHistory = [];",
      "    this.behaviorsObserved = [];",
      "    this.mentalStateEvaluation = {};",
      "  }",
      "  addBehaviorNote(note, observer, timestamp) {",
      "    this.behaviorsObserved.push({note, observer, timestamp});",
      "  }",
      "}",
      "Initializing emergency response system...",
      "Starting secure API endpoints...",
      "const app = express();",
      "app.use(cors());",
      "app.use(bodyParser.json());",
      "Setting up department connections...",
      "Building staff registry cache...",
      "Loading medical inventory system...",
      "await Promise.all(systemModules.map(m => m.initialize()))",
      "Connecting to lab results database...",
      "Setting up pharmacy interface...",
      "Starting security protocols...",
      "Running system diagnostics...",
      "Setting up appointment scheduler...",
      "function calculateMedicationDosage(weight, age) {",
      "  const baseDose = weight * 0.75;",
      "  return age < 12 ? baseDose * 0.5 : baseDose;",
      "}",
      "function analyzePatientBehavior(notes) {",
      "  return notes.map(note => {",
      "    return { severity: calculateSeverity(note), urgency: determineUrgency(note) };",
      "  });",
      "}",
      "Loading psychiatric evaluation modules...",
      "function evaluateMentalState(patientId, observations) {",
      "  const patterns = detectBehavioralPatterns(observations);",
      "  return {",
      "    state: determineState(patterns),",
      "    riskLevel: calculateRisk(patterns),",
      "    recommendedAction: generateRecommendation(patterns)",
      "  };",
      "}",
      "Starting reporting module...",
      "Initializing medical imaging system...",
      "Loading discharge document templates...",
      "Initializing behavior tracking system...",
      "Starting monitoring services...",
      "Setting up patient activity logging...",
      "Preparing observation modules...",
      "All systems ready for startup sequence..."
    ];
    
    return codeLines;
  };

  // Loading state to simulate system startup
  useEffect(() => {
    const allCode = generateMockCode();
    let startTime = Date.now();
    const totalLoadTime = 12000; // 12 seconds loading screen (longer as requested)
    let codeIndex = 0;
    let codeContainer: HTMLDivElement | null = null;
    
    // Function to scroll to bottom of code container
    const scrollToBottom = () => {
      if (codeContainer) {
        codeContainer.scrollTop = codeContainer.scrollHeight;
      }
    };
    
    // Get reference to code container
    setTimeout(() => {
      codeContainer = document.getElementById('code-container') as HTMLDivElement;
    }, 100);
    
    // Random base64 string generator
    const generateBase64 = () => {
      const base64Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
      let base64String = '';
      
      for (let i = 0; i < 40 + Math.floor(Math.random() * 20); i++) {
        base64String += base64Chars.charAt(Math.floor(Math.random() * base64Chars.length));
      }
      
      return base64String;
    };
    
    // Add base64 connection messages occasionally
    const base64Interval = setInterval(() => {
      if (codeIndex > 10 && Math.random() > 0.6) {
        const connectionType = Math.random() > 0.5 ? 'Establishing' : 'Verifying';
        const base64Message = `${connectionType} secure base64 connection: ${generateBase64()}`;
        
        setMockCode(prev => [...prev, base64Message]);
        
        // Add an encrypted patient behavior report sometimes
        if (Math.random() > 0.7) {
          setTimeout(() => {
            setMockCode(prev => [...prev, 
              "Decoding patient behavior report...",
              `Patient behavioral data: ${generateBase64()}`,
              `Observation log: ${generateBase64()}`,
              "Analysis complete: patient exhibits normal behavior patterns",
              "Archiving report to secure storage..."
            ]);
            // Scroll to bottom after adding report
            setTimeout(scrollToBottom, 10);
          }, 300);
        }
        
        // Scroll to bottom after adding base64 content
        setTimeout(scrollToBottom, 10);
      }
    }, 1200);
    
    // Add code lines at varying speeds to simulate real terminal output
    const codeInterval = setInterval(() => {
      if (codeIndex < allCode.length) {
        // Variable speed - sometimes fast, sometimes slow
        const fastMode = Math.random() > 0.7;
        
        // Add 1-3 lines at once for burst effect
        const linesToAdd = Math.min(
          fastMode ? Math.floor(Math.random() * 3) + 2 : 1, 
          allCode.length - codeIndex
        );
        
        const newLines: string[] = [];
        for (let i = 0; i < linesToAdd; i++) {
          if (codeIndex < allCode.length) {
            newLines.push(allCode[codeIndex]);
            codeIndex++;
          }
        }
        
        setMockCode(prev => [...prev, ...newLines]);
        
        // Scroll to bottom after adding new lines
        setTimeout(scrollToBottom, 10);
      }
    }, Math.random() > 0.7 ? 80 : 180); // Variable speed - sometimes fast, sometimes slow
    
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, (elapsed / totalLoadTime) * 100);
      setLoadingProgress(progress);
      
      if (progress >= 100) {
        clearInterval(interval);
        clearInterval(codeInterval);
        clearInterval(base64Interval);
        setLoading(false);
      }
    }, 50);
    
    return () => {
      clearInterval(interval);
      clearInterval(codeInterval);
      clearInterval(base64Interval);
    };
  }, []);

  const toggleStartMenu = () => {
    setStartMenuOpen(prev => !prev);
  };

  const closeStartMenu = () => {
    setStartMenuOpen(false);
  };

  const handleDesktopIconClick = (windowId: WindowComponents) => {
    console.log(`Desktop icon clicked: ${windowId}`);
    // Reset workflow to ensure fresh state
    if (windows.some(w => w.id === windowId)) {
      // If already exists, just focus it
      openWindow(windowId);
    } else {
      // Create the window if it doesn't exist
      const added = addWindowIfNotExists(windowId);
      console.log(`Added window: ${added}`);
      if (added) {
        // Now open it
        openWindow(windowId);
      }
    }
    closeStartMenu();
  };

  const handleTaskbarItemClick = (windowId: WindowComponents) => {
    const windowExists = windows.some(w => w.id === windowId);
    
    if (windowExists) {
      const window = windows.find(w => w.id === windowId);
      if (window?.isMinimized) {
        openWindow(windowId);
      } else if (window?.isOpen) {
        minimizeWindow(windowId);
      }
    } else {
      addWindowIfNotExists(windowId);
      openWindow(windowId);
    }
    
    closeStartMenu();
  };

  // No auto-opening windows on startup as per user request

  // Force open the files window for first-time users for setup
  useEffect(() => {
    if (!loading && isFirstTimeUser && setupWindowOpen) {
      // Auto-open the files window for first-time setup
      if (!windows.some(w => w.id === 'files')) {
        addWindowIfNotExists('files');
        setTimeout(() => {
          openWindow('files');
        }, 300);
      }
    }
  }, [loading, isFirstTimeUser, setupWindowOpen, windows, addWindowIfNotExists, openWindow]);

  // Handle clicks outside the start menu to close it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const startButton = document.getElementById('startButton');
      const startMenu = document.getElementById('startMenu');
      
      if (startMenuOpen && 
          startButton && 
          startMenu && 
          !startButton.contains(event.target as Node) && 
          !startMenu.contains(event.target as Node)) {
        setStartMenuOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [startMenuOpen]);

  return (
    <div className="h-screen flex flex-col">
      {loading ? (
        /* Loading Screen */
        <div className="h-screen w-full bg-black flex">
          {/* Left panel - System code */}
          <div className="w-1/2 h-full p-4 overflow-hidden flex flex-col">
            <div 
              id="code-container"
              className="text-green-500 text-xs font-mono overflow-auto flex-1 pr-2" 
              style={{ fontFamily: 'monospace' }}
            >
              <div className="flex flex-col items-start">
                {mockCode.map((line, index) => (
                  <div key={index} className="mb-1 whitespace-nowrap">
                    {line}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="animate-pulse">
              <span className="text-green-500 text-xl font-bold">▮</span>
            </div>
          </div>
          
          {/* Right panel - Logo and progress */}
          <div className="w-1/2 h-full flex flex-col items-center justify-center">
            <div className="text-win-blue text-5xl mb-2 font-semibold">
              <i className="fas fa-hospital-alt"></i>
            </div>
            <div className="text-white text-3xl mb-8 font-semibold">Hospital OS</div>
            <div className="w-64 h-4 bg-gray-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-win-blue rounded-full transition-all duration-300 ease-in-out"
                style={{ width: `${loadingProgress}%` }}
              ></div>
            </div>
            <div className="text-white mt-4 text-sm flex items-center">
              <div className="animate-spin mr-2 text-win-blue">
                <i className="fas fa-circle-notch"></i>
              </div>
              {loadingProgress < 30 && "Initializing system components..."}
              {loadingProgress >= 30 && loadingProgress < 60 && "Loading hospital modules..."}
              {loadingProgress >= 60 && loadingProgress < 90 && "Connecting to services..."}
              {loadingProgress >= 90 && "Preparing desktop environment..."}
            </div>
            
            <div className="flex space-x-4 mt-16 text-gray-600 text-xl">
              <i className="fas fa-user-md"></i>
              <i className="fas fa-pills"></i>
              <i className="fas fa-heartbeat"></i>
              <i className="fas fa-stethoscope"></i>
              <i className="fas fa-ambulance"></i>
            </div>
            
            <div className="text-gray-500 mt-4 text-xs">© 2025 Hospital OS Corp.</div>
            <div className="text-gray-700 text-xs mt-1">Version 1.0.2</div>
          </div>
        </div>
      ) : (
        <>
          {/* Desktop */}
          <div className="flex-1 relative overflow-hidden" id="desktop">
            {/* Desktop Icons */}
            <div className="absolute top-4 left-4 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-6 gap-y-10">
              {desktopIcons.map(iconId => {
                let icon = '';
                let label = '';
                let bgColor = '';
                
                switch(iconId) {
                  case 'dashboard':
                    icon = 'fas fa-hospital';
                    label = 'Hospital Dashboard';
                    bgColor = 'bg-win-blue';
                    break;
                  case 'patients':
                    icon = 'fas fa-user-injured';
                    label = 'Patient Records';
                    bgColor = 'bg-win-blue';
                    break;
                  case 'appointments':
                    icon = 'far fa-calendar-alt';
                    label = 'Appointments';
                    bgColor = 'bg-win-green';
                    break;
                  case 'staff':
                    icon = 'fas fa-user-md';
                    label = 'Staff Portal';
                    bgColor = 'bg-win-orange';
                    break;
                  case 'inventory':
                    icon = 'fas fa-pills';
                    label = 'Inventory';
                    bgColor = 'bg-win-gray-500';
                    break;
                  case 'reports':
                    icon = 'fas fa-chart-bar';
                    label = 'Reports';
                    bgColor = 'bg-win-red';
                    break;
                  case 'emergency':
                    icon = 'fas fa-ambulance';
                    label = 'Emergency';
                    bgColor = 'bg-win-red';
                    break;
                  case 'lab':
                    icon = 'fas fa-microscope';
                    label = 'Laboratory';
                    bgColor = 'bg-win-blue';
                    break;
                  case 'patientform':
                    icon = 'fas fa-user-plus';
                    label = 'New Patient';
                    bgColor = 'bg-green-600';
                    break;
                  case 'terminal':
                    icon = 'fas fa-terminal';
                    label = 'Terminal';
                    bgColor = 'bg-win-dark';
                    break;
                  case 'taskmanager':
                    icon = 'fas fa-tasks';
                    label = 'Task Manager';
                    bgColor = 'bg-purple-600';
                    break;
                  case 'settings':
                    icon = 'fas fa-cog';
                    label = 'Settings';
                    bgColor = 'bg-gray-500';
                    break;
                  case 'adminpanel':
                    icon = 'fas fa-lock';
                    label = 'Admin Panel';
                    bgColor = 'bg-gray-800';
                    break;
                  default:
                    icon = 'fas fa-window-maximize';
                    label = 'Application';
                    bgColor = 'bg-win-blue';
                }
                
                return (
                  <DesktopIcon
                    key={iconId}
                    id={iconId}
                    icon={icon}
                    label={label}
                    bgColor={bgColor}
                    onClick={() => handleDesktopIconClick(iconId)}
                  />
                );
              })}
            </div>
            
            {/* Windows */}
            {windows.map(window => (
              <Window
                key={window.id}
                id={window.id}
                title={window.title}
                icon={window.icon}
                isOpen={window.isOpen}
                isMinimized={window.isMinimized}
                isMaximized={window.isMaximized}
                zIndex={window.zIndex}
                width={window.width}
                height={window.height}
                x={window.x}
                y={window.y}
                onClose={() => closeWindow(window.id)}
                onMinimize={() => minimizeWindow(window.id)}
                onMaximize={() => maximizeWindow(window.id)}
                onFocus={() => focusWindow(window.id)}
              >
                {window.component}
              </Window>
            ))}
          </div>
          
          {/* Start Menu */}
          {startMenuOpen && (
            <StartMenu 
              onItemClick={handleDesktopIconClick}
              onClose={closeStartMenu}
            />
          )}
          
          {/* Taskbar */}
          <Taskbar 
            startMenuOpen={startMenuOpen}
            onStartButtonClick={toggleStartMenu}
            onTaskbarItemClick={handleTaskbarItemClick}
            windows={windows}
          />
        </>
      )}
    </div>
  );
}
