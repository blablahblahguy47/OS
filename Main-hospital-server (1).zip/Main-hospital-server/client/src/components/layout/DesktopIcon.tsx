import React from 'react';
import { DesktopIconProps } from '@/lib/types';

export default function DesktopIcon({ id, icon, label, bgColor, onClick }: DesktopIconProps) {
  return (
    <div className="desktop-icon w-20 p-2 rounded flex flex-col items-center cursor-pointer" onClick={onClick}>
      <div className={`${bgColor} bg-opacity-90 text-white rounded-sm p-2 mb-1 w-full flex justify-center`}>
        <i className={`${icon} text-xl`}></i>
      </div>
      <span className="text-xs text-white text-center drop-shadow-md line-clamp-2">{label}</span>
    </div>
  );
}
