import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Inventory } from '@shared/schema';
import InventoryForm from './InventoryForm';
import { formatDate } from '@/lib/data';

export default function InventoryWindow() {
  const queryClient = useQueryClient();
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [currentItem, setCurrentItem] = useState<Inventory | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  
  // Fetch inventory
  const { data: inventory, isLoading } = useQuery<Inventory[]>({
    queryKey: ['/api/inventory'],
  });
  
  const deleteItemMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/inventory/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
    }
  });
  
  const handleAddNew = () => {
    setCurrentItem(null);
    setIsAddingItem(true);
  };
  
  const handleEdit = (item: Inventory) => {
    setCurrentItem(item);
    setIsAddingItem(true);
  };
  
  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this inventory item?')) {
      deleteItemMutation.mutate(id);
    }
  };
  
  const handleFormClose = () => {
    setIsAddingItem(false);
    setCurrentItem(null);
  };
  
  const handleFormSubmit = () => {
    setIsAddingItem(false);
    setCurrentItem(null);
    queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
  };
  
  // Filter inventory based on search and category filter
  const filteredInventory = inventory?.filter(item => {
    const matchesSearch = 
      searchTerm === '' || 
      item.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.supplier && item.supplier.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (item.location && item.location.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  }) || [];
  
  // Check for low stock items
  const lowStockItems = inventory?.filter(item => 
    item.reorderLevel && item.quantity <= item.reorderLevel
  ) || [];
  
  // Check for expiring items
  const today = new Date();
  const thirtyDaysFromNow = new Date();
  thirtyDaysFromNow.setDate(today.getDate() + 30);
  
  const expiringItems = inventory?.filter(item => 
    item.expiryDate && 
    new Date(item.expiryDate) <= thirtyDaysFromNow && 
    new Date(item.expiryDate) >= today
  ) || [];
  
  // Group items by category
  const itemsByCategory = filteredInventory.reduce((acc, item) => {
    const category = item.category;
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(item);
    return acc;
  }, {} as Record<string, Inventory[]>);
  
  // Calculate total inventory value
  const totalValue = inventory?.reduce((sum, item) => {
    return sum + (item.cost || 0) * item.quantity;
  }, 0) || 0;
  
  // Get icon for category
  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'medication': return 'fas fa-pills';
      case 'equipment': return 'fas fa-stethoscope';
      case 'supplies': return 'fas fa-box';
      default: return 'fas fa-box';
    }
  };
  
  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <div className="w-56 bg-win-gray-100 border-r border-win-gray-300 p-2">
        <div className="mb-6">
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">CATEGORIES</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={() => setCategoryFilter('all')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${categoryFilter === 'all' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-boxes w-5"></i>
                <span>All Items ({inventory?.length || 0})</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setCategoryFilter('medication')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${categoryFilter === 'medication' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-pills w-5"></i>
                <span>Medications</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setCategoryFilter('equipment')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${categoryFilter === 'equipment' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-stethoscope w-5"></i>
                <span>Equipment</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setCategoryFilter('supplies')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${categoryFilter === 'supplies' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-box w-5"></i>
                <span>Supplies</span>
              </button>
            </li>
          </ul>
        </div>
        
        <div className="mb-6">
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">ALERTS</div>
          <ul>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-exclamation-triangle text-win-orange w-5"></i>
                <span>Low Stock ({lowStockItems.length})</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-clock text-win-red w-5"></i>
                <span>Expiring Soon ({expiringItems.length})</span>
              </button>
            </li>
          </ul>
        </div>
        
        <div>
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">ACTIONS</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={handleAddNew} 
                className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200"
              >
                <i className="fas fa-plus w-5"></i>
                <span>Add New Item</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-file-export w-5"></i>
                <span>Export Inventory</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-truck w-5"></i>
                <span>Order Supplies</span>
              </button>
            </li>
          </ul>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 p-4 overflow-auto scrollbar">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold mb-1">Inventory Management</h1>
            <p className="text-win-gray-500">Track and manage hospital inventory and supplies</p>
          </div>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search inventory..." 
              className="pl-10 pr-4 py-2 rounded border border-win-gray-300 focus:outline-none focus:border-win-blue focus:ring-1 focus:ring-win-blue w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-win-gray-500"></i>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
            <div className="flex items-center mb-2">
              <div className="w-10 h-10 bg-win-blue bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                <i className="fas fa-boxes text-win-blue"></i>
              </div>
              <span className="text-win-gray-500">Total Items</span>
            </div>
            <div className="text-2xl font-semibold">{inventory?.length || 0}</div>
          </div>
          
          <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
            <div className="flex items-center mb-2">
              <div className="w-10 h-10 bg-win-green bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                <i className="fas fa-dollar-sign text-win-green"></i>
              </div>
              <span className="text-win-gray-500">Total Value</span>
            </div>
            <div className="text-2xl font-semibold">${(totalValue / 100).toFixed(2)}</div>
          </div>
          
          <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
            <div className="flex items-center mb-2">
              <div className="w-10 h-10 bg-win-orange bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                <i className="fas fa-exclamation-triangle text-win-orange"></i>
              </div>
              <span className="text-win-gray-500">Low Stock Items</span>
            </div>
            <div className="text-2xl font-semibold">{lowStockItems.length}</div>
          </div>
          
          <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
            <div className="flex items-center mb-2">
              <div className="w-10 h-10 bg-win-red bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                <i className="fas fa-clock text-win-red"></i>
              </div>
              <span className="text-win-gray-500">Expiring Soon</span>
            </div>
            <div className="text-2xl font-semibold">{expiringItems.length}</div>
          </div>
        </div>
        
        {/* Inventory List */}
        <div className="bg-white rounded shadow-sm border border-win-gray-200 mb-6">
          <div className="px-4 py-3 border-b border-win-gray-200 flex justify-between items-center">
            <h2 className="font-semibold">
              {categoryFilter === 'all' ? 'All Inventory Items' : 
               `${categoryFilter.charAt(0).toUpperCase() + categoryFilter.slice(1)} Items`}
            </h2>
            <div className="flex space-x-2">
              <button 
                onClick={handleAddNew}
                className="px-3 py-1 text-sm rounded bg-win-blue text-white"
              >
                <i className="fas fa-plus mr-1"></i> Add Item
              </button>
              <button className="px-3 py-1 text-sm rounded border border-win-gray-300 hover:bg-win-gray-100">
                <i className="fas fa-filter"></i>
              </button>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-win-blue"></div>
            </div>
          ) : filteredInventory.length === 0 ? (
            <p className="text-center py-8 text-win-gray-500">No inventory items found</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="text-left text-sm text-win-gray-500 border-b border-win-gray-200">
                    <th className="px-4 py-3 font-medium">Item Name</th>
                    <th className="px-4 py-3 font-medium">Category</th>
                    <th className="px-4 py-3 font-medium">Quantity</th>
                    <th className="px-4 py-3 font-medium">Unit</th>
                    <th className="px-4 py-3 font-medium">Reorder Level</th>
                    <th className="px-4 py-3 font-medium">Cost</th>
                    <th className="px-4 py-3 font-medium">Location</th>
                    <th className="px-4 py-3 font-medium">Expiry Date</th>
                    <th className="px-4 py-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredInventory.map(item => (
                    <tr key={item.id} className={`border-b border-win-gray-200 hover:bg-win-gray-50 text-sm ${
                      (item.reorderLevel && item.quantity <= item.reorderLevel) ? 'bg-red-50' : ''
                    }`}>
                      <td className="px-4 py-3">
                        <div className="flex items-center">
                          <i className={`${getCategoryIcon(item.category)} mr-2 text-win-gray-500`}></i>
                          <span>{item.itemName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">{item.category.charAt(0).toUpperCase() + item.category.slice(1)}</td>
                      <td className="px-4 py-3">
                        {item.reorderLevel && item.quantity <= item.reorderLevel ? (
                          <span className="text-win-red font-medium">{item.quantity}</span>
                        ) : (
                          item.quantity
                        )}
                      </td>
                      <td className="px-4 py-3">{item.unit || 'N/A'}</td>
                      <td className="px-4 py-3">{item.reorderLevel || 'N/A'}</td>
                      <td className="px-4 py-3">{item.cost ? `$${(item.cost / 100).toFixed(2)}` : 'N/A'}</td>
                      <td className="px-4 py-3">{item.location || 'N/A'}</td>
                      <td className="px-4 py-3">
                        {item.expiryDate ? (
                          new Date(item.expiryDate) <= thirtyDaysFromNow && new Date(item.expiryDate) >= today ? (
                            <span className="text-win-orange font-medium">{formatDate(new Date(item.expiryDate))}</span>
                          ) : (
                            formatDate(new Date(item.expiryDate))
                          )
                        ) : (
                          'N/A'
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => handleEdit(item)} 
                            className="text-win-blue hover:underline"
                          >
                            <i className="fas fa-edit"></i>
                          </button>
                          <button 
                            onClick={() => handleDelete(item.id)} 
                            className="text-win-red hover:underline"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        
        {/* Category Overview */}
        <div className="bg-white rounded shadow-sm border border-win-gray-200">
          <div className="px-4 py-3 border-b border-win-gray-200">
            <h2 className="font-semibold">Inventory by Category</h2>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.entries(itemsByCategory).map(([category, items]) => (
                <div key={category} className="border border-win-gray-200 rounded p-3">
                  <div className="flex items-center mb-3">
                    <div className="w-8 h-8 rounded-full bg-win-blue bg-opacity-10 flex items-center justify-center mr-2 text-win-blue">
                      <i className={getCategoryIcon(category)}></i>
                    </div>
                    <h3 className="font-medium text-win-gray-800">
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </h3>
                  </div>
                  <div className="text-sm text-win-gray-500 mb-2">
                    {items.length} items
                  </div>
                  <div>
                    {items.slice(0, 3).map(item => (
                      <div key={item.id} className="flex justify-between text-sm py-1 border-t border-win-gray-200">
                        <span>{item.itemName}</span>
                        <span className={item.reorderLevel && item.quantity <= item.reorderLevel ? 'text-win-red font-medium' : ''}>
                          {item.quantity} {item.unit}
                        </span>
                      </div>
                    ))}
                    {items.length > 3 && (
                      <div className="text-sm text-win-blue mt-2">
                        +{items.length - 3} more items
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* Inventory Form Modal */}
      {isAddingItem && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-md w-[700px] max-h-[90vh] overflow-auto">
            <InventoryForm 
              item={currentItem}
              onClose={handleFormClose}
              onSubmit={handleFormSubmit}
            />
          </div>
        </div>
      )}
    </div>
  );
}
