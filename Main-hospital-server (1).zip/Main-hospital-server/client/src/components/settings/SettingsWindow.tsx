import React, { useState, useEffect } from 'react';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Slider 
} from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { useWindowContext } from '@/context/WindowContext';
import { WindowComponents } from '@/lib/types';

// Predefined background colors
const backgroundColors = [
  { name: 'Default Blue', value: '#0078d7' },
  { name: 'Windows 11 Purple', value: '#4c2882' },
  { name: 'Professional Black', value: '#202020' },
  { name: 'Calm Green', value: '#2d7d46' },
  { name: 'Classic Teal', value: '#008080' },
  { name: 'Dark Navy', value: '#1a2b47' },
  { name: 'Medical Blue', value: '#3498db' },
  { name: 'Hospital Green', value: '#27ae60' },
];

// Predefined background images
const backgroundImages = [
  { name: 'None', value: 'none' },
  { name: 'Hospital Facade', value: 'url(/backgrounds/hospital.svg)' },
  { name: 'Medical Abstract', value: 'url(/backgrounds/medical.svg)' },
  { name: 'Waves', value: 'url(/backgrounds/waves.svg)' },
  { name: 'Gradient', value: 'url(/backgrounds/gradient.svg)' },
];

export default function SettingsWindow() {
  const { desktopIcons, setDesktopIcons } = useWindowContext();
  
  // Settings state
  const [settings, setSettings] = useState({
    background: {
      type: 'color',
      color: '#0078d7',
      image: 'none',
      opacity: 1,
    },
    appearance: {
      theme: 'light',
      accentColor: '#0078d7',
      transparency: true,
      animations: true,
      blur: true,
    },
    personalization: {
      userName: 'Admin',
      profileImage: '/assets/user.svg',
      showClock: true,
      showDate: true,
      use24HourFormat: false,
    },
    system: {
      startupSound: true,
      notificationSounds: true,
      autoSave: true,
      autoUpdate: true,
    }
  });

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('hospitalOS_settings');
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
        applySettings(JSON.parse(savedSettings));
      } catch (e) {
        console.error("Failed to parse settings:", e);
      }
    }
  }, []);

  // Apply settings to the DOM
  const applySettings = (newSettings: typeof settings) => {
    const root = document.documentElement;
    
    // Apply background
    if (newSettings.background.type === 'color') {
      root.style.setProperty('--desktop-background', newSettings.background.color);
      root.style.setProperty('--desktop-background-image', 'none');
    } else {
      root.style.setProperty('--desktop-background', 'transparent');
      root.style.setProperty('--desktop-background-image', newSettings.background.image);
    }
    
    // Apply background opacity
    root.style.setProperty('--desktop-background-opacity', newSettings.background.opacity.toString());
    
    // Apply accent color
    root.style.setProperty('--accent-color', newSettings.appearance.accentColor);
    
    // Apply theme
    document.body.className = newSettings.appearance.theme === 'dark' ? 'dark' : 'light';
    
    // Apply effects
    root.style.setProperty('--use-blur', newSettings.appearance.blur ? '1' : '0');
    root.style.setProperty('--use-transparency', newSettings.appearance.transparency ? '1' : '0');
    root.style.setProperty('--use-animations', newSettings.appearance.animations ? '1' : '0');
    
    // Apply personalization
    root.style.setProperty('--user-profile-image', `url(${newSettings.personalization.profileImage})`);
    root.style.setProperty('--user-name', `'${newSettings.personalization.userName}'`);
  };

  // Save and apply settings
  const saveSettings = () => {
    localStorage.setItem('hospitalOS_settings', JSON.stringify(settings));
    applySettings(settings);
  };

  // Reset to defaults
  const resetSettings = () => {
    const defaultSettings = {
      background: {
        type: 'color',
        color: '#0078d7',
        image: 'none',
        opacity: 1,
      },
      appearance: {
        theme: 'light',
        accentColor: '#0078d7',
        transparency: true,
        animations: true,
        blur: true,
      },
      personalization: {
        userName: 'Admin',
        profileImage: '/assets/user.svg',
        showClock: true,
        showDate: true,
        use24HourFormat: false,
      },
      system: {
        startupSound: true,
        notificationSounds: true,
        autoSave: true,
        autoUpdate: true,
      }
    };
    setSettings(defaultSettings);
    applySettings(defaultSettings);
    localStorage.setItem('hospitalOS_settings', JSON.stringify(defaultSettings));
  };
  
  // Full system reset/wipe function
  const resetSystem = () => {
    // Clear all localStorage items
    localStorage.clear();
    
    // Reset specific settings with defaults
    localStorage.setItem('hospitalOS_settings', JSON.stringify({
      background: {
        type: 'color',
        color: '#0078d7',
        image: 'none',
        opacity: 1,
      },
      appearance: {
        theme: 'light',
        accentColor: '#0078d7',
        transparency: true,
        animations: true,
        blur: true,
      },
      personalization: {
        userName: 'Admin',
        profileImage: '/assets/user.svg',
        showClock: true,
        showDate: true,
        use24HourFormat: false,
      },
      system: {
        startupSound: true,
        notificationSounds: true,
        autoSave: true,
        autoUpdate: true,
      }
    }));
    
    // Reset desktop icons to default
    localStorage.setItem('hospitalOS_desktopIcons', JSON.stringify([
      'dashboard', 'patients', 'appointments', 'staff', 'reports', 'terminal'
    ]));
    
    // Remove first-time setup completion flag
    localStorage.removeItem('hospitalOSFirstTimeSetup');
    
    // Remove file system
    localStorage.removeItem('hospitalFileSystem');
    
    // Show success message then reload page
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  };

  // Handle background type change
  const handleBackgroundTypeChange = (type: string) => {
    setSettings(prev => ({
      ...prev,
      background: {
        ...prev.background,
        type
      }
    }));
  };

  // Handle color change
  const handleColorChange = (value: string) => {
    setSettings(prev => ({
      ...prev,
      background: {
        ...prev.background,
        color: value
      }
    }));
  };

  // Handle image change
  const handleImageChange = (value: string) => {
    setSettings(prev => ({
      ...prev,
      background: {
        ...prev.background,
        image: value
      }
    }));
  };

  // Handle opacity change
  const handleOpacityChange = (value: number[]) => {
    setSettings(prev => ({
      ...prev,
      background: {
        ...prev.background,
        opacity: value[0]
      }
    }));
  };

  // Handle theme change
  const handleThemeChange = (value: string) => {
    setSettings(prev => ({
      ...prev,
      appearance: {
        ...prev.appearance,
        theme: value
      }
    }));
  };

  // Handle accent color change
  const handleAccentColorChange = (value: string) => {
    setSettings(prev => ({
      ...prev,
      appearance: {
        ...prev.appearance,
        accentColor: value
      }
    }));
  };

  // Handle effect toggles
  const handleEffectToggle = (effect: 'transparency' | 'animations' | 'blur', value: boolean) => {
    setSettings(prev => ({
      ...prev,
      appearance: {
        ...prev.appearance,
        [effect]: value
      }
    }));
  };

  // Handle personalization changes
  const handlePersonalizationChange = (field: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      personalization: {
        ...prev.personalization,
        [field]: value
      }
    }));
  };

  // Handle system settings changes
  const handleSystemChange = (field: string, value: boolean) => {
    setSettings(prev => ({
      ...prev,
      system: {
        ...prev.system,
        [field]: value
      }
    }));
  };
  
  // Toggle desktop icon visibility
  const toggleDesktopIcon = (iconId: WindowComponents, isChecked: boolean) => {
    if (isChecked) {
      // Add icon if not present
      if (!desktopIcons.includes(iconId)) {
        setDesktopIcons(prev => [...prev, iconId]);
        console.log(`Added ${iconId} to desktop icons`);
      }
    } else {
      // Remove icon if present
      setDesktopIcons(prev => prev.filter(id => id !== iconId));
      console.log(`Removed ${iconId} from desktop icons`);
    }
    
    // Save to localStorage for persistence
    localStorage.setItem('hospitalOS_desktopIcons', JSON.stringify(
      desktopIcons.includes(iconId) && !isChecked 
        ? desktopIcons.filter(id => id !== iconId) 
        : !desktopIcons.includes(iconId) && isChecked 
          ? [...desktopIcons, iconId]
          : desktopIcons
    ));
  };

  return (
    <div className="h-full p-4 overflow-auto">
      <Tabs defaultValue="background" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="background">Background</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="personalization">Personalization</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>
        
        {/* Background Settings */}
        <TabsContent value="background">
          <Card>
            <CardHeader>
              <CardTitle>Background Settings</CardTitle>
              <CardDescription>Customize your desktop background</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col space-y-2">
                <Label>Background Type</Label>
                <div className="flex space-x-4">
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="color-type" 
                      name="background-type" 
                      value="color"
                      checked={settings.background.type === 'color'}
                      onChange={() => handleBackgroundTypeChange('color')}
                      className="mr-2"
                    />
                    <Label htmlFor="color-type">Solid Color</Label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="image-type" 
                      name="background-type" 
                      value="image"
                      checked={settings.background.type === 'image'}
                      onChange={() => handleBackgroundTypeChange('image')}
                      className="mr-2"
                    />
                    <Label htmlFor="image-type">Image</Label>
                  </div>
                </div>
              </div>
              
              {settings.background.type === 'color' ? (
                <div className="space-y-2">
                  <Label>Choose Color</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <Select 
                      onValueChange={handleColorChange}
                      value={settings.background.color}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select Color" />
                      </SelectTrigger>
                      <SelectContent>
                        {backgroundColors.map(color => (
                          <SelectItem key={color.value} value={color.value}>
                            <div className="flex items-center">
                              <div 
                                className="w-4 h-4 mr-2 rounded-full" 
                                style={{ backgroundColor: color.value }}
                              ></div>
                              {color.name}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <div className="flex">
                      <Input 
                        type="color" 
                        value={settings.background.color}
                        onChange={(e) => handleColorChange(e.target.value)}
                        className="h-10 w-10"
                      />
                      <Input 
                        type="text" 
                        value={settings.background.color}
                        onChange={(e) => handleColorChange(e.target.value)}
                        className="ml-2 flex-1"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label>Choose Image</Label>
                  <Select 
                    onValueChange={handleImageChange}
                    value={settings.background.image}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Image" />
                    </SelectTrigger>
                    <SelectContent>
                      {backgroundImages.map(image => (
                        <SelectItem key={image.value} value={image.value}>
                          {image.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label>Background Opacity</Label>
                  <span>{Math.round(settings.background.opacity * 100)}%</span>
                </div>
                <Slider 
                  defaultValue={[settings.background.opacity]} 
                  max={1} 
                  step={0.01} 
                  onValueChange={handleOpacityChange}
                />
              </div>
              
              <div className="p-4 border rounded-md">
                <h3 className="font-medium mb-2">Preview</h3>
                <div 
                  className="w-full h-24 rounded-md border"
                  style={{
                    backgroundColor: settings.background.type === 'color' 
                      ? settings.background.color 
                      : 'transparent',
                    backgroundImage: settings.background.type === 'image' 
                      ? settings.background.image 
                      : 'none',
                    opacity: settings.background.opacity
                  }}
                ></div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={resetSettings}>Reset to Default</Button>
              <Button onClick={saveSettings}>Apply Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Appearance Settings */}
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Appearance Settings</CardTitle>
              <CardDescription>Customize the look and feel of your interface</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Theme</Label>
                <Select 
                  onValueChange={handleThemeChange}
                  value={settings.appearance.theme}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Theme" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Accent Color</Label>
                <div className="flex">
                  <Input 
                    type="color" 
                    value={settings.appearance.accentColor}
                    onChange={(e) => handleAccentColorChange(e.target.value)}
                    className="h-10 w-10"
                  />
                  <Input 
                    type="text" 
                    value={settings.appearance.accentColor}
                    onChange={(e) => handleAccentColorChange(e.target.value)}
                    className="ml-2 flex-1"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Visual Effects</Label>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="transparency">Transparency</Label>
                    <Switch 
                      id="transparency" 
                      checked={settings.appearance.transparency}
                      onCheckedChange={(checked) => handleEffectToggle('transparency', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="animations">Animations</Label>
                    <Switch 
                      id="animations" 
                      checked={settings.appearance.animations}
                      onCheckedChange={(checked) => handleEffectToggle('animations', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="blur">Blur Effects</Label>
                    <Switch 
                      id="blur" 
                      checked={settings.appearance.blur}
                      onCheckedChange={(checked) => handleEffectToggle('blur', checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={resetSettings}>Reset to Default</Button>
              <Button onClick={saveSettings}>Apply Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Personalization Settings */}
        <TabsContent value="personalization">
          <Card>
            <CardHeader>
              <CardTitle>Personalization</CardTitle>
              <CardDescription>Customize your user experience</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>User Name</Label>
                <Input 
                  value={settings.personalization.userName}
                  onChange={(e) => handlePersonalizationChange('userName', e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Profile Image</Label>
                <div className="grid grid-cols-4 gap-4">
                  {[
                    { name: 'Default', value: '/assets/user.svg' },
                    { name: 'Doctor', value: '/assets/user-doctor.svg' },
                    { name: 'Nurse', value: '/assets/user-nurse.svg' },
                    { name: 'Tech', value: '/assets/user-tech.svg' }
                  ].map((profile) => (
                    <div 
                      key={profile.value}
                      className={`relative p-2 border rounded-md cursor-pointer hover:bg-gray-100 transition-colors ${
                        settings.personalization.profileImage === profile.value ? 'border-primary ring-2 ring-primary ring-opacity-50' : ''
                      }`}
                      onClick={() => handlePersonalizationChange('profileImage', profile.value)}
                    >
                      <img 
                        src={profile.value} 
                        alt={profile.name}
                        className="w-full h-auto"
                      />
                      <p className="text-center text-xs mt-1">{profile.name}</p>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Taskbar Options</Label>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="showClock">Show Clock</Label>
                    <Switch 
                      id="showClock" 
                      checked={settings.personalization.showClock}
                      onCheckedChange={(checked) => handlePersonalizationChange('showClock', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="showDate">Show Date</Label>
                    <Switch 
                      id="showDate" 
                      checked={settings.personalization.showDate}
                      onCheckedChange={(checked) => handlePersonalizationChange('showDate', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="use24HourFormat">Use 24-Hour Format</Label>
                    <Switch 
                      id="use24HourFormat" 
                      checked={settings.personalization.use24HourFormat}
                      onCheckedChange={(checked) => handlePersonalizationChange('use24HourFormat', checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={resetSettings}>Reset to Default</Button>
              <Button onClick={saveSettings}>Apply Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* System Settings */}
        <TabsContent value="system">
          <Card>
            <CardHeader>
              <CardTitle>System Settings</CardTitle>
              <CardDescription>Configure system preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Sound</Label>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="startupSound">Startup Sound</Label>
                    <Switch 
                      id="startupSound" 
                      checked={settings.system.startupSound}
                      onCheckedChange={(checked) => handleSystemChange('startupSound', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="notificationSounds">Notification Sounds</Label>
                    <Switch 
                      id="notificationSounds" 
                      checked={settings.system.notificationSounds}
                      onCheckedChange={(checked) => handleSystemChange('notificationSounds', checked)}
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Automatic Features</Label>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="autoSave">Auto-Save</Label>
                    <Switch 
                      id="autoSave" 
                      checked={settings.system.autoSave}
                      onCheckedChange={(checked) => handleSystemChange('autoSave', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="autoUpdate">Auto-Update</Label>
                    <Switch 
                      id="autoUpdate" 
                      checked={settings.system.autoUpdate}
                      onCheckedChange={(checked) => handleSystemChange('autoUpdate', checked)}
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Desktop Icons</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-dashboard" 
                      checked={desktopIcons.includes('dashboard')}
                      onCheckedChange={(checked) => toggleDesktopIcon('dashboard', checked as boolean)}
                    />
                    <Label htmlFor="icon-dashboard">Dashboard</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-patients" 
                      checked={desktopIcons.includes('patients')}
                      onCheckedChange={(checked) => toggleDesktopIcon('patients', checked as boolean)}
                    />
                    <Label htmlFor="icon-patients">Patient Records</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-appointments" 
                      checked={desktopIcons.includes('appointments')}
                      onCheckedChange={(checked) => toggleDesktopIcon('appointments', checked as boolean)}
                    />
                    <Label htmlFor="icon-appointments">Appointments</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-staff" 
                      checked={desktopIcons.includes('staff')}
                      onCheckedChange={(checked) => toggleDesktopIcon('staff', checked as boolean)}
                    />
                    <Label htmlFor="icon-staff">Staff Portal</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-inventory" 
                      checked={desktopIcons.includes('inventory')}
                      onCheckedChange={(checked) => toggleDesktopIcon('inventory', checked as boolean)}
                    />
                    <Label htmlFor="icon-inventory">Inventory</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-reports" 
                      checked={desktopIcons.includes('reports')}
                      onCheckedChange={(checked) => toggleDesktopIcon('reports', checked as boolean)}
                    />
                    <Label htmlFor="icon-reports">Reports</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-emergency" 
                      checked={desktopIcons.includes('emergency')}
                      onCheckedChange={(checked) => toggleDesktopIcon('emergency', checked as boolean)}
                    />
                    <Label htmlFor="icon-emergency">Emergency</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-lab" 
                      checked={desktopIcons.includes('lab')}
                      onCheckedChange={(checked) => toggleDesktopIcon('lab', checked as boolean)}
                    />
                    <Label htmlFor="icon-lab">Laboratory</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-patientform" 
                      checked={desktopIcons.includes('patientform')}
                      onCheckedChange={(checked) => toggleDesktopIcon('patientform', checked as boolean)}
                    />
                    <Label htmlFor="icon-patientform">Patient Registration</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-terminal" 
                      checked={desktopIcons.includes('terminal')}
                      onCheckedChange={(checked) => toggleDesktopIcon('terminal', checked as boolean)}
                    />
                    <Label htmlFor="icon-terminal">Terminal</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-taskmanager" 
                      checked={desktopIcons.includes('taskmanager')}
                      onCheckedChange={(checked) => toggleDesktopIcon('taskmanager', checked as boolean)}
                    />
                    <Label htmlFor="icon-taskmanager">Task Manager</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="icon-settings" 
                      checked={desktopIcons.includes('settings')}
                      onCheckedChange={(checked) => toggleDesktopIcon('settings', checked as boolean)}
                    />
                    <Label htmlFor="icon-settings">Settings</Label>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">System Information</h3>
                <div className="text-sm space-y-1">
                  <p>Hospital OS Version: 3.2.1</p>
                  <p>Last Updated: March 27, 2025</p>
                  <p>Build: Replit-2025-03-HOS-3.2.1</p>
                </div>
              </div>
              
              <div className="p-4 border border-destructive rounded-md bg-destructive/5">
                <h3 className="font-medium mb-2 text-destructive">System Reset</h3>
                <p className="text-sm mb-4">
                  This will reset all settings, clear all data, and restart the setup wizard. This action cannot be undone.
                </p>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm">Reset System</Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Reset Entire System?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will delete all settings, preferences, files, and stored data. The system will restart with the setup wizard.
                        <br /><br />
                        <span className="font-bold">This action cannot be undone.</span>
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={resetSystem}>
                        Yes, Reset Everything
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={resetSettings}>Reset to Default</Button>
              <Button onClick={saveSettings}>Apply Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}