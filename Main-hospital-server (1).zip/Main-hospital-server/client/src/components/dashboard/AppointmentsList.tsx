import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Appointment, Patient, User } from '@shared/schema';
import { getStatusColorClass, formatTime } from '@/lib/data';

export default function AppointmentsList() {
  // Fetch data
  const { data: appointments, isLoading: isLoadingAppointments } = useQuery<Appointment[]>({
    queryKey: ['/api/appointments'],
  });
  
  const { data: patients, isLoading: isLoadingPatients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });
  
  const { data: users, isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });
  
  const isLoading = isLoadingAppointments || isLoadingPatients || isLoadingUsers;
  
  // Filter today's appointments
  const today = new Date().toISOString().split('T')[0];
  const todayAppointments = appointments?.filter(app => {
    const appDate = new Date(app.appointmentDate).toISOString().split('T')[0];
    return appDate === today;
  }) || [];
  
  // Get patient and doctor names
  const appointmentsWithNames = todayAppointments.map(appointment => {
    const patient = patients?.find(p => p.id === appointment.patientId);
    const doctor = users?.find(u => u.id === appointment.doctorId);
    
    return {
      ...appointment,
      patientName: patient ? `${patient.firstName} ${patient.lastName}` : 'Unknown Patient',
      doctorName: doctor ? doctor.name : 'Unknown Doctor',
      patientInitials: patient ? `${patient.firstName.charAt(0)}${patient.lastName.charAt(0)}` : 'UK',
    };
  });
  
  return (
    <>
      <div className="px-4 py-3 border-b border-win-gray-200 flex justify-between items-center">
        <h2 className="font-semibold">Today's Appointments</h2>
        <div className="flex space-x-2">
          <button className="px-3 py-1 text-sm rounded bg-win-blue text-white">
            <i className="fas fa-plus mr-1"></i> Add New
          </button>
          <button className="px-3 py-1 text-sm rounded border border-win-gray-300 hover:bg-win-gray-100">
            <i className="fas fa-filter"></i>
          </button>
        </div>
      </div>
      <div className="p-4">
        {isLoading ? (
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-win-blue"></div>
          </div>
        ) : appointmentsWithNames.length === 0 ? (
          <p className="text-center py-8 text-win-gray-500">No appointments scheduled for today.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="text-left text-sm text-win-gray-500 border-b border-win-gray-200">
                  <th className="pb-2 font-medium">Patient</th>
                  <th className="pb-2 font-medium">Time</th>
                  <th className="pb-2 font-medium">Department</th>
                  <th className="pb-2 font-medium">Doctor</th>
                  <th className="pb-2 font-medium">Status</th>
                  <th className="pb-2 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {appointmentsWithNames.map(appointment => (
                  <tr key={appointment.id} className="border-b border-win-gray-200 text-sm">
                    <td className="py-3 flex items-center">
                      <div className="w-8 h-8 rounded-full bg-win-gray-200 flex items-center justify-center mr-2 text-xs">
                        {appointment.patientInitials}
                      </div>
                      <div>{appointment.patientName}</div>
                    </td>
                    <td className="py-3">{formatTime(appointment.appointmentTime)}</td>
                    <td className="py-3">{appointment.department}</td>
                    <td className="py-3">{appointment.doctorName}</td>
                    <td className="py-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColorClass(appointment.status)}`}>
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </span>
                    </td>
                    <td className="py-3">
                      <button className="text-win-blue hover:underline">View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
