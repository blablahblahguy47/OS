import React from 'react';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { Notification } from '@shared/schema';
import { getNotificationIcon, formatRelativeTime } from '@/lib/data';
import { apiRequest } from '@/lib/queryClient';

interface NotificationsListProps {
  notifications: Notification[];
}

export default function NotificationsList({ notifications }: NotificationsListProps) {
  const queryClient = useQueryClient();
  
  const unreadCount = notifications.filter(notification => !notification.isRead).length;
  
  // Mark notification as read
  const markAsReadMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('PATCH', `/api/notifications/${id}/read`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
    }
  });
  
  const handleMarkAsRead = (id: number) => {
    markAsReadMutation.mutate(id);
  };
  
  // Sort notifications by timestamp (most recent first)
  const sortedNotifications = [...notifications].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
  
  return (
    <>
      <div className="px-4 py-3 border-b border-win-gray-200 flex justify-between items-center">
        <h2 className="font-semibold">Notifications</h2>
        {unreadCount > 0 && (
          <span className="px-2 py-1 rounded-full bg-win-red text-xs text-white">{unreadCount}</span>
        )}
      </div>
      <div className="p-2 max-h-[340px] overflow-y-auto scrollbar">
        {notifications.length === 0 ? (
          <p className="text-center py-8 text-win-gray-500">No notifications</p>
        ) : (
          sortedNotifications.map(notification => (
            <div 
              key={notification.id} 
              className={`flex p-2 border-b border-win-gray-200 hover:bg-win-gray-100 ${notification.isRead ? 'opacity-70' : ''}`}
              onClick={() => !notification.isRead && handleMarkAsRead(notification.id)}
            >
              <div className={`w-8 h-8 rounded-full bg-${notification.type === 'alert' ? 'win-red' : 
                                notification.type === 'warning' ? 'win-orange' : 
                                notification.type === 'success' ? 'win-green' : 
                                'win-blue'} bg-opacity-10 flex items-center justify-center mr-2 text-${notification.type === 'alert' ? 'win-red' : 
                                notification.type === 'warning' ? 'win-orange' : 
                                notification.type === 'success' ? 'win-green' : 
                                'win-blue'}`}
              >
                <i className={getNotificationIcon(notification.type)}></i>
              </div>
              <div className="flex-1">
                <div className="text-sm font-medium">{notification.title}</div>
                <div className="text-xs text-win-gray-500">{notification.message}</div>
                <div className="text-xs text-win-gray-500 mt-1">{formatRelativeTime(new Date(notification.timestamp))}</div>
              </div>
            </div>
          ))
        )}
      </div>
      <div className="px-4 py-2 border-t border-win-gray-200">
        <button className="w-full text-center text-win-blue text-sm py-1 hover:bg-win-gray-100 rounded">
          View All Notifications
        </button>
      </div>
    </>
  );
}
