import React from 'react';
import { DepartmentStatusProps } from '@/lib/types';
import { getStatusColorClass } from '@/lib/data';

export default function DepartmentStatus({ 
  name, 
  status, 
  currentLoad, 
  capacity, 
  numDoctors, 
  numNurses 
}: DepartmentStatusProps) {
  const loadPercentage = Math.round((currentLoad / capacity) * 100);
  const statusColorClass = getStatusColorClass(status);
  
  return (
    <div className="border border-win-gray-200 rounded p-3">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-medium">{name}</h3>
        <span className={`text-xs px-2 py-1 rounded-full ${statusColorClass}`}>
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </span>
      </div>
      <div className="mb-2 text-sm text-win-gray-500 flex justify-between">
        <span>Capacity</span>
        <span>{currentLoad}/{capacity} beds</span>
      </div>
      <div className="w-full bg-win-gray-200 rounded-full h-2 mb-3">
        <div 
          className={`h-2 rounded-full ${
            loadPercentage > 85 ? 'bg-win-red' : 
            loadPercentage > 70 ? 'bg-win-orange' : 
            'bg-win-green'
          }`}
          style={{ width: `${loadPercentage}%` }}
        ></div>
      </div>
      <div className="text-xs text-win-gray-500">
        <span className="mr-3"><i className="fas fa-user-md mr-1"></i> {numDoctors} doctors</span>
        <span><i className="fas fa-user-nurse mr-1"></i> {numNurses} nurses</span>
      </div>
    </div>
  );
}
