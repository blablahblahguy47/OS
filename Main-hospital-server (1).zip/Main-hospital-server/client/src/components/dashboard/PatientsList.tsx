import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Patient } from '@shared/schema';
import { getStatusColorClass, getInitials } from '@/lib/data';

export default function PatientsList() {
  const { data: patients, isLoading } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });
  
  // Sort by most recent admission date
  const recentPatients = patients
    ?.sort((a, b) => new Date(b.admissionDate || 0).getTime() - new Date(a.admissionDate || 0).getTime())
    .slice(0, 5) || [];
  
  return (
    <>
      <div className="px-4 py-3 border-b border-win-gray-200">
        <h2 className="font-semibold">Recent Patients</h2>
      </div>
      <div className="p-2">
        {isLoading ? (
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-win-blue"></div>
          </div>
        ) : recentPatients.length === 0 ? (
          <p className="text-center py-8 text-win-gray-500">No patients found.</p>
        ) : (
          recentPatients.map(patient => (
            <div key={patient.id} className="flex items-center p-2 hover:bg-win-gray-100 rounded-sm cursor-pointer">
              <div className="w-10 h-10 rounded-full bg-win-gray-200 flex items-center justify-center mr-3 text-xs">
                {getInitials(patient.firstName, patient.lastName)}
              </div>
              <div className="flex-1">
                <div className="font-medium">{patient.firstName} {patient.lastName}</div>
                <div className="text-xs text-win-gray-500">
                  ID: {patient.patientId} • Admitted: {patient.admissionDate ? new Date(patient.admissionDate).toLocaleDateString('en-US', { month: 'numeric', day: 'numeric' }) : 'N/A'}
                </div>
              </div>
              <div className={`text-xs px-2 py-1 rounded-full ${getStatusColorClass(patient.status)}`}>
                {patient.status.charAt(0).toUpperCase() + patient.status.slice(1)}
              </div>
            </div>
          ))
        )}
      </div>
      <div className="px-4 py-2 border-t border-win-gray-200">
        <button className="w-full text-center text-win-blue text-sm py-1 hover:bg-win-gray-100 rounded">
          View All Patients
        </button>
      </div>
    </>
  );
}
