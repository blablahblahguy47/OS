import React from 'react';
import { StatsCardProps } from '@/lib/types';

export default function StatsCard({ icon, iconBgColor, title, value, trend, subtext }: StatsCardProps) {
  return (
    <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
      <div className="flex items-center mb-2">
        <div className={`w-10 h-10 ${iconBgColor} bg-opacity-10 rounded-full flex items-center justify-center mr-3`}>
          <i className={`${icon} ${iconBgColor.replace('bg-', 'text-')}`}></i>
        </div>
        <span className="text-win-gray-500">{title}</span>
      </div>
      <div className="flex justify-between items-end">
        <span className="text-2xl font-semibold">{value}</span>
        <span className={`text-xs ${trend.isPositive ? 'text-win-green' : 'text-win-red'}`}>
          <i className={`fas fa-arrow-${trend.isPositive ? 'up' : 'down'}`}></i> {trend.value}
        </span>
      </div>
      <div className="text-xs text-win-gray-500">{subtext}</div>
    </div>
  );
}
