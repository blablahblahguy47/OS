import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { format } from 'date-fns';
import StatsCard from './StatsCard';
import AppointmentsList from './AppointmentsList';
import PatientsList from './PatientsList';
import DepartmentStatus from './DepartmentStatus';
import NotificationsList from './NotificationsList';
import { Department, Patient, Appointment, Notification, User } from '@shared/schema';

export default function Dashboard() {
  const { data: departments } = useQuery<Department[]>({
    queryKey: ['/api/departments'],
  });
  
  const { data: patients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });
  
  const { data: appointments } = useQuery<Appointment[]>({
    queryKey: ['/api/appointments'],
  });
  
  const { data: notifications } = useQuery<Notification[]>({
    queryKey: ['/api/notifications'],
  });
  
  const { data: users } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });
  
  // Get current user (would normally come from auth context)
  const currentUser = users?.find(user => user.username === 'drthompson');
  
  // Calculate stats
  const totalInpatients = patients?.filter(patient => 
    patient.status !== 'discharged').length || 0;
  const totalBeds = departments?.reduce((sum, dept) => sum + dept.capacity, 0) || 0;
  
  const totalAppointmentsToday = appointments?.filter(app => {
    const appDate = new Date(app.appointmentDate).toISOString().split('T')[0];
    const today = new Date().toISOString().split('T')[0];
    return appDate === today;
  }).length || 0;
  
  const emergencyCases = patients?.filter(patient => 
    patient.status === 'critical').length || 0;
  
  const staffOnDuty = {
    doctors: users?.filter(user => user.role === 'doctor' && user.status === 'active').length || 0,
    nurses: users?.filter(user => user.role === 'nurse' && user.status === 'active').length || 0
  };
  
  const currentDate = new Date();
  const formattedDate = format(currentDate, "EEEE, MMMM d, yyyy");
  
  return (
    <div className="flex h-full">
      {/* Sidebar Navigation */}
      <div className="w-56 bg-win-gray-100 border-r border-win-gray-300 p-2">
        <div className="mb-6">
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">MAIN MENU</div>
          <ul>
            <li className="mb-1">
              <a href="#" className="flex items-center px-2 py-2 text-sm rounded-sm bg-win-blue text-white">
                <i className="fas fa-tachometer-alt w-5"></i>
                <span>Dashboard</span>
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-user-injured w-5"></i>
                <span>Patients</span>
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="far fa-calendar-alt w-5"></i>
                <span>Appointments</span>
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-user-md w-5"></i>
                <span>Staff</span>
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-pills w-5"></i>
                <span>Pharmacy</span>
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-medkit w-5"></i>
                <span>Inventory</span>
              </a>
            </li>
          </ul>
        </div>
        
        <div>
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">REPORTS</div>
          <ul>
            <li className="mb-1">
              <a href="#" className="flex items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-chart-line w-5"></i>
                <span>Analytics</span>
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-file-medical-alt w-5"></i>
                <span>Medical Reports</span>
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-dollar-sign w-5"></i>
                <span>Financial</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      
      {/* Main Dashboard Content */}
      <div className="flex-1 p-4 overflow-auto scrollbar">
        {/* User Welcome & Search */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold mb-1">Welcome, {currentUser?.name || 'Dr. Thompson'}</h1>
            <p className="text-win-gray-500">{formattedDate} | {currentUser?.department || 'General Medicine'}</p>
          </div>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search..." 
              className="pl-10 pr-4 py-2 rounded border border-win-gray-300 focus:outline-none focus:border-win-blue focus:ring-1 focus:ring-win-blue w-64"
            />
            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-win-gray-500"></i>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatsCard 
            icon="fas fa-procedures"
            iconBgColor="bg-win-blue"
            title="Inpatients"
            value={totalInpatients.toString()}
            trend={{ value: "3.2%", isPositive: true }}
            subtext={`Total beds: ${totalBeds}`}
          />
          
          <StatsCard 
            icon="fas fa-calendar-check"
            iconBgColor="bg-win-green"
            title="Appointments"
            value={totalAppointmentsToday.toString()}
            trend={{ value: "5.7%", isPositive: true }}
            subtext="Today's schedule"
          />
          
          <StatsCard 
            icon="fas fa-heartbeat"
            iconBgColor="bg-win-orange"
            title="Emergency"
            value={emergencyCases.toString()}
            trend={{ value: "12.5%", isPositive: false }}
            subtext={`Critical: ${emergencyCases}`}
          />
          
          <StatsCard 
            icon="fas fa-user-md"
            iconBgColor="bg-win-gray-300"
            title="Staff On Duty"
            value={(staffOnDuty.doctors + staffOnDuty.nurses).toString()}
            trend={{ value: "2.1%", isPositive: false }}
            subtext={`Doctors: ${staffOnDuty.doctors}, Nurses: ${staffOnDuty.nurses}`}
          />
        </div>
        
        {/* Appointment & Patient Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Today's Appointments */}
          <div className="lg:col-span-2 bg-white rounded shadow-sm border border-win-gray-200">
            <AppointmentsList />
          </div>
          
          {/* Recent Patients */}
          <div className="bg-white rounded shadow-sm border border-win-gray-200">
            <PatientsList />
          </div>
        </div>
        
        {/* Department Status & Notifications */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Department Status */}
          <div className="lg:col-span-2 bg-white rounded shadow-sm border border-win-gray-200">
            <div className="px-4 py-3 border-b border-win-gray-200">
              <h2 className="font-semibold">Department Status</h2>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {departments?.map(dept => (
                  <DepartmentStatus
                    key={dept.id}
                    name={dept.name}
                    status={dept.status}
                    currentLoad={dept.currentLoad}
                    capacity={dept.capacity}
                    numDoctors={dept.numDoctors}
                    numNurses={dept.numNurses}
                  />
                ))}
              </div>
            </div>
          </div>
          
          {/* Notifications */}
          <div className="bg-white rounded shadow-sm border border-win-gray-200">
            <NotificationsList notifications={notifications || []} />
          </div>
        </div>
      </div>
    </div>
  );
}
