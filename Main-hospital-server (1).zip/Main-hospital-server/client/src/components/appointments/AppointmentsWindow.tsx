import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Appointment, Patient, User } from '@shared/schema';
import { getStatusColorClass, formatTime, formatDate } from '@/lib/data';
import AppointmentForm from './AppointmentForm';
import { Calendar } from '@/components/ui/calendar';

export default function AppointmentsWindow() {
  const queryClient = useQueryClient();
  const [isAddingAppointment, setIsAddingAppointment] = useState(false);
  const [currentAppointment, setCurrentAppointment] = useState<Appointment | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('list');
  
  // Fetch appointments
  const { data: appointments, isLoading } = useQuery<Appointment[]>({
    queryKey: ['/api/appointments'],
  });
  
  // Fetch patients for dropdown
  const { data: patients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });
  
  // Fetch doctors for dropdown
  const { data: doctors } = useQuery<User[]>({
    queryKey: ['/api/users'],
    select: (users) => users.filter(user => user.role === 'doctor'),
  });
  
  const deleteAppointmentMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/appointments/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
    }
  });
  
  const handleAddNew = () => {
    setCurrentAppointment(null);
    setIsAddingAppointment(true);
  };
  
  const handleEdit = (appointment: Appointment) => {
    setCurrentAppointment(appointment);
    setIsAddingAppointment(true);
  };
  
  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this appointment?')) {
      deleteAppointmentMutation.mutate(id);
    }
  };
  
  const handleFormClose = () => {
    setIsAddingAppointment(false);
    setCurrentAppointment(null);
  };
  
  const handleFormSubmit = () => {
    setIsAddingAppointment(false);
    setCurrentAppointment(null);
    queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
  };
  
  // Filter appointments for selected date
  const selectedDateStr = selectedDate.toISOString().split('T')[0];
  const filteredAppointments = appointments?.filter(app => {
    const appDate = new Date(app.appointmentDate).toISOString().split('T')[0];
    return appDate === selectedDateStr;
  }) || [];
  
  // Add patient and doctor names to appointments
  const appointmentsWithNames = filteredAppointments.map(appointment => {
    const patient = patients?.find(p => p.id === appointment.patientId);
    const doctor = doctors?.find(d => d.id === appointment.doctorId);
    
    return {
      ...appointment,
      patientName: patient ? `${patient.firstName} ${patient.lastName}` : 'Unknown Patient',
      doctorName: doctor ? doctor.name : 'Unknown Doctor',
      patientInitials: patient ? `${patient.firstName.charAt(0)}${patient.lastName.charAt(0)}` : 'UK',
    };
  });
  
  // Group appointments by time for calendar view
  const groupedAppointments = appointmentsWithNames.reduce((acc, appointment) => {
    const timeKey = formatTime(appointment.appointmentTime);
    if (!acc[timeKey]) {
      acc[timeKey] = [];
    }
    acc[timeKey].push(appointment);
    return acc;
  }, {} as Record<string, typeof appointmentsWithNames>);
  
  // Days with appointments for calendar highlighting
  const daysWithAppointments = appointments?.reduce((acc, appointment) => {
    const date = new Date(appointment.appointmentDate);
    const dateStr = date.toISOString().split('T')[0];
    acc[dateStr] = true;
    return acc;
  }, {} as Record<string, boolean>) || {};
  
  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <div className="w-56 bg-win-gray-100 border-r border-win-gray-300 p-2">
        <div className="mb-6">
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">APPOINTMENT VIEWS</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={() => setViewMode('list')} 
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${viewMode === 'list' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-list w-5"></i>
                <span>List View</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setViewMode('calendar')} 
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${viewMode === 'calendar' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-calendar w-5"></i>
                <span>Calendar View</span>
              </button>
            </li>
          </ul>
        </div>
        
        <div>
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">TOOLS</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={handleAddNew} 
                className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200"
              >
                <i className="fas fa-calendar-plus w-5"></i>
                <span>New Appointment</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-print w-5"></i>
                <span>Print Schedule</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-envelope w-5"></i>
                <span>Send Reminders</span>
              </button>
            </li>
          </ul>
        </div>
        
        <div className="mt-4">
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">APPOINTMENT TYPES</div>
          <div className="pl-2">
            <div className="flex items-center mb-2">
              <div className="w-3 h-3 rounded-full bg-win-green mr-2"></div>
              <span className="text-sm">Confirmed</span>
            </div>
            <div className="flex items-center mb-2">
              <div className="w-3 h-3 rounded-full bg-win-orange mr-2"></div>
              <span className="text-sm">Waiting</span>
            </div>
            <div className="flex items-center mb-2">
              <div className="w-3 h-3 rounded-full bg-win-blue mr-2"></div>
              <span className="text-sm">In Progress</span>
            </div>
            <div className="flex items-center mb-2">
              <div className="w-3 h-3 rounded-full bg-win-red mr-2"></div>
              <span className="text-sm">Cancelled</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-win-gray-500 mr-2"></div>
              <span className="text-sm">Completed</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 p-4 overflow-auto scrollbar">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold mb-1">Appointment Scheduler</h1>
            <p className="text-win-gray-500">Manage appointments and schedule patient visits</p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => setSelectedDate(new Date())}
              className="px-3 py-2 rounded border border-win-gray-300 hover:bg-win-gray-100"
            >
              Today
            </button>
            <button 
              onClick={handleAddNew}
              className="px-3 py-2 rounded bg-win-blue text-white"
            >
              <i className="fas fa-plus mr-1"></i> New Appointment
            </button>
          </div>
        </div>
        
        <div className="flex">
          {/* Calendar Widget */}
          <div className="w-64 mr-6">
            <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => date && setSelectedDate(date)}
                modifiers={{
                  hasAppointment: (date) => {
                    const dateStr = date.toISOString().split('T')[0];
                    return !!daysWithAppointments[dateStr];
                  }
                }}
                modifiersStyles={{
                  hasAppointment: {
                    fontWeight: "bold",
                    backgroundColor: "rgba(0, 120, 215, 0.1)",
                    borderRadius: "4px"
                  }
                }}
                className="p-0"
              />
              <div className="mt-4 text-center">
                <h3 className="font-medium">
                  {selectedDate.toLocaleDateString('en-US', { weekday: 'long' })}, {selectedDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </h3>
                <p className="text-sm text-win-gray-500">
                  {appointmentsWithNames.length} appointments
                </p>
              </div>
            </div>
          </div>
          
          {/* Appointments List/Calendar */}
          <div className="flex-1">
            <div className="bg-white rounded shadow-sm border border-win-gray-200">
              <div className="px-4 py-3 border-b border-win-gray-200 flex justify-between items-center">
                <h2 className="font-semibold">
                  Appointments for {selectedDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </h2>
                <div className="flex space-x-2">
                  <button className="px-3 py-1 text-sm rounded border border-win-gray-300 hover:bg-win-gray-100">
                    <i className="fas fa-filter"></i>
                  </button>
                </div>
              </div>
              
              {isLoading ? (
                <div className="flex justify-center p-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-win-blue"></div>
                </div>
              ) : appointmentsWithNames.length === 0 ? (
                <div className="p-8 text-center">
                  <div className="w-16 h-16 bg-win-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-calendar-day text-2xl text-win-gray-400"></i>
                  </div>
                  <h3 className="text-lg font-medium mb-2">No Appointments Scheduled</h3>
                  <p className="text-win-gray-500 mb-4">There are no appointments scheduled for this date.</p>
                  <button 
                    onClick={handleAddNew}
                    className="px-4 py-2 rounded bg-win-blue text-white"
                  >
                    <i className="fas fa-plus mr-1"></i> Add Appointment
                  </button>
                </div>
              ) : viewMode === 'list' ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead>
                      <tr className="text-left text-sm text-win-gray-500 border-b border-win-gray-200">
                        <th className="px-4 py-3 font-medium">Time</th>
                        <th className="px-4 py-3 font-medium">Patient</th>
                        <th className="px-4 py-3 font-medium">Doctor</th>
                        <th className="px-4 py-3 font-medium">Department</th>
                        <th className="px-4 py-3 font-medium">Reason</th>
                        <th className="px-4 py-3 font-medium">Status</th>
                        <th className="px-4 py-3 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {appointmentsWithNames
                        .sort((a, b) => {
                          const timeA = a.appointmentTime.hours * 60 + a.appointmentTime.minutes;
                          const timeB = b.appointmentTime.hours * 60 + b.appointmentTime.minutes;
                          return timeA - timeB;
                        })
                        .map(appointment => (
                        <tr key={appointment.id} className="border-b border-win-gray-200 hover:bg-win-gray-50 text-sm">
                          <td className="px-4 py-3">{formatTime(appointment.appointmentTime)}</td>
                          <td className="px-4 py-3 flex items-center">
                            <div className="w-8 h-8 rounded-full bg-win-gray-200 flex items-center justify-center mr-2 text-xs">
                              {appointment.patientInitials}
                            </div>
                            <span>{appointment.patientName}</span>
                          </td>
                          <td className="px-4 py-3">{appointment.doctorName}</td>
                          <td className="px-4 py-3">{appointment.department}</td>
                          <td className="px-4 py-3">{appointment.reasonForVisit || 'N/A'}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs ${getStatusColorClass(appointment.status)}`}>
                              {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex space-x-2">
                              <button 
                                onClick={() => handleEdit(appointment)} 
                                className="text-win-blue hover:underline"
                              >
                                <i className="fas fa-edit"></i>
                              </button>
                              <button 
                                onClick={() => handleDelete(appointment.id)} 
                                className="text-win-red hover:underline"
                              >
                                <i className="fas fa-trash"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-4">
                  <div className="grid grid-cols-1 gap-4">
                    {Object.entries(groupedAppointments)
                      .sort(([timeA], [timeB]) => {
                        const parseTime = (time: string) => {
                          const [hourStr, minuteStr] = time.split(':');
                          const isPM = time.toLowerCase().includes('pm');
                          let hour = parseInt(hourStr, 10);
                          if (isPM && hour !== 12) hour += 12;
                          if (!isPM && hour === 12) hour = 0;
                          return hour * 60 + parseInt(minuteStr, 10);
                        };
                        return parseTime(timeA) - parseTime(timeB);
                      })
                      .map(([time, timeAppointments]) => (
                      <div key={time} className="border border-win-gray-200 rounded p-3">
                        <div className="flex items-center mb-3">
                          <div className="w-8 h-8 rounded-full bg-win-blue bg-opacity-10 flex items-center justify-center mr-2 text-win-blue">
                            <i className="fas fa-clock"></i>
                          </div>
                          <h3 className="font-semibold">{time}</h3>
                        </div>
                        
                        <div className="pl-10 space-y-2">
                          {timeAppointments.map(appointment => (
                            <div 
                              key={appointment.id} 
                              className="p-2 border-l-4 border-l-win-blue rounded-r flex justify-between items-center"
                            >
                              <div>
                                <div className="font-medium">{appointment.patientName}</div>
                                <div className="text-xs text-win-gray-500">
                                  {appointment.department} • {appointment.doctorName}
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className={`px-2 py-1 rounded-full text-xs ${getStatusColorClass(appointment.status)}`}>
                                  {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                                </span>
                                <button 
                                  onClick={() => handleEdit(appointment)} 
                                  className="text-win-blue hover:bg-win-gray-100 p-1 rounded"
                                >
                                  <i className="fas fa-edit"></i>
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Appointment Form Modal */}
      {isAddingAppointment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-md w-[700px] max-h-[90vh] overflow-auto">
            <AppointmentForm 
              appointment={currentAppointment}
              patients={patients || []}
              doctors={doctors || []}
              selectedDate={selectedDate}
              onClose={handleFormClose}
              onSubmit={handleFormSubmit}
            />
          </div>
        </div>
      )}
    </div>
  );
}
