import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Patient, Appointment, Inventory, Department } from '@shared/schema';
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  CartesianGrid, 
  ResponsiveContainer, 
  Cell 
} from 'recharts';
import { format, subDays, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';

// Report interface for our generated reports
interface Report {
  id: string;
  name: string;
  type: string;
  date: string;
  author: string;
  status: 'Completed' | 'In Progress' | 'Pending';
}

// Patient behavior report interface
interface PatientBehaviorReport {
  id: string;
  patientName: string;
  date: string;
  behaviorNotes: string;
  behaviorScore: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  recommendedAction: string;
  doctorName: string;
}

interface ReportsWindowProps {
  type?: 'emergency' | 'lab';
}

export default function ReportsWindow({ type }: ReportsWindowProps) {
  const [reportType, setReportType] = useState<'patient' | 'appointment' | 'inventory' | 'financial'>('patient');
  const [accessAuthorized, setAccessAuthorized] = useState<boolean>(true); // Set to true to make reports accessible by default
  
  // Handle special report types (emergency or lab)
  useEffect(() => {
    if (type === 'emergency') {
      // Pre-select appropriate report type for emergency view
      setReportType('patient');
      document.title = 'Emergency Response System';
    } else if (type === 'lab') {
      // Pre-select appropriate report type for lab view
      setReportType('inventory');
      document.title = 'Laboratory Results';
    }
  }, [type]);
  const [codeInputVisible, setCodeInputVisible] = useState<boolean>(false); // Hide code input by default
  const [securityCode, setSecurityCode] = useState<string>('');
  const [codeError, setCodeError] = useState<boolean>(false);
  const [showRestrictedReports, setShowRestrictedReports] = useState<boolean>(false);
  const [restrictedReportPassword, setRestrictedReportPassword] = useState<string>('');
  const [showRestrictedModal, setShowRestrictedModal] = useState<boolean>(false);
  const [restrictedPasswordError, setRestrictedPasswordError] = useState<boolean>(false);
  const [reports, setReports] = useState<Report[]>([
    { 
      id: 'RPT-0001',
      name: 'Monthly Patient Summary', 
      type: 'Clinical', 
      date: '2025-03-01', 
      author: 'Dr. Thompson', 
      status: 'Completed' 
    },
    { 
      id: 'RPT-0002',
      name: 'Q1 Financial Statement', 
      type: 'Financial', 
      date: '2025-03-15', 
      author: 'Sarah Reynolds', 
      status: 'Completed' 
    },
    { 
      id: 'RPT-0003',
      name: 'Staff Performance Review', 
      type: 'Administrative', 
      date: '2025-03-10', 
      author: 'Michael Chen', 
      status: 'In Progress' 
    },
    { 
      id: 'RPT-0004',
      name: 'Emergency Room Utilization', 
      type: 'Clinical', 
      date: '2025-03-05', 
      author: 'Dr. Patel', 
      status: 'Completed' 
    },
    { 
      id: 'RPT-0005',
      name: 'Inventory Audit Report', 
      type: 'Administrative', 
      date: '2025-02-28', 
      author: 'Jessica Kim', 
      status: 'Completed' 
    },
    { 
      id: 'RPT-0006',
      name: 'Patient Behavior Documentation', 
      type: 'Clinical', 
      date: '2025-03-25', 
      author: 'Dr. Roberts', 
      status: 'Completed' 
    },
    { 
      id: 'RPT-0007',
      name: 'Discharge Report with Behavioral Notes', 
      type: 'Clinical', 
      date: '2025-03-26', 
      author: 'Dr. Williams', 
      status: 'Completed' 
    }
  ]);
  
  // Patient behavior reports (accessible via password)
  const [patientBehaviorReports, setPatientBehaviorReports] = useState<PatientBehaviorReport[]>([
    {
      id: 'BHV-0001',
      patientName: 'John Smith',
      date: '2025-03-24',
      behaviorNotes: 'Patient exhibited signs of anxiety during the consultation. Fidgeting frequently and avoiding eye contact. Speech was rapid when discussing treatment options.',
      behaviorScore: 7,
      riskLevel: 'Medium',
      recommendedAction: 'Schedule follow-up appointment within 2 weeks',
      doctorName: 'Dr. Roberts'
    },
    {
      id: 'BHV-0002',
      patientName: 'Sarah Johnson',
      date: '2025-03-23',
      behaviorNotes: 'Patient was calm and cooperative during the examination. Showed appropriate emotional responses to questions. Good eye contact maintained throughout the session.',
      behaviorScore: 3,
      riskLevel: 'Low',
      recommendedAction: 'Continue with standard care protocol',
      doctorName: 'Dr. Williams'
    },
    {
      id: 'BHV-0003',
      patientName: 'Michael Davis',
      date: '2025-03-22',
      behaviorNotes: 'Patient displayed hostile behavior when medication changes were suggested. Raised voice and made threatening statements. Required de-escalation procedures.',
      behaviorScore: 9,
      riskLevel: 'High',
      recommendedAction: 'Immediate psychiatric consultation and consider security precautions',
      doctorName: 'Dr. Thompson'
    },
    {
      id: 'BHV-0004',
      patientName: 'Emily Wilson',
      date: '2025-03-21',
      behaviorNotes: 'Patient showed signs of depression. Minimal verbal responses, downcast eyes, and reported feelings of hopelessness. Sleep disturbances noted.',
      behaviorScore: 8,
      riskLevel: 'Medium',
      recommendedAction: 'Refer to mental health specialist and monitor closely',
      doctorName: 'Dr. Patel'
    },
    {
      id: 'BHV-0005',
      patientName: 'Robert Brown',
      date: '2025-03-20',
      behaviorNotes: 'Patient exhibited confused behavior, disorientation to time and place. Family members report recent memory issues. Patient became agitated during cognitive assessment.',
      behaviorScore: 7,
      riskLevel: 'Medium',
      recommendedAction: 'Order neurological workup and cognitive assessment',
      doctorName: 'Dr. Johnson'
    }
  ]);
  
  const [reportFilter, setReportFilter] = useState<string>('All Reports');
  
  // Filter reports based on selected filter
  const filteredReports = reportFilter === 'All Reports' 
    ? reports 
    : reports.filter(report => report.type === reportFilter);
    
  // Generate a random report for automatic addition
  const generateRandomReport = (): Report => {
    const reportNames = [
      'Patient Discharge Summary',
      'Medication Usage Report',
      'Staff Attendance Report',
      'Department Budget Analysis',
      'Emergency Response Time',
      'Billing Reconciliation',
      'Insurance Claims Summary',
      'Patient Satisfaction Survey',
      'Equipment Maintenance Report',
      'Infection Control Audit',
      'Staff Scheduling Overview',
      'Pharmacy Inventory Status'
    ];
    
    const reportTypes = ['Clinical', 'Financial', 'Administrative'];
    const authors = ['Dr. Thompson', 'Dr. Patel', 'Sarah Reynolds', 'Michael Chen', 'Jessica Kim', 'Dr. Johnson', 'Dr. Williams', 'Mark Davis'];
    const statuses: ('Completed' | 'In Progress' | 'Pending')[] = ['Completed', 'In Progress', 'Pending'];
    
    // Generate today's date or a recent date
    const today = new Date();
    const randomDay = Math.floor(Math.random() * 5); // 0-4 days ago
    today.setDate(today.getDate() - randomDay);
    
    // Format the date as YYYY-MM-DD
    const date = today.toISOString().split('T')[0];
    
    // Create a unique ID
    const id = `RPT-${Math.floor(1000 + Math.random() * 9000)}`;
    
    return {
      id,
      name: reportNames[Math.floor(Math.random() * reportNames.length)],
      type: reportTypes[Math.floor(Math.random() * reportTypes.length)],
      date,
      author: authors[Math.floor(Math.random() * authors.length)],
      status: statuses[Math.floor(Math.random() * statuses.length)]
    };
  };
  
  // Add new reports every 2-5 minutes
  useEffect(() => {
    const addReports = () => {
      const newReport = generateRandomReport();
      setReports(prevReports => [newReport, ...prevReports]);
    };
    
    // Initial delay before adding the first random report (between 10-20 seconds for demo purposes)
    const initialDelay = Math.floor(Math.random() * 10000) + 10000;
    
    // Set up the timer for the first report
    const initialTimer = setTimeout(() => {
      addReports();
      
      // Then set up recurring reports
      const interval = setInterval(() => {
        addReports();
      }, (Math.floor(Math.random() * 3) + 2) * 60 * 1000); // Between 2-5 minutes
      
      // Clean up the interval when the component unmounts
      return () => clearInterval(interval);
    }, initialDelay);
    
    // Clean up the initial timer when the component unmounts
    return () => clearTimeout(initialTimer);
  }, []);
  
  // Handle restricted reports access for patient behavior documentation
  const handleRestrictedAccess = () => {
    // For demo purposes, password is "reports123"
    if (restrictedReportPassword === 'reports123') {
      setShowRestrictedReports(true);
      setShowRestrictedModal(false);
      setRestrictedPasswordError(false);
      setRestrictedReportPassword('');
    } else {
      setRestrictedPasswordError(true);
    }
  };
  
  // Handle export functionality
  const handleExport = () => {
    alert(`Exporting ${reportFilter} reports as CSV...`);
  };
  
  // Fetch data
  const { data: patients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });
  
  const { data: appointments } = useQuery<Appointment[]>({
    queryKey: ['/api/appointments'],
  });
  
  const { data: inventory } = useQuery<Inventory[]>({
    queryKey: ['/api/inventory'],
  });
  
  const { data: departments } = useQuery<Department[]>({
    queryKey: ['/api/departments'],
  });
  
  // Patient Status Distribution
  const patientStatusData = React.useMemo(() => {
    if (!patients) return [];
    
    const statusCounts: Record<string, number> = {};
    patients.forEach(patient => {
      if (patient.status) {
        const status = patient.status;
        statusCounts[status] = (statusCounts[status] || 0) + 1;
      }
    });
    
    return Object.entries(statusCounts).map(([status, count]) => ({
      name: status.charAt(0).toUpperCase() + status.slice(1),
      value: count
    }));
  }, [patients]);
  
  // Department Occupancy
  const departmentOccupancyData = React.useMemo(() => {
    if (!departments) return [];
    
    return departments.map(dept => ({
      name: dept.name,
      occupancy: Math.round(((dept.currentLoad || 0) / dept.capacity) * 100),
      currentLoad: dept.currentLoad || 0,
      capacity: dept.capacity
    }));
  }, [departments]);
  
  // Appointments by Day (last 7 days)
  const appointmentsByDayData = React.useMemo(() => {
    if (!appointments) return [];
    
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), i);
      return format(date, 'yyyy-MM-dd');
    }).reverse();
    
    const appointmentsByDay: Record<string, number> = {};
    last7Days.forEach(day => {
      appointmentsByDay[day] = 0;
    });
    
    appointments.forEach(appointment => {
      const date = new Date(appointment.appointmentDate).toISOString().split('T')[0];
      if (appointmentsByDay[date] !== undefined) {
        appointmentsByDay[date]++;
      }
    });
    
    return Object.entries(appointmentsByDay).map(([date, count]) => ({
      date: format(new Date(date), 'MM/dd'),
      count
    }));
  }, [appointments]);
  
  // Inventory Value by Category
  const inventoryValueByCategory = React.useMemo(() => {
    if (!inventory) return [];
    
    const categoryValues: Record<string, number> = {};
    inventory.forEach(item => {
      const category = item.category;
      const itemQuantity = item.quantity || 0;
      const itemCost = item.cost || 0;
      const value = itemCost * itemQuantity;
      categoryValues[category] = (categoryValues[category] || 0) + value;
    });
    
    return Object.entries(categoryValues).map(([category, value]) => ({
      name: category.charAt(0).toUpperCase() + category.slice(1),
      value: value / 100 // Convert cents to dollars
    }));
  }, [inventory]);
  
  // Low Stock Items
  const lowStockItems = React.useMemo(() => {
    if (!inventory) return [];
    
    return inventory
      .filter(item => {
        const reorderLevel = item.reorderLevel || 0;
        const quantity = item.quantity || 0;
        return reorderLevel > 0 && quantity <= reorderLevel;
      })
      .sort((a, b) => {
        const aRatio = (a.quantity || 0) / (a.reorderLevel || 1);
        const bRatio = (b.quantity || 0) / (b.reorderLevel || 1);
        return aRatio - bRatio;
      })
      .slice(0, 5);
  }, [inventory]);
  
  // Monthly Patient Admissions
  const monthlyAdmissions = React.useMemo(() => {
    if (!patients) return [];
    
    const today = new Date();
    const firstDay = startOfMonth(today);
    const lastDay = endOfMonth(today);
    
    const daysInMonth = eachDayOfInterval({ start: firstDay, end: lastDay });
    
    const admissionsByDay: Record<string, number> = {};
    daysInMonth.forEach(day => {
      admissionsByDay[format(day, 'yyyy-MM-dd')] = 0;
    });
    
    patients.forEach(patient => {
      if (patient.admissionDate) {
        const date = new Date(patient.admissionDate).toISOString().split('T')[0];
        const monthYear = date.substring(0, 7);
        const currentMonthYear = today.toISOString().split('T')[0].substring(0, 7);
        
        if (monthYear === currentMonthYear && admissionsByDay[date] !== undefined) {
          admissionsByDay[date]++;
        }
      }
    });
    
    return Object.entries(admissionsByDay).map(([date, count]) => ({
      date: format(new Date(date), 'dd'),
      admissions: count
    }));
  }, [patients]);
  
  // COLORS for pie charts
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];
  
  // Patient behavior score distribution
  const behaviorScoreData = [
    { name: 'Low Risk (1-3)', value: 2 },
    { name: 'Medium Risk (4-7)', value: 8 },
    { name: 'High Risk (8-10)', value: 4 }
  ];
  
  return (
    <div className="flex h-full">
      {/* Restricted Reports Modal */}
      {showRestrictedModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded shadow-lg w-96">
            <h3 className="text-lg font-medium mb-4">Protected Patient Behavior Reports</h3>
            <p className="mb-4 text-gray-600">These reports contain sensitive clinical information about patient behavior. Please enter the access code to continue.</p>
            
            {restrictedPasswordError && (
              <p className="text-red-500 mb-4">Invalid access code. Please try again.</p>
            )}
            
            <input
              type="password"
              value={restrictedReportPassword}
              onChange={(e) => setRestrictedReportPassword(e.target.value)}
              placeholder="Enter access code"
              className="w-full p-2 border rounded mb-4"
              onKeyDown={(e) => e.key === 'Enter' && handleRestrictedAccess()}
            />
            
            <div className="flex justify-end">
              <button 
                className="bg-gray-300 text-gray-800 px-4 py-2 rounded mr-2"
                onClick={() => {
                  setShowRestrictedModal(false);
                  setRestrictedPasswordError(false);
                  setRestrictedReportPassword('');
                }}
              >
                Cancel
              </button>
              <button 
                className="bg-blue-500 text-white px-4 py-2 rounded"
                onClick={handleRestrictedAccess}
              >
                Access Reports
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Sidebar */}
      <div className="w-56 bg-win-gray-100 border-r border-win-gray-300 p-2">
        <div className="mb-6">
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">REPORTS</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={() => setReportType('patient')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${reportType === 'patient' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-user-injured w-5"></i>
                <span>Patient Analytics</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setReportType('appointment')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${reportType === 'appointment' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-calendar-check w-5"></i>
                <span>Appointment Analytics</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setReportType('inventory')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${reportType === 'inventory' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-boxes w-5"></i>
                <span>Inventory Analytics</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setReportType('financial')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${reportType === 'financial' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-chart-line w-5"></i>
                <span>Financial Analytics</span>
              </button>
            </li>
          </ul>
        </div>
        
        <div>
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">ACTIONS</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={handleExport}
                className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200"
              >
                <i className="fas fa-file-export w-5"></i>
                <span>Export Report</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-print w-5"></i>
                <span>Print Report</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-envelope w-5"></i>
                <span>Email Report</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setShowRestrictedModal(true)}
                className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200"
              >
                <i className="fas fa-lock w-5"></i>
                <span>Patient Behavior Reports</span>
              </button>
            </li>
          </ul>
        </div>
      </div>
      
      {/* Security Code Modal */}
      {codeInputVisible && !accessAuthorized && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded shadow-lg w-96">
            <h3 className="text-lg font-medium mb-4">Secure Report Access</h3>
            <p className="mb-4 text-gray-600">Please enter your security code to access hospital reports.</p>
            
            {codeError && (
              <p className="text-red-500 mb-4">Invalid security code. Please try again.</p>
            )}
            
            <input
              type="password"
              value={securityCode}
              onChange={(e) => setSecurityCode(e.target.value)}
              placeholder="Enter security code"
              className="w-full p-2 border rounded mb-4"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  if (securityCode === "reports123") {
                    setAccessAuthorized(true);
                    setCodeInputVisible(false);
                    setCodeError(false);
                  } else {
                    setCodeError(true);
                  }
                }
              }}
            />
            
            <div className="flex justify-end">
              <button 
                className="bg-gray-300 text-gray-800 px-4 py-2 rounded mr-2"
                onClick={() => {
                  setCodeInputVisible(false);
                  setCodeError(false);
                  setSecurityCode('');
                }}
              >
                Cancel
              </button>
              <button 
                className="bg-blue-500 text-white px-4 py-2 rounded"
                onClick={() => {
                  if (securityCode === "reports123") {
                    setAccessAuthorized(true);
                    setCodeInputVisible(false);
                    setCodeError(false);
                  } else {
                    setCodeError(true);
                  }
                }}
              >
                Verify
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Main Content */}
      <div className="flex-1 p-4 overflow-auto scrollbar">
        {!accessAuthorized ? (
          <div className="flex flex-col items-center justify-center h-full">
            <div className="text-6xl text-red-500 mb-4">
              <i className="fas fa-lock"></i>
            </div>
            <h2 className="text-2xl font-bold mb-2">Access Restricted</h2>
            <p className="text-gray-600 mb-4">You need a security code to access these reports.</p>
            <button 
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
              onClick={() => setCodeInputVisible(true)}
            >
              Enter Security Code
            </button>
          </div>
        ) : (
          <>
            {showRestrictedReports ? (
              // Patient Behavior Reports (Protected)
              <div className="space-y-6">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h1 className="text-2xl font-semibold mb-1">
                      Patient Behavior Documentation
                    </h1>
                    <p className="text-win-gray-500">Confidential patient behavior analysis and risk assessment</p>
                  </div>
                  <button 
                    className="px-3 py-2 rounded bg-red-500 text-white"
                    onClick={() => setShowRestrictedReports(false)}
                  >
                    <i className="fas fa-lock mr-1"></i> Close Protected Reports
                  </button>
                </div>
                
                {/* Patient Behavior Analytics */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Behavior Risk Distribution</h2>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={behaviorScoreData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }: { name: string, percent: number }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {behaviorScoreData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={['#4CAF50', '#FFC107', '#F44336'][index % 3]} />
                            ))}
                          </Pie>
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Patient Behavior Risk Trends</h2>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={[
                            { date: '01/15', highRisk: 2, mediumRisk: 5, lowRisk: 8 },
                            { date: '01/30', highRisk: 3, mediumRisk: 6, lowRisk: 7 },
                            { date: '02/15', highRisk: 4, mediumRisk: 8, lowRisk: 5 },
                            { date: '02/28', highRisk: 3, mediumRisk: 7, lowRisk: 6 },
                            { date: '03/15', highRisk: 5, mediumRisk: 9, lowRisk: 3 },
                            { date: '03/28', highRisk: 4, mediumRisk: 8, lowRisk: 4 }
                          ]}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line type="monotone" dataKey="highRisk" name="High Risk" stroke="#F44336" />
                          <Line type="monotone" dataKey="mediumRisk" name="Medium Risk" stroke="#FFC107" />
                          <Line type="monotone" dataKey="lowRisk" name="Low Risk" stroke="#4CAF50" />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
                
                {/* Patient Behavior Reports Table */}
                <div className="bg-white rounded shadow-lg border border-win-gray-200 p-4">
                  <h2 className="font-semibold mb-4">Patient Behavior Documentation</h2>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="bg-win-gray-100">
                          <th className="p-3 border-b border-win-gray-200">Report ID</th>
                          <th className="p-3 border-b border-win-gray-200">Patient Name</th>
                          <th className="p-3 border-b border-win-gray-200">Date</th>
                          <th className="p-3 border-b border-win-gray-200">Risk Level</th>
                          <th className="p-3 border-b border-win-gray-200">Doctor</th>
                          <th className="p-3 border-b border-win-gray-200">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {patientBehaviorReports.map(report => (
                          <tr key={report.id} className="hover:bg-win-gray-50">
                            <td className="p-3 border-b border-win-gray-200">{report.id}</td>
                            <td className="p-3 border-b border-win-gray-200">{report.patientName}</td>
                            <td className="p-3 border-b border-win-gray-200">{report.date}</td>
                            <td className="p-3 border-b border-win-gray-200">
                              <span 
                                className={`px-2 py-1 rounded-full text-xs font-medium
                                  ${report.riskLevel === 'Low' && 'bg-green-100 text-green-800'}
                                  ${report.riskLevel === 'Medium' && 'bg-yellow-100 text-yellow-800'}
                                  ${report.riskLevel === 'High' && 'bg-red-100 text-red-800'}
                                `}
                              >
                                {report.riskLevel}
                              </span>
                            </td>
                            <td className="p-3 border-b border-win-gray-200">{report.doctorName}</td>
                            <td className="p-3 border-b border-win-gray-200">
                              <button 
                                className="text-blue-500 hover:text-blue-700"
                                onClick={() => alert(`Behavior Notes: ${report.behaviorNotes}\n\nRecommended Action: ${report.recommendedAction}`)}
                              >
                                <i className="fas fa-eye mr-1"></i> View Details
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                
                {/* Discharge Reports with Behavior Section */}
                <div className="bg-white rounded shadow-lg border border-win-gray-200 p-4">
                  <h2 className="font-semibold mb-4">Patient Discharge Documentation</h2>
                  <div className="space-y-4">
                    <div className="border rounded p-4">
                      <h3 className="font-medium mb-2">Discharge Report - Michael Davis (BHV-0003)</h3>
                      <div className="space-y-2">
                        <div>
                          <span className="font-medium">Discharge Date:</span> 2025-03-22
                        </div>
                        <div>
                          <span className="font-medium">Attending Physician:</span> Dr. Thompson
                        </div>
                        <div>
                          <span className="font-medium">Behavioral Assessment:</span>
                          <div className="bg-red-50 p-2 mt-1 rounded border border-red-200">
                            <p className="text-sm">Patient exhibited hostile and aggressive behavior during discharge planning. Required extended de-escalation procedures and medication adjustment before discharge was possible. Recommended follow-up with psychiatric services within 72 hours.</p>
                          </div>
                        </div>
                        <div>
                          <span className="font-medium">Risk Assessment:</span>
                          <div className="flex items-center mt-1">
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '90%' }}></div>
                            </div>
                            <span className="ml-2 text-red-600 font-medium">High Risk</span>
                          </div>
                        </div>
                        <div className="flex justify-end mt-2">
                          <button className="text-blue-500 hover:text-blue-700 mr-2">
                            <i className="fas fa-print mr-1"></i> Print
                          </button>
                          <button className="text-blue-500 hover:text-blue-700">
                            <i className="fas fa-file-export mr-1"></i> Export
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border rounded p-4">
                      <h3 className="font-medium mb-2">Discharge Report - Emily Wilson (BHV-0004)</h3>
                      <div className="space-y-2">
                        <div>
                          <span className="font-medium">Discharge Date:</span> 2025-03-21
                        </div>
                        <div>
                          <span className="font-medium">Attending Physician:</span> Dr. Patel
                        </div>
                        <div>
                          <span className="font-medium">Behavioral Assessment:</span>
                          <div className="bg-yellow-50 p-2 mt-1 rounded border border-yellow-200">
                            <p className="text-sm">Patient displayed withdrawn behavior and reported feelings of hopelessness during discharge planning. Expressed reluctance to leave hospital environment. Care coordinator arranged home visit and mental health follow-up within one week. Family members briefed on monitoring requirements.</p>
                          </div>
                        </div>
                        <div>
                          <span className="font-medium">Risk Assessment:</span>
                          <div className="flex items-center mt-1">
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: '70%' }}></div>
                            </div>
                            <span className="ml-2 text-yellow-600 font-medium">Medium Risk</span>
                          </div>
                        </div>
                        <div className="flex justify-end mt-2">
                          <button className="text-blue-500 hover:text-blue-700 mr-2">
                            <i className="fas fa-print mr-1"></i> Print
                          </button>
                          <button className="text-blue-500 hover:text-blue-700">
                            <i className="fas fa-file-export mr-1"></i> Export
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              // Regular Reports Section
              <>
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h1 className="text-2xl font-semibold mb-1">
                      {reportType === 'patient' && 'Patient Analytics'}
                      {reportType === 'appointment' && 'Appointment Analytics'}
                      {reportType === 'inventory' && 'Inventory Analytics'}
                      {reportType === 'financial' && 'Financial Analytics'}
                    </h1>
                    <p className="text-win-gray-500">View and analyze hospital data and statistics</p>
                  </div>
                  <div className="flex space-x-2">
                    <select 
                      className="px-3 py-2 rounded border border-win-gray-300 focus:outline-none focus:border-win-blue focus:ring-1 focus:ring-win-blue"
                    >
                      <option>Last 7 Days</option>
                      <option>Last 30 Days</option>
                      <option>Last 90 Days</option>
                      <option>This Year</option>
                      <option>Custom Range</option>
                    </select>
                    <button className="px-3 py-2 rounded bg-win-blue text-white">
                      <i className="fas fa-sync-alt mr-1"></i> Refresh
                    </button>
                  </div>
                </div>
              </>
            )}
            
            {/* Patient Analytics */}
            {accessAuthorized && reportType === 'patient' && !showRestrictedReports && (
              <div className="space-y-6">
                {/* Protected Reports Access */}
                <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200 border-l-4 border-l-blue-500 mb-4">
                  <div className="flex items-start">
                    <div className="text-blue-500 mr-3 text-xl">
                      <i className="fas fa-info-circle"></i>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Patient Behavior Reports Available</h3>
                      <p className="text-gray-600 text-sm mb-2">
                        Detailed reports with patient behavior documentation and discharge assessments are available 
                        for authorized healthcare professionals.
                      </p>
                      <button 
                        onClick={() => setShowRestrictedModal(true)}
                        className="text-sm bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
                      >
                        <i className="fas fa-lock mr-1"></i> Access Patient Behavior Reports
                      </button>
                    </div>
                  </div>
                </div>
                
                {/* Dashboard Overview */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-blue bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-user-injured text-win-blue"></i>
                      </div>
                      <span className="text-win-gray-500">Total Patients</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      {patients?.length || 0}
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-green bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-procedures text-win-green"></i>
                      </div>
                      <span className="text-win-gray-500">Inpatients</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      {patients?.filter(p => p.status === 'admitted').length || 0}
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-orange bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-calendar-check text-win-orange"></i>
                      </div>
                      <span className="text-win-gray-500">Appointments Today</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      {appointments?.filter(a => {
                        const today = format(new Date(), 'yyyy-MM-dd');
                        return a.appointmentDate === today;
                      }).length || 0}
                    </div>
                  </div>
                </div>
                
                {/* Patient Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Patient Status Distribution</h2>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={patientStatusData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }: { name: string, percent: number }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {patientStatusData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Monthly Admissions</h2>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={monthlyAdmissions}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="admissions" name="Patient Admissions" fill="#0078D7" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
                
                {/* Reports List */}
                <div className="bg-white rounded shadow-lg border border-win-gray-200 p-4">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="font-semibold">Recent Patient Reports</h2>
                    <div>
                      <select 
                        value={reportFilter}
                        onChange={(e) => setReportFilter(e.target.value)}
                        className="px-3 py-2 rounded border border-win-gray-300 focus:outline-none focus:border-win-blue focus:ring-1 focus:ring-win-blue"
                      >
                        <option value="All Reports">All Reports</option>
                        <option value="Clinical">Clinical Reports</option>
                        <option value="Financial">Financial Reports</option>
                        <option value="Administrative">Administrative Reports</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    {filteredReports.length === 0 ? (
                      <div className="text-center p-8 text-win-gray-500">
                        No reports found for the selected filter.
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-left">
                          <thead>
                            <tr className="bg-win-gray-100">
                              <th className="p-3 border-b border-win-gray-200">Report ID</th>
                              <th className="p-3 border-b border-win-gray-200">Report Name</th>
                              <th className="p-3 border-b border-win-gray-200">Type</th>
                              <th className="p-3 border-b border-win-gray-200">Date</th>
                              <th className="p-3 border-b border-win-gray-200">Author</th>
                              <th className="p-3 border-b border-win-gray-200">Status</th>
                              <th className="p-3 border-b border-win-gray-200">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {filteredReports.map(report => (
                              <tr key={report.id} className="hover:bg-win-gray-50">
                                <td className="p-3 border-b border-win-gray-200">{report.id}</td>
                                <td className="p-3 border-b border-win-gray-200">{report.name}</td>
                                <td className="p-3 border-b border-win-gray-200">{report.type}</td>
                                <td className="p-3 border-b border-win-gray-200">{report.date}</td>
                                <td className="p-3 border-b border-win-gray-200">{report.author}</td>
                                <td className="p-3 border-b border-win-gray-200">
                                  <span 
                                    className={`px-2 py-1 rounded-full text-xs font-medium
                                      ${report.status === 'Completed' && 'bg-green-100 text-green-800'}
                                      ${report.status === 'In Progress' && 'bg-blue-100 text-blue-800'}
                                      ${report.status === 'Pending' && 'bg-yellow-100 text-yellow-800'}
                                    `}
                                  >
                                    {report.status}
                                  </span>
                                </td>
                                <td className="p-3 border-b border-win-gray-200">
                                  <button className="text-blue-500 hover:text-blue-700">
                                    <i className="fas fa-eye"></i>
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {/* Appointment Analytics */}
            {accessAuthorized && reportType === 'appointment' && !showRestrictedReports && (
              <div className="space-y-6">
                {/* Dashboard Overview */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-blue bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-calendar-check text-win-blue"></i>
                      </div>
                      <span className="text-win-gray-500">Total Appointments</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      {appointments?.length || 0}
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-green bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-check-circle text-win-green"></i>
                      </div>
                      <span className="text-win-gray-500">Completed</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      {appointments?.filter(a => a.status === 'completed').length || 0}
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-orange bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-clock text-win-orange"></i>
                      </div>
                      <span className="text-win-gray-500">Upcoming</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      {appointments?.filter(a => a.status === 'scheduled').length || 0}
                    </div>
                  </div>
                </div>
                
                {/* Appointment Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Appointments by Day (Last 7 Days)</h2>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={appointmentsByDayData}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="count" name="Appointments" fill="#0078D7" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Department Appointments</h2>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Cardiology', value: 35 },
                              { name: 'Orthopedics', value: 28 },
                              { name: 'Neurology', value: 22 },
                              { name: 'Pediatrics', value: 18 },
                              { name: 'Gynecology', value: 15 }
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {patientStatusData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Inventory Analytics */}
            {accessAuthorized && reportType === 'inventory' && !showRestrictedReports && (
              <div className="space-y-6">
                {/* Inventory Overview */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-blue bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-boxes text-win-blue"></i>
                      </div>
                      <span className="text-win-gray-500">Total Items</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      {inventory?.length || 0}
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-green bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-pills text-win-green"></i>
                      </div>
                      <span className="text-win-gray-500">Medications</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      {inventory?.filter(i => i.category === 'medication').length || 0}
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-red bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-exclamation-triangle text-win-red"></i>
                      </div>
                      <span className="text-win-gray-500">Low Stock</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      {inventory?.filter(i => (i.reorderLevel || 0) > 0 && (i.quantity || 0) <= (i.reorderLevel || 0)).length || 0}
                    </div>
                  </div>
                </div>
                
                {/* Inventory Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Inventory Value by Category</h2>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={inventoryValueByCategory}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {inventoryValueByCategory.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: any) => [`$${Number(value).toFixed(2)}`, 'Value']} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Low Stock Items</h2>
                    <div className="overflow-auto max-h-64">
                      <table className="min-w-full">
                        <thead className="bg-win-gray-100">
                          <tr>
                            <th className="p-2 text-left">Item</th>
                            <th className="p-2 text-left">Category</th>
                            <th className="p-2 text-left">Stock</th>
                            <th className="p-2 text-left">Reorder At</th>
                          </tr>
                        </thead>
                        <tbody>
                          {lowStockItems.map(item => (
                            <tr key={item.id} className="border-t border-win-gray-200">
                              <td className="p-2">{item.itemName}</td>
                              <td className="p-2">{item.category}</td>
                              <td className="p-2">
                                <span className={`px-2 py-0.5 rounded-full text-xs ${(item.quantity || 0) < (item.reorderLevel || 1) / 2 ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                  {item.quantity}
                                </span>
                              </td>
                              <td className="p-2">{item.reorderLevel}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Financial Analytics */}
            {accessAuthorized && reportType === 'financial' && !showRestrictedReports && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-blue bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-chart-line text-win-blue"></i>
                      </div>
                      <span className="text-win-gray-500">Monthly Revenue</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      $245,320.00
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-green bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-arrow-up text-win-green"></i>
                      </div>
                      <span className="text-win-gray-500">Increase YoY</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      +12.4%
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm p-4 border border-win-gray-200">
                    <div className="flex items-center mb-2">
                      <div className="w-10 h-10 bg-win-orange bg-opacity-10 rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-file-invoice-dollar text-win-orange"></i>
                      </div>
                      <span className="text-win-gray-500">Outstanding Invoices</span>
                    </div>
                    <div className="text-2xl font-semibold">
                      $34,250.00
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Monthly Revenue (2025)</h2>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { month: 'Jan', revenue: 193500 },
                            { month: 'Feb', revenue: 205800 },
                            { month: 'Mar', revenue: 245320 }
                          ]}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis tickFormatter={(value) => `$${value/1000}k`} />
                          <Tooltip formatter={(value: any) => [`$${Number(value).toFixed(2)}`, 'Revenue']} />
                          <Legend />
                          <Bar dataKey="revenue" name="Revenue" fill="#0078D7" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded shadow-sm border border-win-gray-200 p-4">
                    <h2 className="font-semibold mb-4">Expense Distribution</h2>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Staff', value: 125000 },
                              { name: 'Supplies', value: 65000 },
                              { name: 'Equipment', value: 32000 },
                              { name: 'Utilities', value: 21000 },
                              { name: 'Maintenance', value: 18000 },
                              { name: 'Other', value: 5200 },
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {patientStatusData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: any) => [`$${Number(value).toFixed(2)}`, 'Value']} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}