import React, { useState, useEffect } from 'react';
import { useWindowContext } from '@/context/WindowContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "@/hooks/use-toast";
import { Search, X, RefreshCw } from 'lucide-react';

interface WindowTask {
  id: string;
  name: string;
  icon: string;
  memory: string;
  cpu: string;
  status: 'Running' | 'Not Responding';
}

export default function TaskManager() {
  const { windows, closeWindow } = useWindowContext();
  const [tasks, setTasks] = useState<WindowTask[]>([]);
  const [systemTasks, setSystemTasks] = useState<WindowTask[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredTasks, setFilteredTasks] = useState<WindowTask[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  // Generate system background tasks
  useEffect(() => {
    const backgroundTasks: WindowTask[] = [
      {
        id: 'system_kernel',
        name: 'Hospital OS Kernel',
        icon: 'fas fa-microchip',
        memory: '45 MB',
        cpu: '1%',
        status: 'Running'
      },
      {
        id: 'system_services',
        name: 'System Services',
        icon: 'fas fa-cogs',
        memory: '124 MB',
        cpu: '3%',
        status: 'Running'
      },
      {
        id: 'background_updates',
        name: 'Background Updates',
        icon: 'fas fa-sync-alt',
        memory: '78 MB',
        cpu: '2%',
        status: 'Running'
      },
      {
        id: 'security_manager',
        name: 'Security Manager',
        icon: 'fas fa-shield-alt',
        memory: '86 MB',
        cpu: '1%',
        status: 'Running'
      },
      {
        id: 'database_service',
        name: 'Database Service',
        icon: 'fas fa-database',
        memory: '156 MB',
        cpu: '5%',
        status: 'Running'
      },
      {
        id: 'network_manager',
        name: 'Network Manager',
        icon: 'fas fa-network-wired',
        memory: '42 MB',
        cpu: '1%',
        status: 'Running'
      }
    ];
    setSystemTasks(backgroundTasks);
  }, []);

  // Convert windows to tasks
  useEffect(() => {
    const windowTasks: WindowTask[] = windows.filter(w => w.isOpen).map(window => {
      // Generate random memory and CPU usage for each window
      const memory = Math.floor(Math.random() * 200) + 50;
      const cpu = Math.floor(Math.random() * 5) + 1;
      
      return {
        id: window.id,
        name: window.title,
        icon: window.icon,
        memory: `${memory} MB`,
        cpu: `${cpu}%`,
        status: 'Running'
      };
    });
    
    setTasks([...windowTasks, ...systemTasks]);
  }, [windows, systemTasks]);

  // Filter tasks based on search query
  useEffect(() => {
    if (searchQuery) {
      setFilteredTasks(tasks.filter(task => 
        task.name.toLowerCase().includes(searchQuery.toLowerCase())
      ));
    } else {
      setFilteredTasks(tasks);
    }
  }, [searchQuery, tasks]);

  // End a task (close a window)
  const handleEndTask = (id: string) => {
    // Check if it's a system task
    if (id.startsWith('system_')) {
      toast({
        title: "Cannot End System Task",
        description: "System tasks cannot be terminated.",
        variant: "destructive"
      });
      return;
    }
    
    closeWindow(id);
    
    toast({
      title: "Task Ended",
      description: `${tasks.find(t => t.id === id)?.name} has been terminated.`
    });
  };

  // Simulate refreshing task list
  const handleRefresh = () => {
    setRefreshing(true);
    
    setTimeout(() => {
      // Update CPU and memory values
      const updatedTasks = tasks.map(task => ({
        ...task,
        memory: `${Math.floor(Math.random() * 200) + 50} MB`,
        cpu: `${Math.floor(Math.random() * 5) + 1}%`
      }));
      
      setTasks(updatedTasks);
      setRefreshing(false);
      
      toast({
        title: "Task List Refreshed",
        description: "Process information has been updated."
      });
    }, 800);
  };

  return (
    <div className="h-full overflow-auto p-4 bg-gray-50">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center">
          <i className="fas fa-tasks mr-2"></i> Task Manager
        </h1>
        <p className="text-gray-600">Manage running applications and system processes</p>
      </div>

      <Card className="shadow-md">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Running Processes</CardTitle>
              <CardDescription>Manage and monitor system tasks</CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search tasks..."
                  className="pl-8 w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleRefresh}
                disabled={refreshing}
                className="flex items-center"
              >
                <RefreshCw className={`h-4 w-4 mr-1 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Memory</TableHead>
                  <TableHead>CPU</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTasks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-gray-500 py-10">
                      No tasks found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTasks.map(task => (
                    <TableRow key={task.id}>
                      <TableCell className="flex items-center">
                        <i className={`${task.icon} mr-2 text-gray-600`}></i>
                        <span className="font-medium">{task.name}</span>
                      </TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                          task.status === 'Running' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {task.status}
                        </span>
                      </TableCell>
                      <TableCell>{task.memory}</TableCell>
                      <TableCell>{task.cpu}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleEndTask(task.id)}
                          disabled={task.id.startsWith('system_')}
                        >
                          <X className="h-4 w-4 mr-1" />
                          End Task
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </ScrollArea>
          <div className="text-xs text-gray-500 mt-4">
            <p>
              <strong>Total:</strong> {filteredTasks.length} processes running | 
              <strong> Memory Usage:</strong> {Math.floor(Math.random() * 2000) + 500} MB | 
              <strong> CPU Usage:</strong> {Math.floor(Math.random() * 30) + 10}%
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}