import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { AlertCircle, Check, Copy, EyeOff, Key, Lock, Save, Trash2 } from 'lucide-react';
import { useWindowContext } from "@/context/WindowContext";

interface PasswordEntry {
  id: string;
  name: string;
  password: string;
  description: string;
  lastModified: string;
}

interface SystemControl {
  id: string;
  name: string;
  status: boolean;
  description: string;
  requiresConfirmation: boolean;
}

export default function AdminControlPanel() {
  const { openWindow } = useWindowContext();
  
  // Password management state
  const [passwords, setPasswords] = useState<PasswordEntry[]>([]);
  const [newPassword, setNewPassword] = useState<Omit<PasswordEntry, 'id' | 'lastModified'>>({
    name: '',
    password: '',
    description: ''
  });
  const [showPasswords, setShowPasswords] = useState<{[key: string]: boolean}>({});

  // System controls state
  const [systemControls, setSystemControls] = useState<SystemControl[]>([]);
  const [confirmationCode, setConfirmationCode] = useState('');
  const [confirmingAction, setConfirmingAction] = useState<string | null>(null);

  // Logs state
  const [systemLogs, setSystemLogs] = useState<string[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<string[]>([]);
  const [logFilter, setLogFilter] = useState('');

  // Load data on mount
  useEffect(() => {
    // Load passwords from localStorage
    const savedPasswords = localStorage.getItem('hospitalOS_admin_passwords');
    if (savedPasswords) {
      try {
        setPasswords(JSON.parse(savedPasswords));
      } catch (e) {
        console.error("Failed to parse saved passwords:", e);
      }
    } else {
      // Initialize with default passwords if none found
      const defaultPasswords: PasswordEntry[] = [
        {
          id: '1',
          name: 'System Access Code',
          password: '1234',
          description: 'Terminal full control access code',
          lastModified: new Date().toISOString()
        },
        {
          id: '2',
          name: 'Reports Access',
          password: 'reports123',
          description: 'Access code for detailed hospital reports',
          lastModified: new Date().toISOString()
        },
        {
          id: '3',
          name: 'System Administrator',
          password: 'admin123',
          description: 'Administrative access to core system functions',
          lastModified: new Date().toISOString()
        },
        {
          id: '4',
          name: 'Database Access',
          password: 'db_secure456',
          description: 'Secure credentials for database management system',
          lastModified: new Date().toISOString()
        },
        {
          id: '5',
          name: 'Pharmacy Controls',
          password: 'pharm789',
          description: 'Access to pharmacy inventory and medication management',
          lastModified: new Date().toISOString()
        },
        {
          id: '6',
          name: 'Emergency Override',
          password: 'emergency911',
          description: 'Emergency access override for critical situations',
          lastModified: new Date().toISOString()
        },
        {
          id: '7',
          name: 'Network Security',
          password: 'network567',
          description: 'Network infrastructure security credentials',
          lastModified: new Date().toISOString()
        }
      ];
      setPasswords(defaultPasswords);
      localStorage.setItem('hospitalOS_admin_passwords', JSON.stringify(defaultPasswords));
    }

    // Initialize system controls
    const defaultControls: SystemControl[] = [
      {
        id: 'security',
        name: 'Enhanced Security Mode',
        status: true,
        description: 'Enables additional security measures and logging',
        requiresConfirmation: false
      },
      {
        id: 'maintenance',
        name: 'System Maintenance Mode',
        status: false,
        description: 'Restricts user access during maintenance',
        requiresConfirmation: true
      },
      {
        id: 'auditing',
        name: 'Audit Logging',
        status: true,
        description: 'Records all system activity for compliance',
        requiresConfirmation: false
      },
      {
        id: 'emergency',
        name: 'Emergency Protocol',
        status: false,
        description: 'Activates emergency procedures and alerts',
        requiresConfirmation: true
      }
    ];
    setSystemControls(defaultControls);

    // Generate mock system logs
    const mockLogs = [
      '[SYSTEM] System initialized - March 27, 2025 08:00:23',
      '[SECURITY] User authentication successful - March 27, 2025 08:15:47',
      '[DATABASE] Database connection established - March 27, 2025 08:00:25',
      '[USER] User "admin" logged in - March 27, 2025 08:15:48',
      '[SECURITY] Terminal access attempted - March 27, 2025 08:32:10',
      '[SECURITY] System access code verified - March 27, 2025 08:32:15',
      '[ADMIN] Full control mode activated - March 27, 2025 08:32:15',
      '[SYSTEM] Background services started - March 27, 2025 08:00:30',
      '[NETWORK] Network integrity check passed - March 27, 2025 08:00:35',
      '[SECURITY] Configuration file access - March 27, 2025 08:35:42',
      '[USER] Settings modified by "admin" - March 27, 2025 08:36:17',
      '[SYSTEM] Memory optimization complete - March 27, 2025 09:00:00',
      '[DATABASE] Scheduled backup started - March 27, 2025 09:30:00',
      '[DATABASE] Backup completed successfully - March 27, 2025 09:32:45',
      '[SECURITY] Invalid access attempt blocked - March 27, 2025 10:15:22',
      '[ADMIN] Admin control panel opened - March 27, 2025 ' + new Date().toLocaleTimeString()
    ];
    setSystemLogs(mockLogs);
    setFilteredLogs(mockLogs);
  }, []);

  // Filter logs when filter changes
  useEffect(() => {
    if (!logFilter) {
      setFilteredLogs(systemLogs);
    } else {
      setFilteredLogs(systemLogs.filter(log => 
        log.toLowerCase().includes(logFilter.toLowerCase())
      ));
    }
  }, [logFilter, systemLogs]);

  // Add new password
  const handleAddPassword = () => {
    if (!newPassword.name || !newPassword.password) {
      toast({
        title: "Missing Information",
        description: "Name and password are required.",
        variant: "destructive"
      });
      return;
    }

    const newEntry: PasswordEntry = {
      id: Date.now().toString(),
      name: newPassword.name,
      password: newPassword.password,
      description: newPassword.description,
      lastModified: new Date().toISOString()
    };

    const updatedPasswords = [...passwords, newEntry];
    setPasswords(updatedPasswords);
    localStorage.setItem('hospitalOS_admin_passwords', JSON.stringify(updatedPasswords));
    
    // Reset form
    setNewPassword({
      name: '',
      password: '',
      description: ''
    });

    // Add to logs
    const logEntry = `[ADMIN] New password entry created: "${newPassword.name}" - March 27, 2025 ${new Date().toLocaleTimeString()}`;
    setSystemLogs(prev => [logEntry, ...prev]);

    toast({
      title: "Password Added",
      description: "New password entry has been created.",
    });
  };

  // Delete password
  const handleDeletePassword = (id: string) => {
    const passwordToDelete = passwords.find(p => p.id === id);
    const updatedPasswords = passwords.filter(password => password.id !== id);
    setPasswords(updatedPasswords);
    localStorage.setItem('hospitalOS_admin_passwords', JSON.stringify(updatedPasswords));

    // Add to logs
    if (passwordToDelete) {
      const logEntry = `[ADMIN] Password entry deleted: "${passwordToDelete.name}" - March 27, 2025 ${new Date().toLocaleTimeString()}`;
      setSystemLogs(prev => [logEntry, ...prev]);
    }

    toast({
      title: "Password Deleted",
      description: "Password entry has been removed.",
    });
  };

  // Update password
  const handleUpdatePassword = (id: string, field: keyof PasswordEntry, value: string) => {
    const updatedPasswords = passwords.map(password => {
      if (password.id === id) {
        return {
          ...password,
          [field]: value,
          lastModified: new Date().toISOString()
        };
      }
      return password;
    });
    
    setPasswords(updatedPasswords);
    localStorage.setItem('hospitalOS_admin_passwords', JSON.stringify(updatedPasswords));
    
    // Add to logs
    const passwordName = passwords.find(p => p.id === id)?.name;
    const logEntry = `[ADMIN] Password "${passwordName}" updated - March 27, 2025 ${new Date().toLocaleTimeString()}`;
    setSystemLogs(prev => [logEntry, ...prev]);
  };

  // Toggle password visibility
  const togglePasswordVisibility = (id: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // Copy password to clipboard
  const copyToClipboard = (text: string, name: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied to Clipboard",
        description: `${name} has been copied to clipboard.`,
      });
    });
  };

  // Toggle system control
  const handleToggleControl = (id: string) => {
    const control = systemControls.find(c => c.id === id);
    
    if (control?.requiresConfirmation && !confirmingAction) {
      setConfirmingAction(id);
      return;
    }
    
    if (confirmingAction === id && confirmationCode !== '1234') {
      toast({
        title: "Invalid Code",
        description: "The confirmation code is incorrect.",
        variant: "destructive"
      });
      return;
    }
    
    const updatedControls = systemControls.map(control => {
      if (control.id === id) {
        return {
          ...control,
          status: !control.status
        };
      }
      return control;
    });
    
    setSystemControls(updatedControls);
    setConfirmingAction(null);
    setConfirmationCode('');
    
    // Add to logs
    const controlName = control?.name;
    const newStatus = !control?.status;
    const logEntry = `[ADMIN] System control "${controlName}" ${newStatus ? 'activated' : 'deactivated'} - March 27, 2025 ${new Date().toLocaleTimeString()}`;
    setSystemLogs(prev => [logEntry, ...prev]);

    toast({
      title: "Control Updated",
      description: `${controlName} has been ${newStatus ? 'activated' : 'deactivated'}.`,
    });
  };

  return (
    <div className="h-full overflow-auto p-4 bg-gray-50">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center">
          <Lock className="mr-2" /> Admin Control Panel
        </h1>
        <p className="text-gray-600">System administration and security management</p>
      </div>

      <Tabs defaultValue="passwords" className="w-full">
        <TabsList className="mb-4 bg-gray-200">
          <TabsTrigger value="passwords" className="data-[state=active]:bg-white">
            <Key className="h-4 w-4 mr-2" />
            Password Management
          </TabsTrigger>
          <TabsTrigger value="controls" className="data-[state=active]:bg-white">
            <AlertCircle className="h-4 w-4 mr-2" />
            System Controls
          </TabsTrigger>
          <TabsTrigger value="logs" className="data-[state=active]:bg-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-2">
              <path d="M12 12h.01" />
              <path d="M12 6h.01" />
              <path d="M12 18h.01" />
              <path d="M18 12h.01" />
              <path d="M18 6h.01" />
              <path d="M18 18h.01" />
              <path d="M6 12h.01" />
              <path d="M6 6h.01" />
              <path d="M6 18h.01" />
            </svg>
            System Logs
          </TabsTrigger>
        </TabsList>
        
        {/* Password Management */}
        <TabsContent value="passwords">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {/* Current Passwords */}
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Secure Credentials</CardTitle>
                <CardDescription>Manage system passwords and access codes</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {passwords.length === 0 ? (
                  <div className="text-center p-4 text-gray-500">
                    No passwords saved yet
                  </div>
                ) : (
                  passwords.map(password => (
                    <div key={password.id} className="p-3 border rounded-md">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-medium text-gray-900">{password.name}</h3>
                          <p className="text-xs text-gray-500">Last modified: {new Date(password.lastModified).toLocaleString()}</p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleDeletePassword(password.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                      
                      <div className="mb-2">
                        <div className="flex items-center mb-1">
                          <Label className="text-xs text-gray-500 flex-1">Password</Label>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-6 w-6 p-0"
                            onClick={() => togglePasswordVisibility(password.id)}
                          >
                            <EyeOff className="h-3 w-3" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-6 w-6 p-0 ml-1"
                            onClick={() => copyToClipboard(password.password, password.name)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="flex">
                          <Input 
                            type={showPasswords[password.id] ? "text" : "password"} 
                            value={password.password}
                            onChange={(e) => handleUpdatePassword(password.id, 'password', e.target.value)}
                            className="flex-1 text-sm"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-xs text-gray-500">Description</Label>
                        <Input 
                          type="text" 
                          value={password.description}
                          onChange={(e) => handleUpdatePassword(password.id, 'description', e.target.value)}
                          className="text-sm"
                        />
                      </div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
            
            {/* Add New Password */}
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Add New Credential</CardTitle>
                <CardDescription>Create a new password entry</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Name</Label>
                    <Input 
                      id="name" 
                      value={newPassword.name}
                      onChange={(e) => setNewPassword({...newPassword, name: e.target.value})}
                      placeholder="e.g., Database Access"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input 
                      id="password" 
                      type="text"
                      value={newPassword.password}
                      onChange={(e) => setNewPassword({...newPassword, password: e.target.value})}
                      placeholder="Enter secure password"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Input 
                      id="description" 
                      value={newPassword.description}
                      onChange={(e) => setNewPassword({...newPassword, description: e.target.value})}
                      placeholder="What is this password used for?"
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleAddPassword} className="w-full">
                  <Save className="mr-2 h-4 w-4" /> Save New Password
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        {/* System Controls */}
        <TabsContent value="controls">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>System Control Center</CardTitle>
              <CardDescription>Manage critical system functions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {systemControls.map(control => (
                  <div key={control.id} className="p-4 border rounded-md bg-white">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{control.name}</h3>
                        <p className="text-sm text-gray-500">{control.description}</p>
                        
                        {confirmingAction === control.id && (
                          <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded">
                            <p className="text-sm text-yellow-700 mb-2">This action requires confirmation. Enter system access code:</p>
                            <div className="flex">
                              <Input 
                                type="password" 
                                value={confirmationCode}
                                onChange={(e) => setConfirmationCode(e.target.value)}
                                className="flex-1 mr-2"
                              />
                              <Button onClick={() => handleToggleControl(control.id)} size="sm">
                                Confirm
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex items-center">
                        <span className={`text-sm mr-2 ${control.status ? 'text-green-600' : 'text-gray-500'}`}>
                          {control.status ? 'Active' : 'Inactive'}
                        </span>
                        <Switch
                          checked={control.status}
                          onCheckedChange={() => handleToggleControl(control.id)}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <p className="text-sm text-gray-500">Some controls require system access code</p>
              <Button variant="outline">
                <Check className="mr-2 h-4 w-4" /> Save All Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* System Logs */}
        <TabsContent value="logs">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>System Activity Logs</CardTitle>
              <CardDescription>Review system activity and security events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Label htmlFor="log-filter" className="sr-only">Filter logs</Label>
                <Input 
                  id="log-filter" 
                  placeholder="Filter logs (e.g., SECURITY, ADMIN, etc.)" 
                  value={logFilter}
                  onChange={(e) => setLogFilter(e.target.value)}
                />
              </div>
              
              <div className="bg-black text-gray-200 font-mono text-xs p-4 rounded h-96 overflow-y-auto">
                {filteredLogs.map((log, index) => {
                  // Color-code different log types
                  let logClass = "text-gray-300";
                  if (log.includes("[SECURITY]")) logClass = "text-yellow-400";
                  else if (log.includes("[ADMIN]")) logClass = "text-blue-400";
                  else if (log.includes("[ERROR]")) logClass = "text-red-400";
                  else if (log.includes("[SYSTEM]")) logClass = "text-green-400";
                  else if (log.includes("[DATABASE]")) logClass = "text-purple-400";
                  else if (log.includes("[USER]")) logClass = "text-cyan-400";
                  else if (log.includes("[NETWORK]")) logClass = "text-indigo-400";
                  
                  return (
                    <div key={index} className={`${logClass} mb-1`}>
                      {log}
                    </div>
                  );
                })}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <span className="text-sm text-gray-500">Showing {filteredLogs.length} of {systemLogs.length} logs</span>
              <Button variant="outline" size="sm">
                Export Logs
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}