import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { User } from '@shared/schema';
import StaffForm from './StaffForm';

export default function StaffWindow() {
  const queryClient = useQueryClient();
  const [isAddingStaff, setIsAddingStaff] = useState(false);
  const [currentStaff, setCurrentStaff] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  
  // Fetch staff
  const { data: staff, isLoading } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });
  
  const deleteStaffMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/users/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    }
  });
  
  const handleAddNew = () => {
    setCurrentStaff(null);
    setIsAddingStaff(true);
  };
  
  const handleEdit = (user: User) => {
    setCurrentStaff(user);
    setIsAddingStaff(true);
  };
  
  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this staff member?')) {
      deleteStaffMutation.mutate(id);
    }
  };
  
  const handleFormClose = () => {
    setIsAddingStaff(false);
    setCurrentStaff(null);
  };
  
  const handleFormSubmit = () => {
    setIsAddingStaff(false);
    setCurrentStaff(null);
    queryClient.invalidateQueries({ queryKey: ['/api/users'] });
  };
  
  // Filter staff based on search and role filter
  const filteredStaff = staff?.filter(user => {
    const matchesSearch = 
      searchTerm === '' || 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.email && user.email.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    
    return matchesSearch && matchesRole;
  }) || [];
  
  // Group staff by department for department view
  const staffByDepartment = filteredStaff.reduce((acc, user) => {
    const dept = user.department || 'Unassigned';
    if (!acc[dept]) {
      acc[dept] = [];
    }
    acc[dept].push(user);
    return acc;
  }, {} as Record<string, User[]>);
  
  // Calculate counts by role
  const roleCounts = staff?.reduce((acc, user) => {
    const role = user.role;
    acc[role] = (acc[role] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};
  
  // Get initials from name
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase();
  };
  
  // Get color based on role
  const getRoleColor = (role: string) => {
    switch (role) {
      case 'doctor': return 'bg-win-green';
      case 'nurse': return 'bg-win-blue';
      case 'admin': return 'bg-win-orange';
      case 'receptionist': return 'bg-win-red';
      default: return 'bg-win-gray-500';
    }
  };
  
  const getRoleName = (role: string) => {
    switch (role) {
      case 'doctor': return 'Doctor';
      case 'nurse': return 'Nurse';
      case 'admin': return 'Administrator';
      case 'receptionist': return 'Receptionist';
      default: return role.charAt(0).toUpperCase() + role.slice(1);
    }
  };
  
  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <div className="w-56 bg-win-gray-100 border-r border-win-gray-300 p-2">
        <div className="mb-6">
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">STAFF FILTERS</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={() => setRoleFilter('all')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${roleFilter === 'all' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-users w-5"></i>
                <span>All Staff ({staff?.length || 0})</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setRoleFilter('doctor')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${roleFilter === 'doctor' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-user-md w-5"></i>
                <span>Doctors ({roleCounts.doctor || 0})</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setRoleFilter('nurse')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${roleFilter === 'nurse' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-user-nurse w-5"></i>
                <span>Nurses ({roleCounts.nurse || 0})</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setRoleFilter('admin')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${roleFilter === 'admin' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-user-tie w-5"></i>
                <span>Administrators ({roleCounts.admin || 0})</span>
              </button>
            </li>
            <li className="mb-1">
              <button 
                onClick={() => setRoleFilter('receptionist')}
                className={`flex w-full items-center px-2 py-2 text-sm rounded-sm ${roleFilter === 'receptionist' ? 'bg-win-blue text-white' : 'hover:bg-win-gray-200'}`}
              >
                <i className="fas fa-user-tag w-5"></i>
                <span>Receptionists ({roleCounts.receptionist || 0})</span>
              </button>
            </li>
          </ul>
        </div>
        
        <div>
          <div className="text-sm font-medium text-win-gray-500 mb-2 pl-2">ACTIONS</div>
          <ul>
            <li className="mb-1">
              <button 
                onClick={handleAddNew} 
                className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200"
              >
                <i className="fas fa-user-plus w-5"></i>
                <span>Add New Staff</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-calendar-week w-5"></i>
                <span>View Schedules</span>
              </button>
            </li>
            <li className="mb-1">
              <button className="flex w-full items-center px-2 py-2 text-sm rounded-sm hover:bg-win-gray-200">
                <i className="fas fa-file-export w-5"></i>
                <span>Export Staff List</span>
              </button>
            </li>
          </ul>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 p-4 overflow-auto scrollbar">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold mb-1">Staff Portal</h1>
            <p className="text-win-gray-500">Manage hospital staff information and departments</p>
          </div>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search staff..." 
              className="pl-10 pr-4 py-2 rounded border border-win-gray-300 focus:outline-none focus:border-win-blue focus:ring-1 focus:ring-win-blue w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-win-gray-500"></i>
          </div>
        </div>
        
        {/* Staff List */}
        <div className="bg-white rounded shadow-sm border border-win-gray-200 mb-6">
          <div className="px-4 py-3 border-b border-win-gray-200 flex justify-between items-center">
            <h2 className="font-semibold">
              {roleFilter === 'all' ? 'All Staff' : `${getRoleName(roleFilter)}s`}
            </h2>
            <div className="flex space-x-2">
              <button 
                onClick={handleAddNew}
                className="px-3 py-1 text-sm rounded bg-win-blue text-white"
              >
                <i className="fas fa-plus mr-1"></i> Add Staff
              </button>
              <button className="px-3 py-1 text-sm rounded border border-win-gray-300 hover:bg-win-gray-100">
                <i className="fas fa-filter"></i>
              </button>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-win-blue"></div>
            </div>
          ) : filteredStaff.length === 0 ? (
            <p className="text-center py-8 text-win-gray-500">No staff members found</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="text-left text-sm text-win-gray-500 border-b border-win-gray-200">
                    <th className="px-4 py-3 font-medium">Name</th>
                    <th className="px-4 py-3 font-medium">Username</th>
                    <th className="px-4 py-3 font-medium">Role</th>
                    <th className="px-4 py-3 font-medium">Department</th>
                    <th className="px-4 py-3 font-medium">Specialty</th>
                    <th className="px-4 py-3 font-medium">Contact</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                    <th className="px-4 py-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredStaff.map(user => (
                    <tr key={user.id} className="border-b border-win-gray-200 hover:bg-win-gray-50 text-sm">
                      <td className="px-4 py-3 flex items-center">
                        <div className={`w-8 h-8 rounded-full ${getRoleColor(user.role)} flex items-center justify-center mr-2 text-white text-xs`}>
                          {getInitials(user.name)}
                        </div>
                        <span>{user.name}</span>
                      </td>
                      <td className="px-4 py-3">{user.username}</td>
                      <td className="px-4 py-3">{getRoleName(user.role)}</td>
                      <td className="px-4 py-3">{user.department || 'N/A'}</td>
                      <td className="px-4 py-3">{user.specialty || 'N/A'}</td>
                      <td className="px-4 py-3">{user.contact || 'N/A'}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          user.status === 'active' ? 'bg-win-green bg-opacity-10 text-win-green' :
                          user.status === 'on leave' ? 'bg-win-orange bg-opacity-10 text-win-orange' :
                          'bg-win-red bg-opacity-10 text-win-red'
                        }`}>
                          {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => handleEdit(user)} 
                            className="text-win-blue hover:underline"
                          >
                            <i className="fas fa-edit"></i>
                          </button>
                          <button 
                            onClick={() => handleDelete(user.id)} 
                            className="text-win-red hover:underline"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        
        {/* Departments Overview */}
        <div className="bg-white rounded shadow-sm border border-win-gray-200">
          <div className="px-4 py-3 border-b border-win-gray-200">
            <h2 className="font-semibold">Staff by Department</h2>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.entries(staffByDepartment).map(([department, users]) => (
                <div key={department} className="border border-win-gray-200 rounded p-3">
                  <h3 className="font-medium text-win-gray-800 mb-2">{department}</h3>
                  <div className="space-y-2">
                    {users.slice(0, 5).map(user => (
                      <div key={user.id} className="flex items-center text-sm">
                        <div className={`w-6 h-6 rounded-full ${getRoleColor(user.role)} flex items-center justify-center mr-2 text-white text-xs`}>
                          {getInitials(user.name)}
                        </div>
                        <div className="flex-1 truncate">{user.name}</div>
                        <div className="text-xs text-win-gray-500">{getRoleName(user.role)}</div>
                      </div>
                    ))}
                    {users.length > 5 && (
                      <div className="text-sm text-win-blue">
                        +{users.length - 5} more staff
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* Staff Form Modal */}
      {isAddingStaff && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-md w-[700px] max-h-[90vh] overflow-auto">
            <StaffForm 
              staff={currentStaff}
              onClose={handleFormClose}
              onSubmit={handleFormSubmit}
            />
          </div>
        </div>
      )}
    </div>
  );
}
