import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, TableBody, TableCell, TableHead, 
  TableHeader, TableRow 
} from "@/components/ui/table";
import { 
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, 
  BreadcrumbList, BreadcrumbSeparator 
} from "@/components/ui/breadcrumb";
import { 
  DropdownMenu, DropdownMenuContent, 
  DropdownMenuItem, DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, DialogContent, DialogDescription, 
  DialogFooter, DialogHeader, DialogTitle, DialogClose
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Search, Folder, File, FileText, MoreVertical, 
  ArrowUp, RefreshCw, Plus, Trash2, FileCog, Edit, Download,
  Info, Settings, Shield, HardDrive, Database, Cog, Lock,
  FileJson, FileBadge, FileCode, FileTerminal, Network
} from 'lucide-react';

// Define File and Folder types
interface FileItem {
  id: string;
  name: string;
  type: 'file';
  size: string;
  lastModified: string;
  content?: string;
}

interface FolderItem {
  id: string;
  name: string;
  type: 'folder';
  lastModified: string;
  items: (FileItem | FolderItem)[];
}

type FileSystemItem = FileItem | FolderItem;

export default function FilesWindow() {
  // State for the current directory path and items
  const [currentPath, setCurrentPath] = useState<string[]>(['Home']);
  const [currentItems, setCurrentItems] = useState<FileSystemItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<FileSystemItem | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newItemType, setNewItemType] = useState<'file' | 'folder'>('folder');
  const [newItemName, setNewItemName] = useState('');
  const [fileContent, setFileContent] = useState('');
  const [isFileDialogOpen, setIsFileDialogOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  // State for first-time setup - extended with more options
  // Check if this is the first time setup, by checking localStorage
  const [isFirstTimeSetup, setIsFirstTimeSetup] = useState(() => {
    // If the flag doesn't exist in localStorage, it's a first-time user
    return localStorage.getItem('hospitalOSFirstTimeSetup') !== 'true';
  });
  const [setupStep, setSetupStep] = useState(1);
  const [setupProgress, setSetupProgress] = useState(0);
  const [userName, setUserName] = useState('');
  const [userDepartment, setUserDepartment] = useState('');
  const [userRole, setUserRole] = useState('');
  const [userAccessLevel, setUserAccessLevel] = useState('Standard');
  const [setupOptions, setSetupOptions] = useState({
    includeSampleFiles: true,
    includeSystemFiles: true,
    enableAutoBackup: true,
    setupSecurityProtocol: true,
    installAdvancedFeatures: false,
    enableDataEncryption: true,
    installDepartmentTemplates: true,
    setupUserSpecificWorkspace: true,
    enableNetworkSharing: false,
    installMedicalDatabases: true,
    setupAdvancedReporting: false,
    integrateWithLaboratory: true,
    setupAutomaticUpdates: true,
    enableCloudSync: false,
    installSecuritySuite: true
  });
  const [installProgress, setInstallProgress] = useState(0);
  const [currentInstallItem, setCurrentInstallItem] = useState('');
  const [installStage, setInstallStage] = useState(0);
  const [isInstallingFiles, setIsInstallingFiles] = useState(false);
  const [isSetupComplete, setIsSetupComplete] = useState(false);
  const [licenseAgreementAccepted, setLicenseAgreementAccepted] = useState(false);
  const [securityQuestions, setSecurityQuestions] = useState({
    question1: '',
    answer1: '',
    question2: '',
    answer2: ''
  });
  const [networkSettings, setNetworkSettings] = useState({
    useDefaultSettings: true,
    hostname: 'Hospital-Workstation',
    domain: 'hospital.local',
    connectionType: 'Wired'
  });

  // Check for first-time setup
  useEffect(() => {
    // For actual production, remove this line:
    // localStorage.removeItem('hospitalOSFirstTimeSetup');
    
    const firstTimeSetupComplete = localStorage.getItem('hospitalOSFirstTimeSetup');
    const savedFileSystem = localStorage.getItem('hospitalFileSystem');
    
    if (!firstTimeSetupComplete) {
      // This is a first-time user, show setup wizard
      setIsFirstTimeSetup(true);
      // Reset state to ensure clean setup
      setSetupStep(1);
      setSetupProgress(10);
    } else if (savedFileSystem) {
      // User has completed setup and has a saved filesystem
      const fileSystem = JSON.parse(savedFileSystem);
      navigateToPath(currentPath);
    } else {
      // Initialize the file system if first-time setup was completed previously but filesystem was deleted
      createDefaultFileSystem();
    }
  }, []);
  
  // Creating a comprehensive file system with system files
  const createDefaultFileSystem = () => {
    const defaultFileSystem: FolderItem = {
      id: 'root',
      name: 'Home',
      type: 'folder',
      lastModified: new Date().toISOString(),
      items: [
        {
          id: 'docs',
          name: 'Documents',
          type: 'folder',
          lastModified: new Date().toISOString(),
          items: [
            {
              id: 'procedures',
              name: 'Hospital Procedures.pdf',
              type: 'file',
              size: '2.4 MB',
              lastModified: new Date().toISOString(),
              content: 'Standard hospital procedures document. Updated annually with the latest medical protocols and safety procedures.'
            },
            {
              id: 'policy',
              name: 'Policy Manual.pdf',
              type: 'file',
              size: '4.7 MB',
              lastModified: new Date().toISOString(),
              content: 'Hospital policy manual including patient care guidelines and staff protocols. Includes sections on HIPAA compliance and emergency procedures.'
            },
            {
              id: 'staff_handbook',
              name: 'Staff Handbook.pdf',
              type: 'file',
              size: '3.8 MB',
              lastModified: new Date().toISOString(),
              content: 'Comprehensive guide for all hospital staff, including code of conduct, dress code, workplace policies, and professional development guidelines.'
            }
          ]
        },
        {
          id: 'reports',
          name: 'Reports',
          type: 'folder',
          lastModified: new Date().toISOString(),
          items: [
            {
              id: 'quarterly',
              name: 'Quarterly Report.xlsx',
              type: 'file',
              size: '1.2 MB',
              lastModified: new Date().toISOString(),
              content: 'Financial data for the last quarter showing hospital performance metrics, including patient admissions, average length of stay, and revenue analysis.'
            },
            {
              id: 'annual',
              name: 'Annual Report 2024.pdf',
              type: 'file',
              size: '5.8 MB',
              lastModified: new Date().toISOString(),
              content: 'Comprehensive annual report for the hospital, including financial statements, patient statistics, quality metrics, and strategic planning initiatives.'
            }
          ]
        },
        {
          id: 'system',
          name: 'System',
          type: 'folder',
          lastModified: new Date().toISOString(),
          items: [
            {
              id: 'sys_config',
              name: 'system.config',
              type: 'file',
              size: '24 KB',
              lastModified: new Date().toISOString(),
              content: '# Hospital OS System Configuration\n\nOSVersion=1.0.3\nLastUpdate=2025-03-25\nSystemHostname=Hospital-Central\nNetworkDomain=hospital.local\nAdminContact=admin@hospital.org\nSecurityProtocol=HIPAA-Compliant\nBackupSchedule=Daily-23:00\nDataRetention=7Years\nMaxConcurrentUsers=250\n'
            },
            {
              id: 'network_config',
              name: 'network.config',
              type: 'file',
              size: '18 KB',
              lastModified: new Date().toISOString(),
              content: '# Network Configuration\n\nPrimaryDNS=192.168.1.1\nSecondaryDNS=192.168.1.2\nSubnetMask=255.255.255.0\nDefaultGateway=192.168.1.254\nDHCPEnabled=true\nDHCPRange=192.168.1.100-192.168.1.200\nWiFiSSID=Hospital-Secure\nWiFiSecurity=WPA2-Enterprise\nVLANConfig=Enabled\n'
            },
            {
              id: 'security_policy',
              name: 'security.policy',
              type: 'file',
              size: '32 KB',
              lastModified: new Date().toISOString(),
              content: '# Security Policy Configuration\n\nPasswordMinLength=12\nPasswordRequireSpecialChars=true\nPasswordRequireNumbers=true\nPasswordRequireMixedCase=true\nPasswordExpiryDays=90\nAccountLockoutThreshold=5\nAccountLockoutDurationMinutes=30\nSessionTimeoutMinutes=15\nMFAEnabled=true\nBiometricAuthEnabled=true\n'
            },
            {
              id: 'sys_log',
              name: 'system.log',
              type: 'file',
              size: '156 KB',
              lastModified: new Date().toISOString(),
              content: '[2025-03-28 00:00:01] System startup\n[2025-03-28 00:00:02] Loading modules: core, authentication, database, network, ui\n[2025-03-28 00:00:05] All modules loaded successfully\n[2025-03-28 00:00:10] Network services initialized\n[2025-03-28 00:01:15] Database connection established\n[2025-03-28 00:01:30] User authentication service started\n[2025-03-28 00:02:00] Web server initialized on port 443\n[2025-03-28 01:15:22] Scheduled backup started\n[2025-03-28 01:30:45] Backup completed successfully\n[2025-03-28 06:00:00] Daily system health check started\n[2025-03-28 06:05:12] Health check completed: All systems operational\n'
            }
          ]
        },
        {
          id: 'database',
          name: 'Database',
          type: 'folder',
          lastModified: new Date().toISOString(),
          items: [
            {
              id: 'db_schema',
              name: 'database.schema',
              type: 'file',
              size: '48 KB',
              lastModified: new Date().toISOString(),
              content: '-- Hospital Database Schema\n\nCREATE TABLE users (\n  id SERIAL PRIMARY KEY,\n  username VARCHAR(50) UNIQUE NOT NULL,\n  password VARCHAR(255) NOT NULL,\n  email VARCHAR(100) UNIQUE,\n  role_id INTEGER REFERENCES roles(id),\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n  last_login TIMESTAMP\n);\n\nCREATE TABLE patients (\n  id SERIAL PRIMARY KEY,\n  patient_id VARCHAR(20) UNIQUE NOT NULL,\n  first_name VARCHAR(50) NOT NULL,\n  last_name VARCHAR(50) NOT NULL,\n  dob DATE NOT NULL,\n  gender VARCHAR(10),\n  address TEXT,\n  phone VARCHAR(20),\n  email VARCHAR(100),\n  insurance_id VARCHAR(50),\n  doctor_id INTEGER REFERENCES users(id),\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\n-- Additional tables omitted for brevity'
            },
            {
              id: 'db_backup',
              name: 'latest_backup.sql',
              type: 'file',
              size: '4.2 MB',
              lastModified: new Date().toISOString(),
              content: '-- Database backup from 2025-03-27 23:00:00\n-- Contains SQL statements to recreate the database\n-- File truncated for display purposes'
            },
            {
              id: 'db_performance',
              name: 'performance_metrics.json',
              type: 'file',
              size: '64 KB',
              lastModified: new Date().toISOString(),
              content: '{\n  "last_analyzed": "2025-03-27T22:00:00",\n  "query_performance": [\n    {\n      "query_id": "SELECT-PATIENT-001",\n      "avg_execution_time_ms": 12.5,\n      "execution_count": 25463,\n      "index_usage": "patient_id_idx"\n    },\n    {\n      "query_id": "UPDATE-APPOINTMENT-003",\n      "avg_execution_time_ms": 28.7,\n      "execution_count": 4521,\n      "index_usage": "appointment_date_idx"\n    }\n  ],\n  "indexes": [\n    {\n      "name": "patient_id_idx",\n      "table": "patients",\n      "columns": ["patient_id"],\n      "size_mb": 1.2,\n      "fragmentation": "3%"\n    },\n    {\n      "name": "appointment_date_idx",\n      "table": "appointments",\n      "columns": ["date", "doctor_id"],\n      "size_mb": 0.8,\n      "fragmentation": "5%"\n    }\n  ],\n  "recommendations": [\n    "Add index on (patient_id, last_name) to improve patient search",\n    "Increase statistics sampling on appointments table"\n  ]\n}'
            }
          ]
        },
        {
          id: 'applications',
          name: 'Applications',
          type: 'folder',
          lastModified: new Date().toISOString(),
          items: [
            {
              id: 'app_config',
              name: 'applications.config',
              type: 'file',
              size: '12 KB',
              lastModified: new Date().toISOString(),
              content: '# Applications Configuration\n\n[Dashboard]\nEnabled=true\nAutoStart=true\nPermission=all\n\n[Patients]\nEnabled=true\nAutoStart=false\nPermission=medical,admin\n\n[Appointments]\nEnabled=true\nAutoStart=false\nPermission=medical,admin,reception\n\n[Reports]\nEnabled=true\nAutoStart=false\nPermission=admin,management\n\n[Terminal]\nEnabled=true\nAutoStart=false\nPermission=admin\n\n[AdminPanel]\nEnabled=true\nAutoStart=false\nPermission=admin\n'
            },
            {
              id: 'licenses',
              name: 'licenses.txt',
              type: 'file',
              size: '28 KB',
              lastModified: new Date().toISOString(),
              content: '# Hospital OS License Information\n\nHospital OS Core - Enterprise License\nExpiration: 2026-12-31\nLicense Key: HOSP-ENT-2025-0472919\nAuthorized Nodes: 50\n\nReporting Module - Enterprise License\nExpiration: 2026-12-31\nLicense Key: HOSP-REP-2025-9172845\n\nLaboratory Integration - Enterprise License\nExpiration: 2026-12-31\nLicense Key: HOSP-LAB-2025-3845729\n\nEmergency Module - Enterprise License\nExpiration: 2026-12-31\nLicense Key: HOSP-EMG-2025-7291834\n'
            }
          ]
        },
        {
          id: 'security',
          name: 'Security',
          type: 'folder',
          lastModified: new Date().toISOString(),
          items: [
            {
              id: 'security_audit',
              name: 'security_audit.log',
              type: 'file',
              size: '128 KB',
              lastModified: new Date().toISOString(),
              content: '[2025-03-26 09:15:32] Security audit started\n[2025-03-26 09:15:45] Checking user accounts and permissions\n[2025-03-26 09:16:30] Analyzing password policies\n[2025-03-26 09:17:15] Reviewing data encryption settings\n[2025-03-26 09:18:05] Checking network security configurations\n[2025-03-26 09:19:20] Reviewing application security settings\n[2025-03-26 09:20:45] Analyzing database security\n[2025-03-26 09:22:10] Security audit completed\n[2025-03-26 09:22:11] Issues found: 2 minor, 0 major\n[2025-03-26 09:22:12] Report generated and sent to security@hospital.org\n'
            },
            {
              id: 'certificates',
              name: 'ssl_certificates.info',
              type: 'file',
              size: '16 KB',
              lastModified: new Date().toISOString(),
              content: '# SSL Certificate Information\n\nDomain: hospital.org\nIssuer: DigiCert Healthcare Security\nValid From: 2025-01-01\nValid To: 2026-01-01\nKey Strength: 4096-bit RSA\nSignature Algorithm: SHA-256\nCertificate Path: /etc/ssl/certs/hospital_org.pem\nPrivate Key Path: /etc/ssl/private/hospital_org.key\nCAA Records: Present\nOCSP Stapling: Enabled\nCT Logs: Submitted\n'
            },
            {
              id: 'auth_methods',
              name: 'authentication.config',
              type: 'file',
              size: '18 KB',
              lastModified: new Date().toISOString(),
              content: '# Authentication Configuration\n\nPrimaryMethod=password\nSecondaryMethod=totp\nFallbackMethod=security_questions\n\nLDAPEnabled=true\nLDAPServer=ldap.hospital.local\nLDAPPort=636\nLDAPSecure=true\nLDAPBaseDN=dc=hospital,dc=local\n\nSAMLEnabled=true\nSAMLProvider=Okta\nSAMLMetadataURL=https://hospital.okta.com/saml/metadata\n\nOIDCEnabled=true\nOIDCProvider=Azure\nOIDCClientID=hospital-oidc-client\nOIDCScope=openid profile email\n\nSessionTimeout=900\nRememberMeEnabled=false\nLoginThrottling=true\nMaxLoginAttempts=5\n'
            }
          ]
        },
        {
          id: 'readme',
          name: 'README.txt',
          type: 'file',
          size: '14 KB',
          lastModified: new Date().toISOString(),
          content: 'Welcome to the Hospital OS File System!\n\nThis file system allows you to organize and manage hospital documents, reports, and other important files. You can create folders, add files, and organize your data in a structured way.\n\nImportant folders:\n- Documents: Store all hospital procedures, policies, and staff documentation\n- Reports: Access financial and operational reports\n- System: View and edit system configuration files\n- Database: Access database schemas and performance metrics\n- Applications: Configure application settings and view licenses\n- Security: Review security audits and certificate information\n\nFor assistance, contact the IT department at support@hospital.org.'
        }
      ]
    };
    
    localStorage.setItem('hospitalFileSystem', JSON.stringify(defaultFileSystem));
    setCurrentItems(defaultFileSystem.items);
    return defaultFileSystem;
  };
  
  // Function to create comprehensive file system with system files
  const createSystemFileSystem = (userName: string) => {
    // Start with the default file system structure
    const sysFileSystem = createDefaultFileSystem();
    
    // Add user-specific folders and files
    sysFileSystem.items.push({
      id: 'personal',
      name: 'Personal',
      type: 'folder',
      lastModified: new Date().toISOString(),
      items: [
        {
          id: 'user_profile',
          name: 'user_profile.json',
          type: 'file',
          size: '1.2 KB',
          lastModified: new Date().toISOString(),
          content: `{\n  "name": "${userName}",\n  "created": "${new Date().toISOString()}",\n  "lastLogin": "${new Date().toISOString()}",\n  "preferences": {\n    "theme": "default",\n    "language": "en-US",\n    "notifications": true,\n    "autoSave": true\n  },\n  "permissions": [\n    "basic_user",\n    "file_access",\n    "report_view"\n  ]\n}`
        },
        {
          id: 'welcome_note',
          name: 'Welcome.txt',
          type: 'file',
          size: '0.5 KB',
          lastModified: new Date().toISOString(),
          content: `Welcome, ${userName}!\n\nThank you for completing the Hospital OS setup process. Your system is now configured and ready to use.\n\nThis folder contains your personal files and settings. Feel free to customize your workspace to suit your preferences.\n\nIf you need assistance, please refer to the Hospital OS manual or contact system support.`
        }
      ]
    });
    
    // Add more system folders based on selected options
    if (setupOptions.includeSystemFiles) {
      // Add advanced system folder with more configuration files
      const systemFolder = sysFileSystem.items.find(item => item.id === 'system') as FolderItem;
      if (systemFolder) {
        systemFolder.items.push(
          {
            id: 'advanced_config',
            name: 'advanced.config',
            type: 'file',
            size: '28 KB',
            lastModified: new Date().toISOString(),
            content: '# Advanced System Configuration\n\nKernelVersion=5.14.21\nSchedulerPolicy=priority\nProcessLimit=1000\nThreadPoolSize=32\nMemoryReservation=2048MB\nSwapUsage=enabled\nIOScheduler=cfq\nPowerManagement=dynamic\nThermalThrottling=enabled\nHardwareMonitoring=enabled\n'
          },
          {
            id: 'drivers',
            name: 'hardware_drivers.log',
            type: 'file',
            size: '45 KB',
            lastModified: new Date().toISOString(),
            content: '# Hardware Drivers Information\n\nGPU Driver: NVIDIA-SMI 535.104.05\nNetwork: Intel E1000 PCI 10/100/1000 Ethernet Controller 5.14.21-v1.0.4\nStorage: NVMe PCIe SSD Controller Driver v3.5.2\nPrinter: HP Universal Printing Driver PCL6 (v6.9.0)\nScanner: TWAIN-compatible Image Acquisition Driver v4.2\nBiometric: Fingerprint Reader Driver v2.3.1\nSmartcard: PC/SC Smart Card Reader Driver v1.8.5\n'
          }
        );
      }
    }
    
    // Save the customized file system
    localStorage.setItem('hospitalFileSystem', JSON.stringify(sysFileSystem));
    return sysFileSystem;
  };

  // Function to navigate to a path
  const navigateToPath = (path: string[]) => {
    const fileSystem = JSON.parse(localStorage.getItem('hospitalFileSystem') || '{}');
    let current: FolderItem = fileSystem;
    
    // Skip the first element (root) and navigate through the path
    for (let i = 1; i < path.length; i++) {
      const segment = path[i];
      const found = current.items.find(item => item.name === segment && item.type === 'folder');
      if (found && found.type === 'folder') {
        current = found;
      } else {
        console.error(`Path segment not found: ${segment}`);
        return;
      }
    }
    
    setCurrentItems(current.items);
    setCurrentPath(path);
  };

  // Function to determine the appropriate icon for a file based on its name
  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    
    if (!extension) return <FileText className="h-4 w-4 mr-2 text-green-500" />;
    
    switch (extension) {
      case 'pdf':
        return <FileText className="h-4 w-4 mr-2 text-red-500" />;
      case 'txt':
        return <FileText className="h-4 w-4 mr-2 text-green-500" />;
      case 'doc':
      case 'docx':
        return <FileText className="h-4 w-4 mr-2 text-blue-500" />;
      case 'xls':
      case 'xlsx':
        return <FileText className="h-4 w-4 mr-2 text-emerald-500" />;
      case 'ppt':
      case 'pptx':
        return <FileText className="h-4 w-4 mr-2 text-orange-500" />;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return <FileText className="h-4 w-4 mr-2 text-purple-500" />;
      case 'json':
        return <FileJson className="h-4 w-4 mr-2 text-yellow-500" />;
      case 'config':
        return <FileCog className="h-4 w-4 mr-2 text-slate-500" />;
      case 'log':
        return <FileTerminal className="h-4 w-4 mr-2 text-gray-500" />;
      case 'schema':
      case 'sql':
        return <Database className="h-4 w-4 mr-2 text-indigo-500" />;
      case 'info':
        return <Info className="h-4 w-4 mr-2 text-sky-500" />;
      case 'policy':
        return <Shield className="h-4 w-4 mr-2 text-red-500" />;
      default:
        return <FileText className="h-4 w-4 mr-2 text-green-500" />;
    }
  };

  // Function to handle folder navigation
  const handleFolderClick = (folder: FolderItem) => {
    setCurrentPath([...currentPath, folder.name]);
    setCurrentItems(folder.items);
  };

  // Function to handle file opening
  const handleFileClick = (file: FileItem) => {
    setSelectedItem(file);
    setFileContent(file.content || '');
    setIsFileDialogOpen(true);
    setIsEditing(false);
  };

  // Function to go up one directory
  const handleGoUp = () => {
    if (currentPath.length > 1) {
      const newPath = [...currentPath];
      newPath.pop();
      navigateToPath(newPath);
    }
  };

  // Function to handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Implement search functionality here
    // For simplicity, just filter the current items
    if (searchQuery.trim() === '') {
      navigateToPath(currentPath);
    } else {
      const filteredItems = currentItems.filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setCurrentItems(filteredItems);
    }
  };

  // Function to save file content
  const saveFileContent = () => {
    if (!selectedItem || selectedItem.type !== 'file') return;
    
    const fileSystem = JSON.parse(localStorage.getItem('hospitalFileSystem') || '{}');
    let current: FolderItem = fileSystem;
    
    // Navigate to the current folder
    for (let i = 1; i < currentPath.length; i++) {
      const segment = currentPath[i];
      const found = current.items.find(item => item.name === segment && item.type === 'folder');
      if (found && found.type === 'folder') {
        current = found;
      }
    }
    
    // Find and update the file
    const fileIndex = current.items.findIndex(item => item.id === selectedItem.id);
    if (fileIndex !== -1) {
      const updatedItem = { 
        ...current.items[fileIndex],
        content: fileContent,
        lastModified: new Date().toISOString()
      };
      current.items[fileIndex] = updatedItem;
      
      // Save the updated file system
      localStorage.setItem('hospitalFileSystem', JSON.stringify(fileSystem));
      
      // Update current items
      setCurrentItems([...current.items]);
      setIsFileDialogOpen(false);
    }
  };

  // Function to create a new item
  const createNewItem = () => {
    if (!newItemName.trim()) return;
    
    const fileSystem = JSON.parse(localStorage.getItem('hospitalFileSystem') || '{}');
    let current: FolderItem = fileSystem;
    
    // Navigate to the current folder
    for (let i = 1; i < currentPath.length; i++) {
      const segment = currentPath[i];
      const found = current.items.find(item => item.name === segment && item.type === 'folder');
      if (found && found.type === 'folder') {
        current = found;
      }
    }
    
    // Create new item based on type
    const newId = `${Date.now()}`;
    let newItem: FileSystemItem;
    
    if (newItemType === 'folder') {
      newItem = {
        id: newId,
        name: newItemName,
        type: 'folder',
        lastModified: new Date().toISOString(),
        items: []
      };
    } else {
      newItem = {
        id: newId,
        name: newItemName,
        type: 'file',
        size: '0 KB',
        lastModified: new Date().toISOString(),
        content: ''
      };
    }
    
    // Add new item to current folder
    current.items.push(newItem);
    
    // Save updated file system
    localStorage.setItem('hospitalFileSystem', JSON.stringify(fileSystem));
    
    // Update current items
    setCurrentItems([...current.items]);
    setIsCreateDialogOpen(false);
    setNewItemName('');
  };

  // Function to delete item
  const deleteItem = () => {
    if (!selectedItem) return;
    
    const fileSystem = JSON.parse(localStorage.getItem('hospitalFileSystem') || '{}');
    let current: FolderItem = fileSystem;
    
    // Navigate to the current folder
    for (let i = 1; i < currentPath.length; i++) {
      const segment = currentPath[i];
      const found = current.items.find(item => item.name === segment && item.type === 'folder');
      if (found && found.type === 'folder') {
        current = found;
      }
    }
    
    // Filter out the item to delete
    current.items = current.items.filter(item => item.id !== selectedItem.id);
    
    // Save updated file system
    localStorage.setItem('hospitalFileSystem', JSON.stringify(fileSystem));
    
    // Update current items
    setCurrentItems([...current.items]);
    setIsDeleteDialogOpen(false);
    setSelectedItem(null);
  };

  // Simulate file installation with progress updates - much slower installation process
  const simulateInstallation = () => {
    setIsInstallingFiles(true);
    setInstallProgress(0);
    setInstallStage(1);
    
    // More detailed installation items
    const installItems = [
      'Core System Files',
      'Database Templates',
      'Security Components',
      'Network Configuration',
      'User Interface Components',
      'Application Integration Modules',
      'Report Templates',
      'Medical Reference Libraries',
      'Departmental Templates',
      'Security Protocols',
      'Access Control Systems',
      'Logging Infrastructure',
      'Backup Systems',
      'Recovery Tools',
      'System Documentation',
      'User Manuals',
      'Training Materials',
      'Diagnostic Tools',
      'Performance Monitoring',
      'Security Analysis Tools',
      'Medical Procedure Archives',
      'Physician Reference Materials',
      'Laboratory Testing Protocols',
      'Regulatory Compliance Documents',
      'Pharmacy Interaction Database',
      'Patient Record Templates',
      'Electronic Health Record System',
      'Medical Imaging Software',
      'Voice Recognition Tools',
      'AI Diagnostic Assistants'
    ];
    
    // Installation logs for more detail based on progress
    const installLogs = [
      'Initializing file system...',
      'Checking disk space and system requirements...',
      'Verifying system compatibility...',
      'Setting up installation environment...',
      'Preparing installation packages...',
      'Creating directory structure...',
      'Establishing secure installation protocol...',
      'Validating package signatures...',
      'Installing core components...',
      'Setting up system registry...',
      'Configuring base system...',
      'Installing system libraries...',
      'Setting up security framework...',
      'Establishing secure communication channels...',
      'Installing crypto modules...',
      'Configuring user authentication...',
      'Installing application files...',
      'Setting up medical database structure...',
      'Configuring emergency protocols...',
      'Installing data processing modules...',
      'Setting up notification system...',
      'Configuring reporting engine...',
      'Installing visualization components...',
      'Setting up laboratory integrations...',
      'Installing pharmacy systems...',
      'Configuring medical device connections...',
      'Installing patient management system...',
      'Setting up appointment scheduling...',
      'Finalizing file installation...',
      'Verifying installation integrity...'
    ];
    
    let currentItemIndex = 0;
    let currentLogIndex = 0;
    let installLogs_Shown: string[] = [];
    
    // First phase - much slower (1-2 minutes total)
    const installInterval = setInterval(() => {
      if (currentItemIndex < installItems.length) {
        setCurrentInstallItem(installItems[currentItemIndex]);
        
        // Slower progress - each item takes more time
        setInstallProgress((currentItemIndex + 1) / installItems.length * 100);
        
        // Add a new log entry periodically but not on every item
        if (currentItemIndex % 3 === 0 && currentLogIndex < installLogs.length) {
          installLogs_Shown.push(installLogs[currentLogIndex]);
          currentLogIndex++;
          // Store the logs in localStorage so we can access them in the component
          localStorage.setItem('installLogs', JSON.stringify(installLogs_Shown));
        }
        
        currentItemIndex++;
      } else {
        clearInterval(installInterval);
        setInstallStage(2);
        
        // Second phase - configuring (takes ~1 minute)
        const configLogs = [
          'Applying system preferences...',
          'Configuring user settings...',
          'Initializing user workspace...',
          'Setting regional preferences...',
          'Configuring language settings...',
          'Setting up time zone preferences...',
          'Applying theme settings...',
          'Setting up security protocols...',
          'Configuring access control lists...',
          'Setting up audit logging...',
          'Setting up encryption keys...',
          'Configuring network settings...',
          'Setting up firewall rules...',
          'Configuring proxy settings...',
          'Setting up connection pooling...',
          'Configuring DNS resolution...',
          'Applying departmental templates...',
          'Setting up role-based configurations...',
          'Configuring workflow defaults...',
          'Setting up report templates...',
          'Configuration complete.'
        ];
        
        let configProgress = 0;
        let configLogIndex = 0;
        let configLogs_Shown: string[] = [];
        
        const configInterval = setInterval(() => {
          // Slower increase (will take ~1 minute)
          configProgress += 1;
          setInstallProgress(configProgress);
          
          // Add configuration logs more slowly
          if (configProgress % 5 === 0 && configLogIndex < configLogs.length) {
            configLogs_Shown.push(configLogs[configLogIndex]);
            configLogIndex++;
            localStorage.setItem('configLogs', JSON.stringify(configLogs_Shown));
          }
          
          if (configProgress >= 100) {
            clearInterval(configInterval);
            setInstallStage(3);
            
            // Third phase - optimization (takes ~1 minute)
            const optimizeLogs = [
              'Running system optimization...',
              'Analyzing file access patterns...',
              'Optimizing file indexing...',
              'Setting up caching strategies...',
              'Optimizing memory usage...',
              'Tuning garbage collection...',
              'Optimizing file access...',
              'Setting up read-ahead buffers...',
              'Configuring file system cache...',
              'Optimizing search indexing...',
              'Optimizing database access...',
              'Setting up connection pooling...',
              'Optimizing query patterns...',
              'Creating database indices...',
              'Optimizing stored procedures...',
              'Tuning database parameters...',
              'Optimizing network communication...',
              'Setting up compression...',
              'Configuring network buffers...',
              'Finalizing optimization...',
              'Optimization complete.'
            ];
            
            let optimizeProgress = 0;
            let optimizeLogIndex = 0;
            let optimizeLogs_Shown: string[] = [];
            
            const optimizeInterval = setInterval(() => {
              // Slow increase (will take ~1 minute)
              optimizeProgress += 1;
              setInstallProgress(optimizeProgress);
              
              // Add optimization logs periodically
              if (optimizeProgress % 5 === 0 && optimizeLogIndex < optimizeLogs.length) {
                optimizeLogs_Shown.push(optimizeLogs[optimizeLogIndex]);
                optimizeLogIndex++;
                localStorage.setItem('optimizeLogs', JSON.stringify(optimizeLogs_Shown));
              }
              
              if (optimizeProgress >= 100) {
                clearInterval(optimizeInterval);
                setTimeout(() => {
                  setIsInstallingFiles(false);
                  completeSetup();
                }, 1000); // Small delay before completion
              }
            }, 600); // Slower updates
          }
        }, 600); // Slower updates
      }
    }, 2000); // Much slower - 2 seconds per item
  };

  // Function to handle setup completion
  const completeSetup = () => {
    // Create the file system based on user choices
    const fileSystem = createSystemFileSystem(userName);
    
    // Mark setup as complete in localStorage
    localStorage.setItem('hospitalOSFirstTimeSetup', 'true');
    
    // Update state
    setIsFirstTimeSetup(false);
    setIsSetupComplete(true);
    setCurrentItems(fileSystem.items);
  };
  
  // Function to handle setup step navigation
  const handleNextStep = () => {
    const nextStep = setupStep + 1;
    
    // Total number of setup steps
    const totalSteps = 10;
    
    // Update progress bar based on current step
    setSetupProgress(Math.min((nextStep / totalSteps) * 100, 100));
    
    // Last step triggers installation
    if (nextStep > totalSteps) {
      simulateInstallation();
    } else {
      setSetupStep(nextStep);
    }
  };
  
  const handlePreviousStep = () => {
    if (setupStep > 1) {
      const prevStep = setupStep - 1;
      setSetupStep(prevStep);
      setSetupProgress((prevStep / 10) * 100);
    }
  };
  
  // Function to handle option changes
  const handleOptionChange = (option: keyof typeof setupOptions, value: boolean) => {
    setSetupOptions({
      ...setupOptions,
      [option]: value
    });
  };
  
  return (
    <div className="h-full flex flex-col bg-background p-4">
      {/* First Time Setup Dialog */}
      <Dialog open={isFirstTimeSetup} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-[550px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">
              {setupStep === 1 && "Welcome to Hospital OS"}
              {setupStep === 2 && "User Profile Setup"}
              {setupStep === 3 && "Department Information"}
              {setupStep === 4 && "Access Level Configuration"}
              {setupStep === 5 && "System Configuration"}
              {setupStep === 6 && "File System Setup"}
              {setupStep === 7 && "Security Configuration"}
              {setupStep === 8 && "Network Settings"}
              {setupStep === 9 && "License Agreement"}
              {setupStep === 10 && "Setup Summary"}
              {isInstallingFiles && (
                installStage === 1 ? "Installing System Files" :
                installStage === 2 ? "Configuring System" :
                "Optimizing Performance"
              )}
            </DialogTitle>
            <DialogDescription>
              {setupStep === 1 && "Welcome to the Hospital OS file system setup process. This comprehensive wizard will guide you through the initial system configuration."}
              {setupStep === 2 && "Please enter your personal information to customize your Hospital OS experience."}
              {setupStep === 3 && "Select your department to receive specialized templates and configurations."}
              {setupStep === 4 && "Set your system access level and permissions."}
              {setupStep === 5 && "Configure your system preferences. You can change these settings later in the Settings app."}
              {setupStep === 6 && "Choose which files and folders to include in your file system."}
              {setupStep === 7 && "Configure security settings and recovery options."}
              {setupStep === 8 && "Set up network connection preferences for file sharing."}
              {setupStep === 9 && "Review and accept the Hospital OS license agreement."}
              {setupStep === 10 && "Your system is almost ready! Review your configuration before beginning installation."}
              {isInstallingFiles && (
                installStage === 1 ? "Installing necessary files and components. This process may take several minutes." :
                installStage === 2 ? "Configuring system preferences and optimizing settings." :
                "Finalizing installation and optimizing system performance."
              )}
            </DialogDescription>
          </DialogHeader>
          
          <div className="my-6">
            <Progress value={setupProgress} className="w-full" />
          </div>
          
          {/* Installation in progress */}
          {isInstallingFiles && (
            <div className="space-y-6 py-4">
              <div className="flex justify-center p-4">
                {installStage === 1 && <HardDrive className="h-16 w-16 text-primary animate-pulse" />}
                {installStage === 2 && <Cog className="h-16 w-16 text-primary animate-spin" />}
                {installStage === 3 && <Settings className="h-16 w-16 text-primary animate-spin" />}
              </div>
              
              <div className="space-y-4">
                <div className="text-center mb-2">
                  {installStage === 1 && `Installing: ${currentInstallItem}`}
                  {installStage === 2 && "Configuring system preferences"}
                  {installStage === 3 && "Optimizing performance"}
                </div>
                <Progress value={installProgress} className="w-full" />
                <p className="text-center text-sm text-muted-foreground">
                  {installStage === 1 && `${Math.round(installProgress)}% complete. Installing necessary files...`}
                  {installStage === 2 && `${Math.round(installProgress)}% complete. Configuring system...`}
                  {installStage === 3 && `${Math.round(installProgress)}% complete. Finalizing installation...`}
                </p>
              </div>
              
              <div className="border p-2 rounded bg-muted/20 max-h-[200px] overflow-auto font-mono text-xs">
                {installStage === 1 && (
                  <>
                    {/* Get logs from localStorage for first phase */}
                    {(() => {
                      try {
                        const logs = JSON.parse(localStorage.getItem('installLogs') || '[]');
                        return logs.map((log: string, index: number) => (
                          <div key={index}>{log}</div>
                        ));
                      } catch (e) {
                        // Fallback if localStorage isn't available
                        return (
                          <>
                            <div>Initializing file system...</div>
                            <div>Checking disk space and system requirements...</div>
                            {installProgress > 10 && <div>Verifying system compatibility...</div>}
                            {installProgress > 20 && <div>Setting up installation environment...</div>}
                            {installProgress > 30 && <div>Preparing installation packages...</div>}
                            {installProgress > 40 && <div>Establishing secure installation protocol...</div>}
                            {installProgress > 50 && <div>Installing core components...</div>}
                            {installProgress > 60 && <div>Setting up security framework...</div>}
                            {installProgress > 70 && <div>Installing application files...</div>}
                            {installProgress > 80 && <div>Setting up medical database structure...</div>}
                            {installProgress > 90 && <div>Finalizing file installation...</div>}
                            {installProgress === 100 && <div>File installation complete.</div>}
                          </>
                        );
                      }
                    })()}
                  </>
                )}
                {installStage === 2 && (
                  <>
                    {/* Get logs from localStorage for configuration phase */}
                    {(() => {
                      try {
                        const logs = JSON.parse(localStorage.getItem('configLogs') || '[]');
                        return logs.map((log: string, index: number) => (
                          <div key={index}>{log}</div>
                        ));
                      } catch (e) {
                        // Fallback if localStorage isn't available
                        return (
                          <>
                            <div>Applying system preferences...</div>
                            <div>Configuring user settings...</div>
                            {installProgress > 20 && <div>Initializing user workspace...</div>}
                            {installProgress > 30 && <div>Setting up security protocols...</div>}
                            {installProgress > 40 && <div>Configuring access control lists...</div>}
                            {installProgress > 50 && <div>Setting up encryption keys...</div>}
                            {installProgress > 60 && <div>Configuring network settings...</div>}
                            {installProgress > 70 && <div>Setting up firewall rules...</div>}
                            {installProgress > 80 && <div>Applying departmental templates...</div>}
                            {installProgress > 90 && <div>Setting up report templates...</div>}
                            {installProgress === 100 && <div>Configuration complete.</div>}
                          </>
                        );
                      }
                    })()}
                  </>
                )}
                {installStage === 3 && (
                  <>
                    {/* Get logs from localStorage for optimization phase */}
                    {(() => {
                      try {
                        const logs = JSON.parse(localStorage.getItem('optimizeLogs') || '[]');
                        return logs.map((log: string, index: number) => (
                          <div key={index}>{log}</div>
                        ));
                      } catch (e) {
                        // Fallback if localStorage isn't available
                        return (
                          <>
                            <div>Running system optimization...</div>
                            {installProgress > 10 && <div>Analyzing file access patterns...</div>}
                            {installProgress > 20 && <div>Optimizing file indexing...</div>}
                            {installProgress > 30 && <div>Optimizing memory usage...</div>}
                            {installProgress > 40 && <div>Optimizing file access...</div>}
                            {installProgress > 50 && <div>Configuring file system cache...</div>}
                            {installProgress > 60 && <div>Optimizing database access...</div>}
                            {installProgress > 70 && <div>Optimizing query patterns...</div>}
                            {installProgress > 80 && <div>Optimizing network communication...</div>}
                            {installProgress > 90 && <div>Finalizing optimization...</div>}
                            {installProgress === 100 && <div>Optimization complete.</div>}
                          </>
                        );
                      }
                    })()}
                  </>
                )}
              </div>
            </div>
          )}

          {/* Step 1: Welcome */}
          {!isInstallingFiles && setupStep === 1 && (
            <div className="flex flex-col space-y-6">
              <div className="flex justify-center p-6">
                <FileCog className="h-24 w-24 text-primary" />
              </div>
              <p>
                Hospital OS is setting up your file system for the first time. This process will only run once and will customize your workspace.
              </p>
              <p>
                The setup will:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Configure your user profile</li>
                <li>Set up system folders and important files</li>
                <li>Install sample documents and templates</li>
                <li>Configure security settings</li>
                <li>Personalize your workspace</li>
                <li>Set up networking and sharing</li>
                <li>Install specialized medical libraries</li>
                <li>Configure backup and disaster recovery</li>
                <li>Set up performance monitoring</li>
              </ul>
              <p className="text-sm text-muted-foreground mt-4">
                This setup process is comprehensive and will take several minutes to complete.
                Please do not close the application during setup.
              </p>
            </div>
          )}
          
          {/* Step 2: User Profile */}
          {!isInstallingFiles && setupStep === 2 && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Your Name</Label>
                <Input
                  id="name"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Enter your name"
                />
              </div>
              <div className="space-y-2 mt-4">
                <Label htmlFor="role">Your Role</Label>
                <Input
                  id="role"
                  value={userRole}
                  onChange={(e) => setUserRole(e.target.value)}
                  placeholder="Enter your job role"
                />
                <p className="text-xs text-muted-foreground">
                  Your role will determine which specialized templates are installed.
                </p>
              </div>
            </div>
          )}
          
          {/* Step 3: Department Information */}
          {!isInstallingFiles && setupStep === 3 && (
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <select
                  id="department"
                  value={userDepartment}
                  onChange={(e) => setUserDepartment(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="">Select department</option>
                  <option value="Administration">Administration</option>
                  <option value="Emergency">Emergency</option>
                  <option value="Surgery">Surgery</option>
                  <option value="Pediatrics">Pediatrics</option>
                  <option value="Cardiology">Cardiology</option>
                  <option value="Neurology">Neurology</option>
                  <option value="Oncology">Oncology</option>
                  <option value="Radiology">Radiology</option>
                  <option value="Laboratory">Laboratory</option>
                  <option value="Pharmacy">Pharmacy</option>
                </select>
              </div>
              
              <div className="space-y-2 mt-4">
                <Label>Department-specific templates</Label>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="dept-templates" 
                    checked={setupOptions.installDepartmentTemplates}
                    onCheckedChange={(checked) => handleOptionChange('installDepartmentTemplates', checked === true)}
                  />
                  <label
                    htmlFor="dept-templates"
                    className="text-sm font-medium leading-none"
                  >
                    Install specialized templates for my department
                  </label>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Departmental templates include specialized forms, reports, and workflows.
                </p>
              </div>
            </div>
          )}
          
          {/* Step 4: Access Level Configuration */}
          {!isInstallingFiles && setupStep === 4 && (
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <Label htmlFor="access-level">Access Level</Label>
                <select
                  id="access-level"
                  value={userAccessLevel}
                  onChange={(e) => setUserAccessLevel(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="Standard">Standard</option>
                  <option value="Advanced">Advanced</option>
                  <option value="Administrator">Administrator</option>
                </select>
                <p className="text-xs text-muted-foreground mt-1">
                  Access level determines which system features are available to you.
                </p>
              </div>
              
              <div className="space-y-2 mt-4">
                <Label>Security Questions</Label>
                <p className="text-xs text-muted-foreground mb-2">
                  These questions will be used for account recovery if needed.
                </p>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="question1" className="text-sm">Security Question 1</Label>
                    <select
                      id="question1"
                      value={securityQuestions.question1}
                      onChange={(e) => setSecurityQuestions({...securityQuestions, question1: e.target.value})}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2"
                    >
                      <option value="">Select a question</option>
                      <option value="What was your childhood nickname?">What was your childhood nickname?</option>
                      <option value="What is the name of your first pet?">What is the name of your first pet?</option>
                      <option value="What was your first car?">What was your first car?</option>
                    </select>
                    <Input
                      id="answer1"
                      className="mt-2"
                      value={securityQuestions.answer1}
                      onChange={(e) => setSecurityQuestions({...securityQuestions, answer1: e.target.value})}
                      placeholder="Your answer"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="question2" className="text-sm">Security Question 2</Label>
                    <select
                      id="question2"
                      value={securityQuestions.question2}
                      onChange={(e) => setSecurityQuestions({...securityQuestions, question2: e.target.value})}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2"
                    >
                      <option value="">Select a question</option>
                      <option value="In what city were you born?">In what city were you born?</option>
                      <option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
                      <option value="What high school did you attend?">What high school did you attend?</option>
                    </select>
                    <Input
                      id="answer2"
                      className="mt-2"
                      value={securityQuestions.answer2}
                      onChange={(e) => setSecurityQuestions({...securityQuestions, answer2: e.target.value})}
                      placeholder="Your answer"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 5: System Configuration */}
          {!isInstallingFiles && setupStep === 5 && (
            <div className="space-y-6 py-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Auto-backup enabled</Label>
                  <p className="text-sm text-muted-foreground">Automatically backup your files daily</p>
                </div>
                <Switch
                  checked={setupOptions.enableAutoBackup}
                  onCheckedChange={(checked) => handleOptionChange('enableAutoBackup', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Security protocol setup</Label>
                  <p className="text-sm text-muted-foreground">Configure enhanced security settings</p>
                </div>
                <Switch
                  checked={setupOptions.setupSecurityProtocol}
                  onCheckedChange={(checked) => handleOptionChange('setupSecurityProtocol', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Advanced features</Label>
                  <p className="text-sm text-muted-foreground">Install additional system tools and utilities</p>
                </div>
                <Switch
                  checked={setupOptions.installAdvancedFeatures}
                  onCheckedChange={(checked) => handleOptionChange('installAdvancedFeatures', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Data encryption</Label>
                  <p className="text-sm text-muted-foreground">Enable HIPAA-compliant file encryption</p>
                </div>
                <Switch
                  checked={setupOptions.enableDataEncryption}
                  onCheckedChange={(checked) => handleOptionChange('enableDataEncryption', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Automatic updates</Label>
                  <p className="text-sm text-muted-foreground">Check for and install updates automatically</p>
                </div>
                <Switch
                  checked={setupOptions.setupAutomaticUpdates}
                  onCheckedChange={(checked) => handleOptionChange('setupAutomaticUpdates', checked)}
                />
              </div>
            </div>
          )}
          
          {/* Step 6: File System Setup */}
          {!isInstallingFiles && setupStep === 6 && (
            <div className="space-y-6 py-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="sample-files" 
                  checked={setupOptions.includeSampleFiles}
                  onCheckedChange={(checked) => handleOptionChange('includeSampleFiles', checked === true)}
                />
                <div className="grid gap-1.5 leading-none">
                  <label
                    htmlFor="sample-files"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Include sample files and templates
                  </label>
                  <p className="text-sm text-muted-foreground">
                    Add pre-configured documents and report templates
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="system-files" 
                  checked={setupOptions.includeSystemFiles}
                  onCheckedChange={(checked) => handleOptionChange('includeSystemFiles', checked === true)}
                />
                <div className="grid gap-1.5 leading-none">
                  <label
                    htmlFor="system-files"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Include system files
                  </label>
                  <p className="text-sm text-muted-foreground">
                    Add configuration files, logs, and system documentation
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="medical-db" 
                  checked={setupOptions.installMedicalDatabases}
                  onCheckedChange={(checked) => handleOptionChange('installMedicalDatabases', checked === true)}
                />
                <div className="grid gap-1.5 leading-none">
                  <label
                    htmlFor="medical-db"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Install medical reference databases
                  </label>
                  <p className="text-sm text-muted-foreground">
                    Add comprehensive medical references and coding databases
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="user-workspace" 
                  checked={setupOptions.setupUserSpecificWorkspace}
                  onCheckedChange={(checked) => handleOptionChange('setupUserSpecificWorkspace', checked === true)}
                />
                <div className="grid gap-1.5 leading-none">
                  <label
                    htmlFor="user-workspace"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Create personalized workspace
                  </label>
                  <p className="text-sm text-muted-foreground">
                    Set up a customized workspace based on your role and department
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 7: Security Configuration */}
          {!isInstallingFiles && setupStep === 7 && (
            <div className="space-y-6 py-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Security Suite</Label>
                  <p className="text-sm text-muted-foreground">Install comprehensive security tools</p>
                </div>
                <Switch
                  checked={setupOptions.installSecuritySuite}
                  onCheckedChange={(checked) => handleOptionChange('installSecuritySuite', checked)}
                />
              </div>
              
              <div className="space-y-2">
                <Label className="text-base">Access Protection</Label>
                <p className="text-sm text-muted-foreground mb-2">
                  Select protection level for sensitive files.
                </p>
                <div className="flex space-x-4">
                  <div className="flex items-center space-x-2">
                    <input type="radio" id="standard" name="protection" checked />
                    <Label htmlFor="standard">Standard</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="radio" id="enhanced" name="protection" />
                    <Label htmlFor="enhanced">Enhanced</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="radio" id="maximum" name="protection" />
                    <Label htmlFor="maximum">Maximum</Label>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-md p-4 bg-muted/10">
                <div className="flex items-start space-x-3">
                  <Lock className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium">Security Recommendation</h4>
                    <p className="text-sm text-muted-foreground">
                      Based on your department and role, we recommend enabling full encryption
                      and installing the security suite for HIPAA compliance.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 8: Network Settings */}
          {!isInstallingFiles && setupStep === 8 && (
            <div className="space-y-6 py-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Use default network settings</Label>
                  <p className="text-sm text-muted-foreground">Automatically configure network settings</p>
                </div>
                <Switch
                  checked={networkSettings.useDefaultSettings}
                  onCheckedChange={(checked) => setNetworkSettings({...networkSettings, useDefaultSettings: checked})}
                />
              </div>
              
              {!networkSettings.useDefaultSettings && (
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="hostname">Computer Name</Label>
                    <Input
                      id="hostname"
                      value={networkSettings.hostname}
                      onChange={(e) => setNetworkSettings({...networkSettings, hostname: e.target.value})}
                      placeholder="Computer name"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="domain">Network Domain</Label>
                    <Input
                      id="domain"
                      value={networkSettings.domain}
                      onChange={(e) => setNetworkSettings({...networkSettings, domain: e.target.value})}
                      placeholder="Network domain"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="connection">Connection Type</Label>
                    <select
                      id="connection"
                      value={networkSettings.connectionType}
                      onChange={(e) => setNetworkSettings({...networkSettings, connectionType: e.target.value})}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      <option value="Wired">Wired</option>
                      <option value="Wireless">Wireless</option>
                      <option value="VPN">VPN</option>
                    </select>
                  </div>
                </div>
              )}
              
              <div className="flex items-center justify-between mt-4">
                <div className="space-y-0.5">
                  <Label className="text-base">Enable file sharing</Label>
                  <p className="text-sm text-muted-foreground">Allow others to access shared files</p>
                </div>
                <Switch
                  checked={setupOptions.enableNetworkSharing}
                  onCheckedChange={(checked) => handleOptionChange('enableNetworkSharing', checked)}
                />
              </div>
            </div>
          )}
          
          {/* Step 9: License Agreement */}
          {!isInstallingFiles && setupStep === 9 && (
            <div className="space-y-4 py-4">
              <div className="border rounded-md p-4 bg-muted/5 h-[200px] overflow-auto text-sm">
                <h4 className="font-bold mb-2">Hospital OS License Agreement</h4>
                <p className="mb-2">This End User License Agreement ("Agreement") is a legal agreement between you and Hospital OS Inc.</p>
                <p className="mb-2">By installing, accessing or using the Hospital OS software ("Software"), you agree to be bound by the terms of this Agreement.</p>
                <h5 className="font-semibold mt-4 mb-1">1. Grant of License</h5>
                <p className="mb-2">Subject to the terms of this Agreement, Hospital OS grants you a limited, non-exclusive, non-transferable license to use the Software.</p>
                <h5 className="font-semibold mt-4 mb-1">2. Restrictions</h5>
                <p className="mb-2">You may not: (a) copy, modify, or create derivative works of the Software; (b) reverse engineer, decompile, or disassemble the Software; (c) rent, lease, or lend the Software.</p>
                <h5 className="font-semibold mt-4 mb-1">3. Privacy and Data Security</h5>
                <p className="mb-2">All data is stored locally on your device. Hospital OS does not collect or transmit your personal data or patient information.</p>
                <h5 className="font-semibold mt-4 mb-1">4. Termination</h5>
                <p className="mb-2">This Agreement is effective until terminated. Your rights under this Agreement will terminate automatically if you fail to comply with any of its terms.</p>
                <h5 className="font-semibold mt-4 mb-1">5. Disclaimer of Warranty</h5>
                <p className="mb-2">THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND.</p>
                <h5 className="font-semibold mt-4 mb-1">6. Limitation of Liability</h5>
                <p className="mb-2">IN NO EVENT SHALL HOSPITAL OS BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES.</p>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="accept-license" 
                  checked={licenseAgreementAccepted}
                  onCheckedChange={(checked) => setLicenseAgreementAccepted(checked === true)}
                />
                <label
                  htmlFor="accept-license"
                  className="text-sm font-medium leading-none"
                >
                  I accept the license agreement
                </label>
              </div>
            </div>
          )}
          
          {/* Step 10: Setup Summary */}
          {!isInstallingFiles && setupStep === 10 && (
            <div className="space-y-4 py-4">
              <p className="mb-2">
                {userName ? `Hello ${userName}!` : 'Hello'} Your Hospital OS is almost ready. Here's a summary of your configuration:
              </p>
              
              <div className="border rounded-md p-4 bg-muted/50 space-y-2 max-h-[250px] overflow-auto">
                <p><strong>User:</strong> {userName || 'Anonymous'}</p>
                <p><strong>Role:</strong> {userRole || 'Not specified'}</p>
                <p><strong>Department:</strong> {userDepartment || 'Not specified'}</p>
                <p><strong>Access Level:</strong> {userAccessLevel}</p>
                <p><strong>Network Hostname:</strong> {networkSettings.hostname}</p>
                <hr className="my-2" />
                <p><strong>Auto-backup:</strong> {setupOptions.enableAutoBackup ? 'Enabled' : 'Disabled'}</p>
                <p><strong>Security protocol:</strong> {setupOptions.setupSecurityProtocol ? 'Enabled' : 'Disabled'}</p>
                <p><strong>Advanced features:</strong> {setupOptions.installAdvancedFeatures ? 'Installed' : 'Not installed'}</p>
                <p><strong>Sample files:</strong> {setupOptions.includeSampleFiles ? 'Included' : 'Not included'}</p>
                <p><strong>System files:</strong> {setupOptions.includeSystemFiles ? 'Included' : 'Not included'}</p>
                <p><strong>Data encryption:</strong> {setupOptions.enableDataEncryption ? 'Enabled' : 'Disabled'}</p>
                <p><strong>Department templates:</strong> {setupOptions.installDepartmentTemplates ? 'Included' : 'Not included'}</p>
                <p><strong>User workspace:</strong> {setupOptions.setupUserSpecificWorkspace ? 'Configured' : 'Default'}</p>
                <p><strong>Network sharing:</strong> {setupOptions.enableNetworkSharing ? 'Enabled' : 'Disabled'}</p>
                <p><strong>Medical databases:</strong> {setupOptions.installMedicalDatabases ? 'Installed' : 'Not installed'}</p>
                <p><strong>Security suite:</strong> {setupOptions.installSecuritySuite ? 'Installed' : 'Not installed'}</p>
              </div>
              
              <p>
                Click "Begin Installation" to start installing Hospital OS with these settings. This process may take several minutes to complete.
              </p>
            </div>
          )}
          
          <DialogFooter>
            {!isInstallingFiles && (
              <>
                {setupStep > 1 && (
                  <Button variant="outline" onClick={handlePreviousStep} disabled={isInstallingFiles}>
                    Back
                  </Button>
                )}
                
                <Button 
                  onClick={handleNextStep} 
                  disabled={
                    (setupStep === 9 && !licenseAgreementAccepted) || 
                    isInstallingFiles
                  }
                >
                  {setupStep < 10 ? 'Next' : 'Begin Installation'}
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Setup Complete Notification */}
      <Dialog open={isSetupComplete} onOpenChange={() => setIsSetupComplete(false)}>
        <DialogContent className="sm:max-w-[425px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Setup Complete</DialogTitle>
            <DialogDescription>
              Your Hospital OS file system has been successfully configured.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center py-6">
            <div className="rounded-full bg-primary/10 p-6">
              <FileBadge className="h-12 w-12 text-primary" />
            </div>
          </div>
          <p className="text-center mb-4">
            Welcome to your personalized Hospital OS experience. Your file system is now ready to use.
          </p>
          <DialogFooter>
            <DialogClose asChild>
              <Button>Get Started</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">File Explorer</h2>
        
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" onClick={handleGoUp} disabled={currentPath.length <= 1}>
            <ArrowUp className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={() => navigateToPath(currentPath)}>
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button variant="outline" onClick={() => { setIsCreateDialogOpen(true); setNewItemType('folder'); }}>
            <Plus className="h-4 w-4 mr-2" />
            New
          </Button>
        </div>
      </div>
      
      <div className="flex items-center space-x-2 mb-4">
        <Breadcrumb>
          <BreadcrumbList>
            {currentPath.map((segment, index) => (
              <React.Fragment key={index}>
                {index > 0 && <BreadcrumbSeparator />}
                <BreadcrumbItem>
                  <BreadcrumbLink 
                    onClick={() => navigateToPath(currentPath.slice(0, index + 1))}
                  >
                    {segment}
                  </BreadcrumbLink>
                </BreadcrumbItem>
              </React.Fragment>
            ))}
          </BreadcrumbList>
        </Breadcrumb>
      </div>
      
      <div className="mb-4">
        <form onSubmit={handleSearch} className="flex w-full space-x-2">
          <Input 
            placeholder="Search files and folders..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1"
          />
          <Button type="submit" variant="outline" size="icon">
            <Search className="h-4 w-4" />
          </Button>
        </form>
      </div>
      
      <Tabs defaultValue="all" className="flex-1 flex flex-col">
        <div className="flex justify-between items-center mb-2">
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="recent">Recent</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
          </TabsList>
          
          <div className="flex space-x-2">
            <Button 
              variant={viewMode === 'list' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setViewMode('list')}
            >
              List
            </Button>
            <Button 
              variant={viewMode === 'grid' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              Grid
            </Button>
          </div>
        </div>
        
        <TabsContent value="all" className="flex-1 overflow-auto">
          {viewMode === 'list' ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[300px]">Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Size</TableHead>
                  <TableHead>Modified</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {currentItems.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      This folder is empty
                    </TableCell>
                  </TableRow>
                ) : (
                  currentItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell 
                        className="font-medium cursor-pointer hover:bg-muted/50"
                        onClick={() => item.type === 'folder' 
                          ? handleFolderClick(item as FolderItem) 
                          : handleFileClick(item as FileItem)
                        }
                      >
                        <div className="flex items-center">
                          {item.type === 'folder' ? (
                            <Folder className="h-4 w-4 mr-2 text-blue-500" />
                          ) : (
                            getFileIcon(item.name)
                          )}
                          {item.name}
                        </div>
                      </TableCell>
                      <TableCell>
                        {item.type === 'folder' ? 'Folder' : 'File'}
                      </TableCell>
                      <TableCell>
                        {item.type === 'folder' ? '--' : (item as FileItem).size}
                      </TableCell>
                      <TableCell>
                        {new Date(item.lastModified).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {item.type === 'file' && (
                              <DropdownMenuItem onClick={() => {
                                setSelectedItem(item);
                                setFileContent((item as FileItem).content || '');
                                setIsFileDialogOpen(true);
                                setIsEditing(false);
                              }}>
                                <FileText className="h-4 w-4 mr-2" />
                                Open
                              </DropdownMenuItem>
                            )}
                            {item.type === 'file' && (
                              <DropdownMenuItem onClick={() => {
                                setSelectedItem(item);
                                setFileContent((item as FileItem).content || '');
                                setIsFileDialogOpen(true);
                                setIsEditing(true);
                              }}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => {
                              setSelectedItem(item);
                              setIsDeleteDialogOpen(true);
                            }}>
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-2">
              {currentItems.length === 0 ? (
                <div className="col-span-full text-center py-8 text-muted-foreground">
                  This folder is empty
                </div>
              ) : (
                currentItems.map((item) => (
                  <div 
                    key={item.id}
                    className="border rounded-md p-4 cursor-pointer hover:bg-muted/50 flex flex-col items-center text-center"
                    onClick={() => item.type === 'folder' 
                      ? handleFolderClick(item as FolderItem) 
                      : handleFileClick(item as FileItem)
                    }
                  >
                    {item.type === 'folder' ? (
                      <Folder className="h-12 w-12 mb-2 text-blue-500" />
                    ) : (
                      React.cloneElement(getFileIcon(item.name), { className: "h-12 w-12 mb-2" })
                    )}
                    <div className="font-medium truncate w-full">{item.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {item.type === 'folder' ? 'Folder' : (item as FileItem).size}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="recent" className="flex-1">
          <div className="text-center py-8 text-muted-foreground">
            Recent files will appear here
          </div>
        </TabsContent>
        
        <TabsContent value="favorites" className="flex-1">
          <div className="text-center py-8 text-muted-foreground">
            You haven't added any favorites yet
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Create New Item Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New {newItemType === 'folder' ? 'Folder' : 'File'}</DialogTitle>
            <DialogDescription>
              Enter a name for the new {newItemType === 'folder' ? 'folder' : 'file'}.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="flex items-center space-x-4">
              <Button 
                variant={newItemType === 'folder' ? 'default' : 'outline'}
                onClick={() => setNewItemType('folder')}
              >
                <Folder className="h-4 w-4 mr-2" />
                Folder
              </Button>
              <Button 
                variant={newItemType === 'file' ? 'default' : 'outline'}
                onClick={() => setNewItemType('file')}
              >
                <File className="h-4 w-4 mr-2" />
                File
              </Button>
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                Name
              </Label>
              <Input
                id="name"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                className="col-span-3"
                placeholder={newItemType === 'folder' ? 'New Folder' : 'New File.txt'}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={createNewItem}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* File Viewer/Editor Dialog */}
      <Dialog open={isFileDialogOpen} onOpenChange={setIsFileDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedItem?.name} {isEditing && '(Editing)'}
            </DialogTitle>
            <DialogDescription>
              {isEditing 
                ? 'Edit file content' 
                : 'File content viewer'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="border rounded-md p-2 min-h-[200px] max-h-[400px] overflow-auto">
            {isEditing ? (
              <textarea 
                className="w-full h-full min-h-[200px] resize-none border-0 focus:outline-none"
                value={fileContent}
                onChange={(e) => setFileContent(e.target.value)}
              />
            ) : (
              <pre className="whitespace-pre-wrap text-sm">
                {fileContent}
              </pre>
            )}
          </div>
          
          <DialogFooter>
            {isEditing ? (
              <>
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={saveFileContent}>Save</Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => setIsFileDialogOpen(false)}>
                  Close
                </Button>
                <Button onClick={() => setIsEditing(true)}>Edit</Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Delete {selectedItem?.type === 'folder' ? 'Folder' : 'File'}</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{selectedItem?.name}"? This action cannot be undone.
              {selectedItem?.type === 'folder' && ' All contents within this folder will also be deleted.'}
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={deleteItem}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}