import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Patient, InsertPatient } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

type FormSection = 'personal' | 'medical' | 'emergency' | 'insurance' | 'consent';

export default function PatientFormWindow() {
  const { toast } = useToast();
  const [currentSection, setCurrentSection] = useState<FormSection>('personal');
  const [formData, setFormData] = useState<Partial<InsertPatient>>({
    patientId: `P-${Math.floor(10000 + Math.random() * 90000)}`,
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: '',
    address: '',
    phoneNumber: '',
    email: '',
    insuranceProvider: '',
    insuranceNumber: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
    medicalHistory: '',
    currentMedications: '',
    allergies: '',
    bloodType: '',
    admissionDate: new Date().toISOString().split('T')[0],
    status: 'active',
    assignedDoctorId: 1,
    height: 0,
    weight: 0
  });
  
  const [additionalInfo, setAdditionalInfo] = useState({
    relationship: '',
    symptoms: '',
    insuranceGroupNumber: '',
    primaryCareProvider: '',
    preferredPharmacy: '',
    consentToTreatment: false,
    consentToShareInfo: false,
    signature: '',
    dateOfSignature: new Date().toISOString().split('T')[0]
  });
  
  const { data: patients } = useQuery<Patient[]>({
    queryKey: ['/api/patients'],
  });
  
  const createPatientMutation = useMutation({
    mutationFn: async (data: Partial<InsertPatient>) => {
      const res = await apiRequest("POST", "/api/patients", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/patients'] });
      toast({
        title: "Success",
        description: "Patient information has been saved successfully",
        variant: "default",
      });
      
      // Reset form
      setFormData({
        patientId: `P-${Math.floor(10000 + Math.random() * 90000)}`,
        firstName: '',
        lastName: '',
        dateOfBirth: '',
        gender: '',
        address: '',
        phoneNumber: '',
        email: '',
        insuranceProvider: '',
        insuranceNumber: '',
        emergencyContactName: '',
        emergencyContactPhone: '',
        medicalHistory: '',
        currentMedications: '',
        allergies: '',
        bloodType: '',
        admissionDate: new Date().toISOString().split('T')[0],
        status: 'active',
        assignedDoctorId: 1,
        height: 0,
        weight: 0
      });
      
      setAdditionalInfo({
        relationship: '',
        symptoms: '',
        insuranceGroupNumber: '',
        primaryCareProvider: '',
        preferredPharmacy: '',
        consentToTreatment: false,
        consentToShareInfo: false,
        signature: '',
        dateOfSignature: new Date().toISOString().split('T')[0]
      });
      
      setCurrentSection('personal');
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to save patient information: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    if (name in formData) {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'number' ? parseFloat(value) : value
      }));
    } else {
      setAdditionalInfo(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };
  
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setAdditionalInfo(prev => ({
      ...prev,
      [name]: checked
    }));
  };
  
  const handleNextSection = () => {
    const sections: FormSection[] = ['personal', 'medical', 'emergency', 'insurance', 'consent'];
    const currentIndex = sections.indexOf(currentSection);
    if (currentIndex < sections.length - 1) {
      setCurrentSection(sections[currentIndex + 1]);
    }
  };
  
  const handlePrevSection = () => {
    const sections: FormSection[] = ['personal', 'medical', 'emergency', 'insurance', 'consent'];
    const currentIndex = sections.indexOf(currentSection);
    if (currentIndex > 0) {
      setCurrentSection(sections[currentIndex - 1]);
    }
  };
  
  const handleSubmitForm = () => {
    // Basic validation
    if (!formData.firstName || !formData.lastName || !formData.dateOfBirth) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    if (!additionalInfo.consentToTreatment || !additionalInfo.signature) {
      toast({
        title: "Consent Required",
        description: "Please provide consent and signature to continue",
        variant: "destructive",
      });
      return;
    }
    
    // Submit the form
    createPatientMutation.mutate(formData as InsertPatient);
  };
  
  // Progress percentage
  const getProgressPercentage = () => {
    const sections: FormSection[] = ['personal', 'medical', 'emergency', 'insurance', 'consent'];
    const currentIndex = sections.indexOf(currentSection);
    return ((currentIndex + 1) / sections.length) * 100;
  };
  
  return (
    <div className="h-full flex flex-col bg-white overflow-hidden">
      {/* Patient Form Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-800 p-3 flex items-center justify-between">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center mr-3">
            <i className="fas fa-user-plus text-green-600 text-xl"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Patient Registration Form</h1>
            <p className="text-white text-opacity-80 text-sm">Complete all sections to register a new patient</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-white">Patient ID: {formData.patientId}</span>
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="bg-gray-100 px-4 py-2 border-b">
        <div className="flex justify-between text-sm text-gray-500 mb-1">
          <span>Progress</span>
          <span>{Math.round(getProgressPercentage())}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div 
            className="bg-green-600 h-2.5 rounded-full" 
            style={{ width: `${getProgressPercentage()}%` }}
          ></div>
        </div>
      </div>
      
      {/* Form Navigation */}
      <div className="bg-gray-50 px-4 py-2 border-b flex overflow-x-auto">
        <button 
          onClick={() => setCurrentSection('personal')}
          className={`px-4 py-2 mr-2 rounded-md ${currentSection === 'personal' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
        >
          <i className="fas fa-user mr-2"></i>Personal Information
        </button>
        <button 
          onClick={() => setCurrentSection('medical')}
          className={`px-4 py-2 mr-2 rounded-md ${currentSection === 'medical' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
        >
          <i className="fas fa-notes-medical mr-2"></i>Medical History
        </button>
        <button 
          onClick={() => setCurrentSection('emergency')}
          className={`px-4 py-2 mr-2 rounded-md ${currentSection === 'emergency' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
        >
          <i className="fas fa-phone-alt mr-2"></i>Emergency Contact
        </button>
        <button 
          onClick={() => setCurrentSection('insurance')}
          className={`px-4 py-2 mr-2 rounded-md ${currentSection === 'insurance' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
        >
          <i className="fas fa-id-card mr-2"></i>Insurance
        </button>
        <button 
          onClick={() => setCurrentSection('consent')}
          className={`px-4 py-2 rounded-md ${currentSection === 'consent' ? 'bg-green-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
        >
          <i className="fas fa-signature mr-2"></i>Consent & Signature
        </button>
      </div>
      
      {/* Form Content */}
      <div className="flex-1 overflow-auto p-6">
        <form onSubmit={(e) => e.preventDefault()} className="max-w-4xl mx-auto">
          {/* Personal Information Section */}
          {currentSection === 'personal' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-gray-800 border-b pb-2">Personal Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    First Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Last Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date of Birth <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    name="dateOfBirth"
                    value={formData.dateOfBirth}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Gender <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                  >
                    <option value="">Select gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                    <option value="prefer-not-to-say">Prefer not to say</option>
                  </select>
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Address <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    name="phoneNumber"
                    value={formData.phoneNumber}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Height (cm)
                  </label>
                  <input
                    type="number"
                    name="height"
                    value={formData.height || ''}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Weight (kg)
                  </label>
                  <input
                    type="number"
                    name="weight"
                    value={formData.weight || ''}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>
            </div>
          )}
          
          {/* Medical History Section */}
          {currentSection === 'medical' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-gray-800 border-b pb-2">Medical Information</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Current Symptoms
                  </label>
                  <textarea
                    name="symptoms"
                    value={additionalInfo.symptoms}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 min-h-[100px]"
                    placeholder="Please describe your current symptoms and concerns"
                  ></textarea>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Medical History
                  </label>
                  <textarea
                    name="medicalHistory"
                    value={formData.medicalHistory}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 min-h-[100px]"
                    placeholder="Please list any past medical conditions, surgeries, or hospitalizations"
                  ></textarea>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Current Medications
                  </label>
                  <textarea
                    name="currentMedications"
                    value={formData.currentMedications}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 min-h-[100px]"
                    placeholder="Please list all current medications and dosages"
                  ></textarea>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Allergies
                  </label>
                  <textarea
                    name="allergies"
                    value={formData.allergies}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="Please list any allergies to medications, foods, or environmental factors"
                  ></textarea>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Blood Type
                    </label>
                    <select
                      name="bloodType"
                      value={formData.bloodType}
                      onChange={handleInputChange}
                      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    >
                      <option value="">Select blood type</option>
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                      <option value="Unknown">Unknown</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Preferred Pharmacy
                    </label>
                    <input
                      type="text"
                      name="preferredPharmacy"
                      value={additionalInfo.preferredPharmacy}
                      onChange={handleInputChange}
                      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Emergency Contact Section */}
          {currentSection === 'emergency' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-gray-800 border-b pb-2">Emergency Contact Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Emergency Contact Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="emergencyContactName"
                    value={formData.emergencyContactName}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Emergency Contact Phone <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    name="emergencyContactPhone"
                    value={formData.emergencyContactPhone}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Relationship to Patient
                  </label>
                  <select
                    name="relationship"
                    value={additionalInfo.relationship}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select relationship</option>
                    <option value="spouse">Spouse</option>
                    <option value="parent">Parent</option>
                    <option value="child">Child</option>
                    <option value="sibling">Sibling</option>
                    <option value="friend">Friend</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>
            </div>
          )}
          
          {/* Insurance Section */}
          {currentSection === 'insurance' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-gray-800 border-b pb-2">Insurance Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Insurance Provider
                  </label>
                  <input
                    type="text"
                    name="insuranceProvider"
                    value={formData.insuranceProvider}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Insurance ID Number
                  </label>
                  <input
                    type="text"
                    name="insuranceNumber"
                    value={formData.insuranceNumber}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Group Number
                  </label>
                  <input
                    type="text"
                    name="insuranceGroupNumber"
                    value={additionalInfo.insuranceGroupNumber}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Primary Care Provider
                  </label>
                  <input
                    type="text"
                    name="primaryCareProvider"
                    value={additionalInfo.primaryCareProvider}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-blue-800 font-medium mb-2">Insurance Card</h3>
                <p className="text-blue-600 mb-4">Please provide a copy of the front and back of your insurance card.</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Front of Card
                    </label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                      <i className="fas fa-upload text-gray-400 text-2xl mb-2"></i>
                      <p className="text-gray-500">Click to upload or drag and drop</p>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Back of Card
                    </label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                      <i className="fas fa-upload text-gray-400 text-2xl mb-2"></i>
                      <p className="text-gray-500">Click to upload or drag and drop</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Consent Section */}
          {currentSection === 'consent' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-gray-800 border-b pb-2">Consent & Authorization</h2>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium mb-2">Consent for Treatment</h3>
                <p className="text-sm text-gray-700 mb-4">
                  I voluntarily consent to medical treatment and diagnostic procedures provided by General Hospital and its associated physicians, clinicians and other personnel. I am aware that the practice of medicine and surgery is not an exact science and I acknowledge that no guarantees have been made to me as to the result of treatments or examinations at General Hospital.
                </p>
                
                <div className="flex items-center mb-4">
                  <input
                    type="checkbox"
                    id="consentToTreatment"
                    name="consentToTreatment"
                    checked={additionalInfo.consentToTreatment}
                    onChange={handleCheckboxChange}
                    className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                  />
                  <label htmlFor="consentToTreatment" className="ml-2 text-sm text-gray-700">
                    I consent to treatment <span className="text-red-500">*</span>
                  </label>
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium mb-2">Release of Information & Privacy Practices</h3>
                <p className="text-sm text-gray-700 mb-4">
                  I acknowledge that I have received the Notice of Privacy Practices, which describes the ways in which the hospital may use and disclose my healthcare information for its treatment, payment, healthcare operations and other prescribed and permitted uses and disclosures. I understand that this information may be disclosed electronically by the Provider and/or the Provider's business associates.
                </p>
                
                <div className="flex items-center mb-4">
                  <input
                    type="checkbox"
                    id="consentToShareInfo"
                    name="consentToShareInfo"
                    checked={additionalInfo.consentToShareInfo}
                    onChange={handleCheckboxChange}
                    className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                  />
                  <label htmlFor="consentToShareInfo" className="ml-2 text-sm text-gray-700">
                    I consent to sharing of information
                  </label>
                </div>
              </div>
              
              <div className="space-y-6 mt-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Signature <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="signature"
                    value={additionalInfo.signature}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="Type your full name as signature"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    name="dateOfSignature"
                    value={additionalInfo.dateOfSignature}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
              </div>
            </div>
          )}
        </form>
      </div>
      
      {/* Form Navigation Buttons */}
      <div className="border-t border-gray-200 p-4 flex justify-between bg-gray-50">
        <button
          onClick={handlePrevSection}
          className={`px-6 py-2 rounded-md text-gray-600 bg-gray-200 hover:bg-gray-300 ${currentSection === 'personal' ? 'opacity-50 cursor-not-allowed' : ''}`}
          disabled={currentSection === 'personal'}
        >
          <i className="fas fa-chevron-left mr-2"></i>
          Previous
        </button>
        
        {currentSection !== 'consent' ? (
          <button
            onClick={handleNextSection}
            className="px-6 py-2 rounded-md bg-green-600 text-white hover:bg-green-700"
          >
            Next
            <i className="fas fa-chevron-right ml-2"></i>
          </button>
        ) : (
          <button
            onClick={handleSubmitForm}
            className="px-6 py-2 rounded-md bg-green-600 text-white hover:bg-green-700 flex items-center"
            disabled={createPatientMutation.isPending}
          >
            {createPatientMutation.isPending ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>
                Submitting...
              </>
            ) : (
              <>
                <i className="fas fa-check-circle mr-2"></i>
                Submit Form
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
}