import React, { createContext, useState, useContext, ReactNode, useEffect } from "react";
import { WindowState, WindowContextType, WindowComponents } from "@/lib/types";
import Dashboard from "@/components/dashboard/Dashboard";
import PatientsWindow from "@/components/patients/PatientsWindow";
import AppointmentsWindow from "@/components/appointments/AppointmentsWindow";
import StaffWindow from "@/components/staff/StaffWindow";
import InventoryWindow from "@/components/inventory/InventoryWindow";
import ReportsWindow from "@/components/reports/ReportsWindow";
import TerminalWindow from "@/components/terminal/TerminalWindow";
import SettingsWindow from "@/components/settings/SettingsWindow";
import AdminControlPanel from "@/components/admin/AdminControlPanel";
import TaskManager from "@/components/admin/TaskManager";
import EmergencyWindow from "@/components/emergency/EmergencyWindow";
import LabWindow from "@/components/lab/LabWindow";
import PatientFormWindow from "@/components/patientform/PatientFormWindow";
import FilesWindow from "@/components/files/FilesWindow";

const WindowContext = createContext<WindowContextType | undefined>(undefined);

export function WindowProvider({ children }: { children: ReactNode }) {
  const [windows, setWindows] = useState<WindowState[]>([]);
  const [activeWindowId, setActiveWindowId] = useState<string | null>(null);
  const [nextZIndex, setNextZIndex] = useState(1);
  // Initialize with saved icons or defaults
  const [desktopIcons, setDesktopIcons] = useState<WindowComponents[]>(() => {
    // Try to load from localStorage first
    const savedIcons = localStorage.getItem('hospitalOS_desktopIcons');
    if (savedIcons) {
      try {
        return JSON.parse(savedIcons);
      } catch (e) {
        console.error("Failed to parse saved desktop icons", e);
      }
    }
    
    // Default set of desktop icons
    return [
      "dashboard", 
      "patients", 
      "appointments", 
      "emergency",
      "lab",
      "patientform",
      "files"
    ];
  });

  const addWindowIfNotExists = (windowId: WindowComponents): boolean => {
    // STRICT check if window already exists
    const windowExists = windows.some(w => w.id === windowId);
    console.log(`Check if window ${windowId} exists: ${windowExists}`);
    
    if (windowExists) {
      console.log(`Window ${windowId} already exists in state, not creating duplicate`);
      return false;
    }
    
    console.log(`Creating new window: ${windowId}`);
    let windowComponent;
    let windowTitle;
    let windowIcon;
    
    switch (windowId) {
      case 'dashboard':
        windowComponent = <Dashboard />;
        windowTitle = 'Hospital Dashboard';
        windowIcon = 'fas fa-hospital';
        break;
      case 'patients':
        windowComponent = <PatientsWindow />;
        windowTitle = 'Patient Records';
        windowIcon = 'fas fa-user-injured';
        break;
      case 'appointments':
        windowComponent = <AppointmentsWindow />;
        windowTitle = 'Appointment Scheduler';
        windowIcon = 'far fa-calendar-alt';
        break;
      case 'staff':
        windowComponent = <StaffWindow />;
        windowTitle = 'Staff Portal';
        windowIcon = 'fas fa-user-md';
        break;
      case 'inventory':
        windowComponent = <InventoryWindow />;
        windowTitle = 'Inventory Management';
        windowIcon = 'fas fa-pills';
        break;
      case 'reports':
        windowComponent = <ReportsWindow />;
        windowTitle = 'Reports & Analytics';
        windowIcon = 'fas fa-chart-bar';
        break;
      case 'emergency':
        windowComponent = <EmergencyWindow />;
        windowTitle = 'Emergency Response';
        windowIcon = 'fas fa-ambulance';
        break;
      case 'lab':
        windowComponent = <LabWindow />;
        windowTitle = 'Laboratory Results';
        windowIcon = 'fas fa-microscope';
        break;
      case 'patientform':
        windowComponent = <PatientFormWindow />;
        windowTitle = 'Patient Registration Form';
        windowIcon = 'fas fa-user-plus';
        break;
      case 'terminal':
        windowComponent = <TerminalWindow />;
        windowTitle = 'Terminal';
        windowIcon = 'fas fa-terminal';
        break;
      case 'settings':
        windowComponent = <SettingsWindow />;
        windowTitle = 'System Settings';
        windowIcon = 'fas fa-cog';
        break;
      case 'adminpanel':
        windowComponent = <AdminControlPanel />;
        windowTitle = 'Admin Control Panel';
        windowIcon = 'fas fa-lock';
        break;
      case 'taskmanager':
        windowComponent = <TaskManager />;
        windowTitle = 'Task Manager';
        windowIcon = 'fas fa-tasks';
        break;
      case 'files':
        windowComponent = <FilesWindow />;
        windowTitle = 'File Explorer';
        windowIcon = 'fas fa-folder';
        break;
      default:
        console.log(`Unknown window ID: ${windowId}`);
        return false;
    }
    
    // Add window to state with random position
    const randomOffset = Math.floor(Math.random() * 100);
    const newWindow = {
      id: windowId,
      title: windowTitle,
      icon: windowIcon,
      component: windowComponent,
      isOpen: true,
      isMinimized: false,
      isMaximized: false,
      zIndex: nextZIndex, // Use nextZIndex for proper layering
      x: 36 + randomOffset,
      y: 10 + randomOffset,
      width: windowId === 'dashboard' ? 'calc(100% - 250px)' : '800px',
      height: windowId === 'dashboard' ? 'calc(100% - 120px)' : '600px'
    };
    
    // Use functional update pattern with another check to prevent race conditions
    setWindows(prevWindows => {
      // Double-check inside the state update to prevent race conditions
      if (prevWindows.some(w => w.id === windowId)) {
        console.log(`Late check: Window ${windowId} already exists, not adding`);
        return prevWindows;
      }
      
      console.log(`Adding window ${windowId} to state`);
      return [...prevWindows, newWindow];
    });
    
    setNextZIndex(prev => prev + 1);
    return true;
  };

  const openWindow = (id: string) => {
    // Check if window is already open
    const existingWindow = windows.find(window => window.id === id);
    
    if (existingWindow) {
      // If window exists but is minimized, restore it
      if (existingWindow.isMinimized) {
        setWindows(prevWindows => 
          prevWindows.map(window => 
            window.id === id 
              ? { ...window, isMinimized: false, zIndex: nextZIndex } 
              : window
          )
        );
        setNextZIndex(prev => prev + 1);
      } 
      // Just focus the window
      focusWindow(id);
    } else {
      // Window doesn't exist in state, we should create it
      const result = addWindowIfNotExists(id as WindowComponents);
      console.log(`Adding window ${id}: ${result}`);
    }
    
    setActiveWindowId(id);
  };

  const closeWindow = (id: string) => {
    setWindows(prevWindows => prevWindows.filter(window => window.id !== id));
    
    // If we closed the active window, set active to the highest z-index window
    if (activeWindowId === id) {
      const remainingWindows = windows.filter(window => window.id !== id);
      if (remainingWindows.length > 0) {
        const highestZIndexWindow = remainingWindows.reduce((prev, current) => 
          (prev.zIndex > current.zIndex) ? prev : current
        );
        setActiveWindowId(highestZIndexWindow.id);
      } else {
        setActiveWindowId(null);
      }
    }
  };

  const minimizeWindow = (id: string) => {
    setWindows(prevWindows => 
      prevWindows.map(window => 
        window.id === id 
          ? { ...window, isMinimized: true } 
          : window
      )
    );
    
    // If we minimized the active window, set active to null
    if (activeWindowId === id) {
      const visibleWindows = windows.filter(window => !window.isMinimized && window.id !== id);
      if (visibleWindows.length > 0) {
        const highestZIndexWindow = visibleWindows.reduce((prev, current) => 
          (prev.zIndex > current.zIndex) ? prev : current
        );
        setActiveWindowId(highestZIndexWindow.id);
      } else {
        setActiveWindowId(null);
      }
    }
  };

  const maximizeWindow = (id: string) => {
    setWindows(prevWindows => 
      prevWindows.map(window => 
        window.id === id 
          ? { ...window, isMaximized: !window.isMaximized } 
          : window
      )
    );
  };

  const focusWindow = (id: string) => {
    setWindows(prevWindows => 
      prevWindows.map(window => 
        window.id === id 
          ? { ...window, zIndex: nextZIndex } 
          : window
      )
    );
    setNextZIndex(prev => prev + 1);
    setActiveWindowId(id);
  };

  const value = {
    windows,
    activeWindowId,
    openWindow,
    closeWindow,
    minimizeWindow,
    maximizeWindow,
    focusWindow,
    addWindowIfNotExists,
    desktopIcons,
    setDesktopIcons
  };

  return <WindowContext.Provider value={value}>{children}</WindowContext.Provider>;
}

export function useWindowContext() {
  const context = useContext(WindowContext);
  if (context === undefined) {
    throw new Error("useWindowContext must be used within a WindowProvider");
  }
  return context;
}
