import React, { useState, useEffect } from 'react';
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { WindowProvider } from "./context/WindowContext";
import Desktop from "./components/layout/Desktop";
import DeviceSelector from "./components/DeviceSelector";
import { DevicePreference, WindowComponents } from './lib/types';
import SetupPage from "./pages/setup-page";

// Import CSS for FontAwesome
const fontAwesomeCSS = document.createElement('link');
fontAwesomeCSS.rel = 'stylesheet';
fontAwesomeCSS.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css';
document.head.appendChild(fontAwesomeCSS);

function App() {
  const [showDeviceSelector, setShowDeviceSelector] = useState<boolean>(true);
  const [deviceMode, setDeviceMode] = useState<'mobile' | 'laptop'>('laptop');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isFirstTimeUser, setIsFirstTimeUser] = useState<boolean>(false);
  const [setupWindowOpen, setSetupWindowOpen] = useState<boolean>(false);
  const [showSetupPage, setShowSetupPage] = useState<boolean>(false);

  // BIOS related states
  const [showBios, setShowBios] = useState(false);
  const [biosProgress, setBiosProgress] = useState(0);
  const [biosStage, setBiosStage] = useState<'POST' | 'MEM' | 'CPU' | 'HDD' | 'BOOT'>('POST');
  const [showBiosMessage, setShowBiosMessage] = useState(true);
  
  // Check for saved device preference and first-time setup on app start
  useEffect(() => {
    // Check if first-time setup has been completed
    const setupCompleted = localStorage.getItem('hospitalOSFirstTimeSetup') === 'true';
    setIsFirstTimeUser(!setupCompleted);
    setShowSetupPage(!setupCompleted);
    
    const savedPreference = localStorage.getItem('devicePreference');
    
    if (savedPreference) {
      try {
        const parsed = JSON.parse(savedPreference) as DevicePreference;
        setDeviceMode(parsed.selectedDevice);
        // Skip device selector if preference exists
        setShowDeviceSelector(false);
      } catch (e) {
        console.error('Error parsing device preference:', e);
      }
    }
  }, []);
  
  // Handle setup completion
  const handleSetupComplete = () => {
    setShowSetupPage(false);
    setIsFirstTimeUser(false);
    
    // Mark first-time setup as complete
    localStorage.setItem('hospitalOSFirstTimeSetup', 'true');
    
    // Start loading screen after setup is complete
    setIsLoading(true);
    
    // Simulate loading screen for 30 seconds
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 30000);
    
    return () => clearTimeout(timer);
  };
  
  const handleDeviceSelected = (device: 'mobile' | 'laptop') => {
    setDeviceMode(device);
    setShowDeviceSelector(false);
    
    // Save preference to localStorage
    localStorage.setItem('devicePreference', JSON.stringify({ selectedDevice: device }));
    
    // If first time user, show setup page, otherwise show loading screen
    if (isFirstTimeUser && !showSetupPage) {
      setShowSetupPage(true);
    } else if (!isFirstTimeUser) {
      // Start loading screen
      setIsLoading(true);
      
      // Simulate loading screen for 30 seconds
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 30000);
      
      return () => clearTimeout(timer);
    }
  };

  // BIOS loading effect
  useEffect(() => {
    if (isLoading && showBios) {
      // Progress through BIOS stages
      const stageTimer = setInterval(() => {
        setBiosProgress(prev => {
          const newProgress = prev + 2;
          
          // Change stages at different progress points
          if (newProgress === 20) setBiosStage('MEM');
          else if (newProgress === 40) setBiosStage('CPU');
          else if (newProgress === 60) setBiosStage('HDD');
          else if (newProgress === 80) setBiosStage('BOOT');
          else if (newProgress >= 100) {
            clearInterval(stageTimer);
            // After BIOS completes, go back to code screen
            setTimeout(() => setShowBios(false), 1000);
            return 100;
          }
          
          return newProgress;
        });
      }, 75);
      
      return () => clearInterval(stageTimer);
    }
  }, [isLoading, showBios]);
  
  // Auto-hide the BIOS message after 5 seconds
  useEffect(() => {
    if (showBiosMessage && isLoading) {
      const messageTimer = setTimeout(() => {
        setShowBiosMessage(false);
      }, 5000);
      
      return () => clearTimeout(messageTimer);
    }
  }, [showBiosMessage, isLoading]);

  // Render BIOS screen
  const renderBiosScreen = () => {
    return (
      <div className="fixed inset-0 bg-black font-mono z-50 p-4 overflow-hidden text-white">
        <div className="max-w-4xl mx-auto">
          <div className="mb-4">
            <div className="flex justify-between items-center mb-4 bg-blue-950 p-2">
              <div className="text-xl font-bold text-white">MedSys BIOS Setup Utility</div>
              <div className="text-sm text-gray-300">v3.2.1</div>
            </div>
            
            <div className="bg-blue-900 p-4 border border-blue-700">
              <div className="grid grid-cols-5 gap-2 mb-6">
                <div className="col-span-1 text-blue-200 text-sm font-bold">System Time:</div>
                <div className="col-span-4 text-white">{new Date().toLocaleTimeString()}</div>
                
                <div className="col-span-1 text-blue-200 text-sm font-bold">System Date:</div>
                <div className="col-span-4 text-white">{new Date().toLocaleDateString()}</div>
                
                <div className="col-span-1 text-blue-200 text-sm font-bold">SATA Ports:</div>
                <div className="col-span-4 text-white">[Auto]</div>
                
                <div className="col-span-1 text-blue-200 text-sm font-bold">System Memory:</div>
                <div className="col-span-4 text-white">64GB DDR4 3200MHz</div>
                
                <div className="col-span-1 text-blue-200 text-sm font-bold">CPU Type:</div>
                <div className="col-span-4 text-white">Intel Xeon E5-2678 v3 @ 3.50GHz</div>
              </div>
              
              <div className="mb-4 border border-blue-700 p-3">
                <div className="text-blue-100 font-bold mb-2">Boot Sequence Diagnostic</div>
                <div className="flex justify-between mb-2">
                  <div>Progress</div>
                  <div>{biosProgress}%</div>
                </div>
                <div className="w-full bg-blue-950 h-2 mb-3">
                  <div className="bg-green-500 h-2" style={{ width: `${biosProgress}%` }}></div>
                </div>
                
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div className="text-blue-200">Component</div>
                  <div className="text-blue-200">Status</div>
                  <div className="text-blue-200">Info</div>
                  
                  <div>POST</div>
                  <div className={biosStage === 'POST' ? 'text-yellow-400' : 'text-green-400'}>
                    {biosStage === 'POST' ? 'CHECKING' : 'PASSED'}
                  </div>
                  <div>0x00</div>
                  
                  <div>Memory</div>
                  <div className={
                    biosStage === 'MEM' ? 'text-yellow-400' : 
                    biosStage === 'POST' ? 'text-gray-500' : 'text-green-400'
                  }>
                    {biosStage === 'MEM' ? 'CHECKING' : 
                     biosStage === 'POST' ? 'PENDING' : 'PASSED'}
                  </div>
                  <div>64GB OK</div>
                  
                  <div>CPU</div>
                  <div className={
                    biosStage === 'CPU' ? 'text-yellow-400' : 
                    biosStage === 'POST' || biosStage === 'MEM' ? 'text-gray-500' : 'text-green-400'
                  }>
                    {biosStage === 'CPU' ? 'CHECKING' : 
                     biosStage === 'POST' || biosStage === 'MEM' ? 'PENDING' : 'PASSED'}
                  </div>
                  <div>3.5GHz</div>
                  
                  <div>Storage</div>
                  <div className={
                    biosStage === 'HDD' ? 'text-yellow-400' : 
                    biosStage === 'POST' || biosStage === 'MEM' || biosStage === 'CPU' ? 'text-gray-500' : 'text-green-400'
                  }>
                    {biosStage === 'HDD' ? 'CHECKING' : 
                     biosStage === 'POST' || biosStage === 'MEM' || biosStage === 'CPU' ? 'PENDING' : 'PASSED'}
                  </div>
                  <div>NVMe SSD</div>
                  
                  <div>Boot Loader</div>
                  <div className={
                    biosStage === 'BOOT' ? 'text-yellow-400' : 
                    (biosStage === 'POST' || biosStage === 'MEM' || biosStage === 'CPU' || biosStage === 'HDD') ? 'text-gray-500' : 'text-green-400'
                  }>
                    {biosStage === 'BOOT' ? 'LOADING' : 
                     (biosStage === 'POST' || biosStage === 'MEM' || biosStage === 'CPU' || biosStage === 'HDD') ? 'PENDING' : 'PASSED'}
                  </div>
                  <div>UEFI</div>
                </div>
              </div>
            </div>
            
            <div className="bg-blue-950 p-3 flex justify-between items-center">
              <div className="text-sm text-gray-300">Press ESC to exit</div>
              
              <div className="text-sm flex space-x-4 text-gray-300">
                <div>F10: Save & Exit</div>
                <div>F7: Defaults</div>
                <div>F2: Previous</div>
                <div>F3: Next</div>
              </div>
            </div>
            
            {biosStage === 'BOOT' && biosProgress > 90 && (
              <div className="text-lg text-green-400 animate-pulse text-center mt-4">
                Loading Hospital Management System...
              </div>
            )}
            
            {/* Exit button */}
            <div className="mt-4 flex justify-center">
              <button
                onClick={() => setShowBios(false)}
                className="px-4 py-2 bg-blue-700 text-white rounded hover:bg-blue-600 transition-colors"
              >
                Exit BIOS
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Render loading screen with animated code
  const renderLoadingScreen = () => {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-50">
        <div className="text-green-500 text-3xl mb-8">Hospital Management System</div>
        <div className="w-80 h-60 overflow-hidden bg-black border border-green-500 rounded p-2 mb-8">
          <div className="animate-slide text-green-400 font-mono text-xs">
            {Array(100).fill(0).map((_, i) => (
              <div key={i} className="whitespace-nowrap">
                {`${Math.random().toString(36).substring(2, 10)} ${Math.random().toString(36).substring(2, 10)} ${Math.random().toString(36).substring(2, 5)}`}
              </div>
            ))}
          </div>
        </div>
        <div className="text-green-400 mb-8">Initializing system components...</div>
        
        {/* BIOS access button */}
        <button
          onClick={() => {
            setShowBios(true);
            setBiosProgress(0);
            setBiosStage('POST');
          }}
          className="px-4 py-2 bg-blue-900 text-white rounded hover:bg-blue-800 transition-colors"
        >
          Access BIOS
        </button>
        
        {/* BIOS access message */}
        {showBiosMessage && (
          <div className="absolute bottom-4 right-4 bg-black bg-opacity-80 border border-blue-500 p-3 rounded text-blue-300 max-w-xs animate-pulse">
            <p className="text-sm">Press "Access BIOS" to enter the system configuration utility</p>
          </div>
        )}
      </div>
    );
  };
  
  // Show device selector first if needed
  if (showDeviceSelector) {
    return <DeviceSelector onDeviceSelected={handleDeviceSelected} />;
  }
  
  // Show setup page for first-time users
  if (showSetupPage) {
    return <SetupPage onSetupComplete={handleSetupComplete} />;
  }
  
  // Show the loading screen if loading is active
  if (isLoading) {
    // Show BIOS screen or regular loading screen
    return showBios ? renderBiosScreen() : renderLoadingScreen();
  }
  
  // Show the main application
  return (
    <QueryClientProvider client={queryClient}>
      <WindowProvider>
        <div className={deviceMode === 'mobile' ? 'mobile-mode' : 'desktop-mode'}>
          <Desktop isFirstTimeUser={false} setupWindowOpen={false} />
        </div>
        <Toaster />
      </WindowProvider>
    </QueryClientProvider>
  );
}

export default App;
