import { useEffect } from 'react';

// This hook updates UI elements to use the latest personalization settings
export function useProfile() {
  useEffect(() => {
    // Function to update profile elements with CSS variables
    const updateProfileElements = () => {
      const usernameElement = document.getElementById('profile-username');
      
      if (usernameElement) {
        // Get the CSS variable value
        const computedStyle = getComputedStyle(document.documentElement);
        const username = computedStyle.getPropertyValue('--user-name').replace(/['"]/g, '');
        
        // Update the element
        usernameElement.textContent = username;
      }
    };

    // Run immediately
    updateProfileElements();

    // Set up MutationObserver to watch for changes in CSS variables
    const observer = new MutationObserver(updateProfileElements);
    
    // Watch for attribute changes on the root element
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['style'],
    });

    return () => {
      // Clean up observer on component unmount
      observer.disconnect();
    };
  }, []);
}