import { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { 
  Building, 
  Server, 
  FileText, 
  Settings, 
  User, 
  Shield, 
  Network, 
  FileJson, 
  LayoutDashboard, 
  KeyRound, 
  Laptop, 
  Cog,
  CheckCircle2, 
  FolderPlus, 
  HardDrive, 
  Monitor, 
  Wifi 
} from "lucide-react";

interface SetupPageProps {
  onSetupComplete: () => void;
}

export default function SetupPage({ onSetupComplete }: SetupPageProps) {
  const { toast } = useToast();
  
  // Setup steps and progress
  const [setupStep, setSetupStep] = useState(1);
  const [setupProgress, setSetupProgress] = useState(10);
  const [isInstallingFiles, setIsInstallingFiles] = useState(false);
  const [isSetupComplete, setIsSetupComplete] = useState(false);
  const [installProgress, setInstallProgress] = useState(0);
  const [installStage, setInstallStage] = useState(1);
  const [currentInstallItem, setCurrentInstallItem] = useState('');
  
  // User information
  const [userName, setUserName] = useState('');
  const [userDepartment, setUserDepartment] = useState('');
  const [userRole, setUserRole] = useState('');
  const [userAccessLevel, setUserAccessLevel] = useState('Standard');

  // Security questions
  const [securityQuestions, setSecurityQuestions] = useState({
    question1: '',
    answer1: '',
    question2: '',
    answer2: '',
  });

  // License agreement
  const [licenseAgreementAccepted, setLicenseAgreementAccepted] = useState(false);
  
  // Setup options
  const [setupOptions, setSetupOptions] = useState({
    enableAutoBackup: true,
    setupAutomaticUpdates: true,
    installDepartmentTemplates: true,
    setupAdvancedReporting: true,
    enableNotifications: true,
    setupDataEncryption: true,
    enableNetworkSharing: false,
    installExtraUtilities: true,
  });
  
  // Function to handle option changes
  const handleOptionChange = (option: string, value: boolean) => {
    setSetupOptions(prev => ({
      ...prev,
      [option]: value
    }));
  };
  
  // Function to handle security question changes
  const handleSecurityQuestionChange = (field: string, value: string) => {
    setSecurityQuestions(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Create a mock file system with desktop icons, folders, and files
  const createSystemFileSystem = (userName: string) => {
    type FileItem = {
      id: string;
      name: string;
      type: 'file';
      size: string;
      lastModified: string;
    };
    
    type FolderItem = {
      id: string;
      name: string;
      type: 'folder';
      lastModified: string;
      items: (FileItem | FolderItem)[];
    };
    
    const currentDate = new Date().toLocaleDateString();
    
    // Create the file system structure
    const fileSystem: FolderItem = {
      id: 'root',
      name: 'Root',
      type: 'folder',
      lastModified: currentDate,
      items: [
        {
          id: 'desktop',
          name: 'Desktop',
          type: 'folder',
          lastModified: currentDate,
          items: [
            {
              id: 'patient-records',
              name: 'Patient Records',
              type: 'folder',
              lastModified: currentDate,
              items: []
            },
            {
              id: 'medical-protocols',
              name: 'Medical Protocols',
              type: 'folder',
              lastModified: currentDate,
              items: []
            },
            {
              id: 'templates',
              name: 'Templates',
              type: 'folder',
              lastModified: currentDate,
              items: []
            },
            {
              id: 'readme',
              name: 'README.txt',
              type: 'file',
              size: '2.4 KB',
              lastModified: currentDate
            }
          ]
        },
        {
          id: 'documents',
          name: 'Documents',
          type: 'folder',
          lastModified: currentDate,
          items: [
            {
              id: 'user-guide',
              name: 'User Guide.pdf',
              type: 'file',
              size: '5.2 MB',
              lastModified: currentDate
            },
            {
              id: 'training-materials',
              name: 'Training Materials',
              type: 'folder',
              lastModified: currentDate,
              items: []
            }
          ]
        },
        {
          id: 'system',
          name: 'System',
          type: 'folder',
          lastModified: currentDate,
          items: [
            {
              id: 'logs',
              name: 'Logs',
              type: 'folder',
              lastModified: currentDate,
              items: []
            },
            {
              id: 'config',
              name: 'Configuration',
              type: 'folder',
              lastModified: currentDate,
              items: []
            }
          ]
        },
        {
          id: 'data',
          name: 'Data',
          type: 'folder',
          lastModified: currentDate,
          items: [
            {
              id: 'backups',
              name: 'Backups',
              type: 'folder',
              lastModified: currentDate,
              items: []
            },
            {
              id: 'exports',
              name: 'Exports',
              type: 'folder',
              lastModified: currentDate,
              items: []
            }
          ]
        },
        {
          id: 'user-profile',
          name: `${userName || 'User'} Profile`,
          type: 'folder',
          lastModified: currentDate,
          items: [
            {
              id: 'settings',
              name: 'Settings.json',
              type: 'file',
              size: '1.2 KB',
              lastModified: currentDate
            },
            {
              id: 'preferences',
              name: 'Preferences.json',
              type: 'file',
              size: '0.8 KB',
              lastModified: currentDate
            }
          ]
        }
      ]
    };
    
    // Add department-specific folders and files
    if (userDepartment && setupOptions.installDepartmentTemplates) {
      const deptFolder: FolderItem = {
        id: `dept-${userDepartment.toLowerCase()}`,
        name: `${userDepartment} Resources`,
        type: 'folder',
        lastModified: currentDate,
        items: [
          {
            id: `${userDepartment.toLowerCase()}-templates`,
            name: 'Templates',
            type: 'folder',
            lastModified: currentDate,
            items: []
          },
          {
            id: `${userDepartment.toLowerCase()}-protocols`,
            name: 'Protocols',
            type: 'folder',
            lastModified: currentDate,
            items: []
          }
        ]
      };
      
      // Add to desktop
      const desktop = fileSystem.items.find(item => item.id === 'desktop') as FolderItem;
      desktop.items.push(deptFolder);
    }
    
    // Save file system to localStorage
    localStorage.setItem('hospitalFileSystem', JSON.stringify(fileSystem));
    
    return fileSystem;
  };
  
  // Function to handle setup completion
  const completeSetup = () => {
    // Create the file system based on user choices
    createSystemFileSystem(userName);
    
    // Save user settings
    localStorage.setItem('hospitalOS_settings', JSON.stringify({
      background: {
        type: 'color',
        color: '#0078d7',
        image: 'none',
        opacity: 1,
      },
      appearance: {
        theme: 'light',
        accentColor: '#0078d7',
        transparency: true,
      },
      desktop: {
        showIcons: true,
        iconSize: 'medium',
      },
      startMenu: {
        size: 'medium',
        showRecentApps: true,
      }
    }));
    
    // Mark setup as completed
    setIsInstallingFiles(false);
    setIsSetupComplete(true);
    
    // Save first-time user status to localStorage
    localStorage.setItem('isFirstTimeUser', 'false');
    
    // Trigger callback to parent
    onSetupComplete();
  };
  
  // Mock installation process
  const startInstallation = () => {
    setIsInstallingFiles(true);
    setInstallStage(1);
    setInstallProgress(0);
    setCurrentInstallItem('Initializing installation...');
    
    // Extended installation times (2-4 minutes per stage)
    const installationItems = [
      { name: 'Downloading core system files...', delay: 120000 }, // 2 minutes
      { name: 'Installing system components...', delay: 180000 }, // 3 minutes
      { name: 'Setting up database connections...', delay: 150000 }, // 2.5 minutes
      { name: 'Configuring user preferences...', delay: 120000 }, // 2 minutes
      { name: 'Installing medical reference data...', delay: 240000 }, // 4 minutes
      { name: 'Configuring department templates...', delay: 150000 }, // 2.5 minutes
      { name: 'Setting up security protocols...', delay: 180000 }, // 3 minutes
      { name: 'Optimizing system performance...', delay: 120000 }, // 2 minutes
      { name: 'Finalizing installation...', delay: 120000 } // 2 minutes
    ];
    
    // For development/testing convenience, we'll divide the delay by 60 to make the installation faster
    // Remove this in production to use the actual longer delays
    const devFactor = 60;
    const adjustedItems = installationItems.map(item => ({ 
      ...item, 
      delay: Math.floor(item.delay / devFactor)
    }));
    
    let currentIndex = 0;
    let totalDelay = adjustedItems.reduce((sum, item) => sum + item.delay, 0);
    let elapsedTime = 0;
    
    // Update progress more frequently than waiting for each task to complete
    const progressUpdateInterval = 500; // Update progress every 500ms
    let progressTimer: ReturnType<typeof setInterval>;
    
    const processNextItem = () => {
      if (currentIndex < adjustedItems.length) {
        const item = adjustedItems[currentIndex];
        
        setCurrentInstallItem(item.name);
        
        // Clear any existing progress timer
        if (progressTimer) clearInterval(progressTimer);
        
        // Start time for current task
        const startTime = Date.now();
        const taskDuration = item.delay;
        
        // Update progress at intervals
        progressTimer = setInterval(() => {
          const elapsed = Date.now() - startTime;
          const taskProgress = Math.min(1, elapsed / taskDuration);
          
          // Calculate overall progress
          const prevTasksTime = elapsedTime;
          const currentTaskContribution = taskProgress * taskDuration;
          const newElapsedTime = prevTasksTime + currentTaskContribution;
          const newProgress = Math.min(99, Math.floor((newElapsedTime / totalDelay) * 100));
          
          setInstallProgress(newProgress);
          
          // Change installation stage at 33% and 66%
          if (newProgress >= 33 && newProgress < 66 && installStage === 1) {
            setInstallStage(2);
          } else if (newProgress >= 66 && installStage === 2) {
            setInstallStage(3);
          }
          
          // If task is complete, move to next task
          if (elapsed >= taskDuration) {
            clearInterval(progressTimer);
            currentIndex++;
            elapsedTime += taskDuration;
            processNextItem();
          }
        }, progressUpdateInterval);
      } else {
        // Installation complete
        setInstallProgress(100);
        setTimeout(() => {
          completeSetup();
        }, 1500);
      }
    };
    
    processNextItem();
  };
  
  // Function to handle setup step navigation
  const handleNextStep = () => {
    const nextStep = setupStep + 1;
    
    // Total number of setup steps
    const totalSteps = 10;
    
    // Update progress bar based on current step
    const newProgress = Math.min(100, Math.floor((nextStep / totalSteps) * 100));
    setSetupProgress(newProgress);
    
    // Handle step-specific logic
    if (nextStep === 10) {
      // Last step, ready to start installation
      setSetupStep(nextStep);
    } else if (nextStep > 10) {
      // Start installation process
      startInstallation();
    } else {
      // Move to next step
      setSetupStep(nextStep);
    }
  };
  
  const handlePreviousStep = () => {
    if (setupStep > 1) {
      const prevStep = setupStep - 1;
      setSetupStep(prevStep);
      
      // Update progress bar
      const newProgress = Math.floor((prevStep / 10) * 100);
      setSetupProgress(newProgress);
    }
  };
  
  // Check if current step is valid to proceed
  const isStepValid = () => {
    switch (setupStep) {
      case 2: // User Profile
        return userName.trim() !== '';
      case 3: // Department
        return userDepartment !== '';
      case 4: // Role & Access
        return userRole !== '';
      case 7: // Security Questions
        return securityQuestions.question1 !== '' && 
               securityQuestions.answer1 !== '' && 
               securityQuestions.question2 !== '' && 
               securityQuestions.answer2 !== '';
      case 9: // License Agreement
        return licenseAgreementAccepted;
      default:
        return true;
    }
  };
  
  // Main render method
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 p-4">
      <Card className="w-full max-w-3xl">
        <CardHeader className="bg-gradient-to-r from-blue-700 to-blue-900 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">
                {setupStep === 1 && "Welcome to Hospital OS"}
                {setupStep === 2 && "User Profile Setup"}
                {setupStep === 3 && "Department Information"}
                {setupStep === 4 && "Access Level Configuration"}
                {setupStep === 5 && "System Configuration"}
                {setupStep === 6 && "File System Setup"}
                {setupStep === 7 && "Security Configuration"}
                {setupStep === 8 && "Network Settings"}
                {setupStep === 9 && "License Agreement"}
                {setupStep === 10 && "Setup Summary"}
                {isInstallingFiles && (
                  installStage === 1 ? "Installing System Files" :
                  installStage === 2 ? "Configuring System" :
                  "Optimizing Performance"
                )}
              </CardTitle>
              <CardDescription className="text-blue-100">
                {setupStep === 1 && "Welcome to the Hospital OS setup wizard. This comprehensive process will guide you through the initial system configuration."}
                {setupStep === 2 && "Please enter your personal information to customize your Hospital OS experience."}
                {setupStep === 3 && "Select your department to receive specialized templates and configurations."}
                {setupStep === 4 && "Set your system access level and permissions."}
                {setupStep === 5 && "Configure your system preferences. You can change these settings later in the Settings app."}
                {setupStep === 6 && "Choose which file types and templates to include in your system."}
                {setupStep === 7 && "Set up your security questions for account recovery."}
                {setupStep === 8 && "Configure your network settings or use the recommended defaults."}
                {setupStep === 9 && "Please review and accept the license agreement to continue."}
                {setupStep === 10 && "Review your configuration before installation begins."}
                {isInstallingFiles && "Please wait while we set up your system. This may take several minutes."}
              </CardDescription>
            </div>
            <div className="text-3xl">
              {setupStep === 1 && <LayoutDashboard />}
              {setupStep === 2 && <User />}
              {setupStep === 3 && <Building />}
              {setupStep === 4 && <KeyRound />}
              {setupStep === 5 && <Settings />}
              {setupStep === 6 && <FileText />}
              {setupStep === 7 && <Shield />}
              {setupStep === 8 && <Network />}
              {setupStep === 9 && <FileJson />}
              {setupStep === 10 && <Laptop />}
              {isInstallingFiles && <Cog className="animate-spin" />}
            </div>
          </div>
        </CardHeader>
        
        <Progress value={isInstallingFiles ? installProgress : setupProgress} className="rounded-none" />
        
        <CardContent className="p-6 max-h-[60vh] overflow-y-auto">
          {/* Step 1: Welcome */}
          {setupStep === 1 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Welcome to the Hospital Operating System!</h3>
              <p>
                Thank you for choosing Hospital OS, the comprehensive hospital management system designed to streamline workflows and improve patient care.
              </p>
              <p>
                This setup wizard will guide you through the initial configuration process. Please follow the steps to customize your experience based on your role and department.
              </p>
              <div className="bg-blue-50 p-4 rounded-md">
                <h4 className="font-medium mb-2">Setup includes:</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Personal profile configuration</li>
                  <li>Department and role settings</li>
                  <li>System appearance and behavior preferences</li>
                  <li>Security configurations</li>
                  <li>File system and template setup</li>
                </ul>
              </div>
              <p className="text-sm text-muted-foreground">
                This process will take approximately 5-10 minutes to complete.
              </p>
            </div>
          )}
          
          {/* Step 2: User Profile */}
          {setupStep === 2 && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="user-name">Your Name</Label>
                <Input 
                  id="user-name" 
                  placeholder="Enter your full name" 
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                />
                {userName.trim() === '' && (
                  <p className="text-sm text-red-500">Name is required</p>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Profile Image</Label>
                  <div className="flex justify-center">
                    <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 border">
                      {userName ? userName.charAt(0).toUpperCase() : 'U'}
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Personalization</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="show-welcome" defaultChecked />
                      <Label htmlFor="show-welcome">Show welcome screen on startup</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="enable-tips" defaultChecked />
                      <Label htmlFor="enable-tips">Enable helpful tips and tutorials</Label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 3: Department Selection */}
          {setupStep === 3 && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <Select
                  value={userDepartment}
                  onValueChange={setUserDepartment}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Emergency">Emergency</SelectItem>
                    <SelectItem value="Surgery">Surgery</SelectItem>
                    <SelectItem value="Pediatrics">Pediatrics</SelectItem>
                    <SelectItem value="Cardiology">Cardiology</SelectItem>
                    <SelectItem value="Neurology">Neurology</SelectItem>
                    <SelectItem value="Oncology">Oncology</SelectItem>
                    <SelectItem value="Radiology">Radiology</SelectItem>
                    <SelectItem value="Laboratory">Laboratory</SelectItem>
                    <SelectItem value="Pharmacy">Pharmacy</SelectItem>
                    <SelectItem value="Administration">Administration</SelectItem>
                    <SelectItem value="IT">IT Department</SelectItem>
                  </SelectContent>
                </Select>
                {userDepartment === '' && (
                  <p className="text-sm text-red-500">Department selection is required</p>
                )}
              </div>
              
              <div className="p-4 bg-blue-50 rounded-md">
                <h4 className="font-medium mb-2">Department-specific features:</h4>
                <p className="text-sm">
                  Your department selection will customize templates, workflows, and available tools to match your specific needs. This can be changed later in the settings.
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="dept-preferences">Department Preferences</Label>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="dept-templates" 
                      checked={setupOptions.installDepartmentTemplates}
                      onCheckedChange={(checked) => handleOptionChange('installDepartmentTemplates', checked as boolean)}
                    />
                    <Label htmlFor="dept-templates">Install department-specific templates</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="dept-reports" 
                      checked={setupOptions.setupAdvancedReporting}
                      onCheckedChange={(checked) => handleOptionChange('setupAdvancedReporting', checked as boolean)}
                    />
                    <Label htmlFor="dept-reports">Set up specialized reporting tools</Label>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 4: Role & Access Level */}
          {setupStep === 4 && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Select
                  value={userRole}
                  onValueChange={setUserRole}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Physician">Physician</SelectItem>
                    <SelectItem value="Nurse">Nurse</SelectItem>
                    <SelectItem value="Administrator">Administrator</SelectItem>
                    <SelectItem value="Technician">Technician</SelectItem>
                    <SelectItem value="Pharmacist">Pharmacist</SelectItem>
                    <SelectItem value="Lab Technician">Lab Technician</SelectItem>
                    <SelectItem value="Receptionist">Receptionist</SelectItem>
                    <SelectItem value="IT Support">IT Support</SelectItem>
                    <SelectItem value="Department Head">Department Head</SelectItem>
                  </SelectContent>
                </Select>
                {userRole === '' && (
                  <p className="text-sm text-red-500">Role selection is required</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="access-level">Access Level</Label>
                <Select
                  value={userAccessLevel}
                  onValueChange={setUserAccessLevel}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select access level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Basic">Basic - Limited access</SelectItem>
                    <SelectItem value="Standard">Standard - Department access</SelectItem>
                    <SelectItem value="Advanced">Advanced - Cross-department access</SelectItem>
                    <SelectItem value="Administrator">Administrator - Full system access</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="p-4 bg-blue-50 rounded-md">
                <h4 className="font-medium mb-2">Access Level Information:</h4>
                <ul className="text-sm space-y-1">
                  <li><span className="font-medium">Basic:</span> View-only access to limited data within your department.</li>
                  <li><span className="font-medium">Standard:</span> Full access to department data, limited ability to modify records.</li>
                  <li><span className="font-medium">Advanced:</span> Extended access across multiple departments with record modification privileges.</li>
                  <li><span className="font-medium">Administrator:</span> Complete system access including configuration settings and user management.</li>
                </ul>
              </div>
            </div>
          )}
          
          {/* Step 5: System Configuration */}
          {setupStep === 5 && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>System Features</Label>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="auto-backup">Automatic Backup</Label>
                    <Switch 
                      id="auto-backup" 
                      checked={setupOptions.enableAutoBackup}
                      onCheckedChange={(checked) => handleOptionChange('enableAutoBackup', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="auto-updates">Automatic Updates</Label>
                    <Switch 
                      id="auto-updates" 
                      checked={setupOptions.setupAutomaticUpdates}
                      onCheckedChange={(checked) => handleOptionChange('setupAutomaticUpdates', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="advanced-features">Advanced Features</Label>
                    <Switch 
                      id="advanced-features" 
                      checked={setupOptions.installExtraUtilities}
                      onCheckedChange={(checked) => handleOptionChange('installExtraUtilities', checked)}
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Appearance</Label>
                <Tabs defaultValue="light">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="light">Light Mode</TabsTrigger>
                    <TabsTrigger value="dark">Dark Mode</TabsTrigger>
                  </TabsList>
                  <TabsContent value="light" className="p-4 bg-gray-100 rounded-md mt-2">
                    <div className="h-24 bg-white rounded border border-gray-300 flex items-center justify-center">
                      <div className="text-black">Light Mode Preview</div>
                    </div>
                  </TabsContent>
                  <TabsContent value="dark" className="p-4 bg-gray-800 rounded-md mt-2">
                    <div className="h-24 bg-gray-900 rounded border border-gray-700 flex items-center justify-center">
                      <div className="text-white">Dark Mode Preview</div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
              
              <div className="space-y-2">
                <Label>System Performance</Label>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <Label htmlFor="animation-level" className="text-sm">Animation Level</Label>
                      <span className="text-sm text-muted-foreground">Balanced</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs">Low</span>
                      <div className="w-full">
                        <input 
                          type="range" 
                          min="1" 
                          max="5" 
                          defaultValue="3"
                          className="w-full" 
                        />
                      </div>
                      <span className="text-xs">High</span>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <Label htmlFor="startup-items" className="text-sm">Startup Items</Label>
                      <span className="text-sm text-muted-foreground">Essential</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs">Minimal</span>
                      <div className="w-full">
                        <input 
                          type="range" 
                          min="1" 
                          max="5" 
                          defaultValue="2"
                          className="w-full" 
                        />
                      </div>
                      <span className="text-xs">All</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 6: File System Setup */}
          {setupStep === 6 && (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-md">
                <h4 className="font-medium mb-2">File System Configuration</h4>
                <p className="text-sm">
                  Select which folders and templates you would like to include in your system.
                </p>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox id="templates-folder" defaultChecked />
                  <div className="flex items-center space-x-2">
                    <FolderPlus className="w-4 h-4 text-blue-600" />
                    <Label htmlFor="templates-folder">Department Templates</Label>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox id="documents-folder" defaultChecked />
                  <div className="flex items-center space-x-2">
                    <FileText className="w-4 h-4 text-blue-600" />
                    <Label htmlFor="documents-folder">Documentation & User Guides</Label>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox id="backup-folder" defaultChecked />
                  <div className="flex items-center space-x-2">
                    <HardDrive className="w-4 h-4 text-blue-600" />
                    <Label htmlFor="backup-folder">Backup & Recovery Tools</Label>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox id="sample-data" defaultChecked />
                  <div className="flex items-center space-x-2">
                    <Server className="w-4 h-4 text-blue-600" />
                    <Label htmlFor="sample-data">Sample Data (Training)</Label>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox id="utilities" defaultChecked />
                  <div className="flex items-center space-x-2">
                    <Settings className="w-4 h-4 text-blue-600" />
                    <Label htmlFor="utilities">System Utilities</Label>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <Label className="mb-2 block">Default File Locations</Label>
                <div className="space-y-2 text-sm">
                  <div className="grid grid-cols-5 gap-2">
                    <div className="col-span-2 font-medium">Patient Records</div>
                    <div className="col-span-3 text-muted-foreground">/Data/Patients</div>
                  </div>
                  <div className="grid grid-cols-5 gap-2">
                    <div className="col-span-2 font-medium">Exported Reports</div>
                    <div className="col-span-3 text-muted-foreground">/Data/Exports</div>
                  </div>
                  <div className="grid grid-cols-5 gap-2">
                    <div className="col-span-2 font-medium">System Backups</div>
                    <div className="col-span-3 text-muted-foreground">/System/Backups</div>
                  </div>
                  <div className="grid grid-cols-5 gap-2">
                    <div className="col-span-2 font-medium">User Documents</div>
                    <div className="col-span-3 text-muted-foreground">/Documents</div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 7: Security Configuration */}
          {setupStep === 7 && (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-md mb-4">
                <h4 className="font-medium mb-2">Security Setup</h4>
                <p className="text-sm">
                  Set up security questions for account recovery. These will be used to verify your identity if you need to reset your password.
                </p>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="security-q1">Security Question 1</Label>
                  <Select 
                    value={securityQuestions.question1}
                    onValueChange={(value) => handleSecurityQuestionChange('question1', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a security question" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="What was your first pet's name?">What was your first pet's name?</SelectItem>
                      <SelectItem value="In what city were you born?">In what city were you born?</SelectItem>
                      <SelectItem value="What was the name of your first school?">What was the name of your first school?</SelectItem>
                      <SelectItem value="What is your mother's maiden name?">What is your mother's maiden name?</SelectItem>
                      <SelectItem value="What was your childhood nickname?">What was your childhood nickname?</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Input 
                    placeholder="Answer" 
                    value={securityQuestions.answer1}
                    onChange={(e) => handleSecurityQuestionChange('answer1', e.target.value)}
                    className="mt-2" 
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="security-q2">Security Question 2</Label>
                  <Select 
                    value={securityQuestions.question2}
                    onValueChange={(value) => handleSecurityQuestionChange('question2', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a security question" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="What is the name of your favorite childhood teacher?">What is the name of your favorite childhood teacher?</SelectItem>
                      <SelectItem value="What was the make of your first car?">What was the make of your first car?</SelectItem>
                      <SelectItem value="What is your favorite movie?">What is your favorite movie?</SelectItem>
                      <SelectItem value="What is the name of the street you grew up on?">What is the name of the street you grew up on?</SelectItem>
                      <SelectItem value="What is your favorite book?">What is your favorite book?</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Input 
                    placeholder="Answer" 
                    value={securityQuestions.answer2}
                    onChange={(e) => handleSecurityQuestionChange('answer2', e.target.value)}
                    className="mt-2" 
                  />
                </div>
              </div>
              
              <div className="mt-4 space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="enable-encryption" 
                    checked={setupOptions.setupDataEncryption}
                    onCheckedChange={(checked) => handleOptionChange('setupDataEncryption', checked as boolean)}
                  />
                  <Label htmlFor="enable-encryption">Enable data encryption</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox id="enable-audit" defaultChecked />
                  <Label htmlFor="enable-audit">Enable audit logging</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="enable-notifications" 
                    checked={setupOptions.enableNotifications}
                    onCheckedChange={(checked) => handleOptionChange('enableNotifications', checked as boolean)}
                  />
                  <Label htmlFor="enable-notifications">Enable security notifications</Label>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 8: Network Settings */}
          {setupStep === 8 && (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-md mb-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Wifi className="text-blue-600" />
                  <h4 className="font-medium">Network Configuration</h4>
                </div>
                <p className="text-sm">
                  Configure how your system connects to the hospital network. Most users can use the default settings.
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Connection Type</Label>
                  <Select defaultValue="automatic">
                    <SelectTrigger>
                      <SelectValue placeholder="Select connection type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="automatic">Automatic (Recommended)</SelectItem>
                      <SelectItem value="wired">Wired Ethernet</SelectItem>
                      <SelectItem value="wireless">Wireless</SelectItem>
                      <SelectItem value="vpn">VPN</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Proxy Settings</Label>
                  <Select defaultValue="none">
                    <SelectTrigger>
                      <SelectValue placeholder="Select proxy configuration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Proxy</SelectItem>
                      <SelectItem value="auto">Auto-detect</SelectItem>
                      <SelectItem value="manual">Manual Configuration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="mt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="enable-network-sharing">Enable Network Sharing</Label>
                  <Switch 
                    id="enable-network-sharing" 
                    checked={setupOptions.enableNetworkSharing}
                    onCheckedChange={(checked) => handleOptionChange('enableNetworkSharing', checked)}
                  />
                </div>
              </div>
              
              <div className="mt-4 bg-gray-100 p-4 rounded-md">
                <div className="flex items-center mb-2">
                  <Monitor className="mr-2 h-4 w-4" />
                  <h4 className="font-medium">Network Status</h4>
                </div>
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span>Status:</span>
                    <span className="text-green-600 font-medium">Connected</span>
                  </div>
                  <div className="flex justify-between">
                    <span>IP Address:</span>
                    <span>192.168.1.100</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Network:</span>
                    <span>Hospital Main Network</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Signal Strength:</span>
                    <span>Excellent</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Step 9: License Agreement */}
          {setupStep === 9 && (
            <div className="space-y-4">
              <div className="p-4 bg-gray-100 rounded border text-sm h-64 overflow-y-auto">
                <h3 className="font-bold mb-2">Hospital OS License Agreement</h3>
                <p className="mb-2">
                  This Hospital Operating System ("Hospital OS") is licensed, not sold, to you by Medical Systems Inc. for use strictly in accordance with the terms and conditions of this License Agreement.
                </p>
                <h4 className="font-bold mt-3 mb-1">1. License Grant</h4>
                <p className="mb-2">
                  Medical Systems Inc. grants you a revocable, non-exclusive, non-transferable, limited license to download, install and use the Hospital OS solely for your internal hospital operations.
                </p>
                <h4 className="font-bold mt-3 mb-1">2. Restrictions</h4>
                <p className="mb-2">
                  You agree not to, and you will not permit others to:
                </p>
                <ul className="list-disc pl-5 mb-2 space-y-1">
                  <li>License, sell, rent, lease, assign, distribute, transmit, host, outsource, disclose or otherwise commercially exploit the Hospital OS.</li>
                  <li>Modify, make derivative works of, disassemble, decrypt, reverse compile or reverse engineer any part of the Hospital OS.</li>
                  <li>Remove, alter or obscure any proprietary notice of Medical Systems Inc. or its affiliates.</li>
                </ul>
                <h4 className="font-bold mt-3 mb-1">3. Patient Data and Privacy</h4>
                <p className="mb-2">
                  All patient data processed through Hospital OS remains the sole property of your institution. You are responsible for compliance with all applicable privacy laws and regulations regarding the use, collection, and processing of patient data.
                </p>
                <h4 className="font-bold mt-3 mb-1">4. Updates and Maintenance</h4>
                <p className="mb-2">
                  Medical Systems Inc. may from time to time in its sole discretion develop and provide Hospital OS updates, which may include upgrades, bug fixes, patches, and other error corrections.
                </p>
                <h4 className="font-bold mt-3 mb-1">5. Term and Termination</h4>
                <p className="mb-2">
                  This License Agreement is effective until terminated by you or Medical Systems Inc. Your rights under this License will terminate automatically without notice if you fail to comply with any of its terms and conditions.
                </p>
                <h4 className="font-bold mt-3 mb-1">6. Disclaimer of Warranty</h4>
                <p className="mb-2">
                  THE HOSPITAL OS IS PROVIDED "AS IS" AND "AS AVAILABLE," WITH ALL FAULTS AND WITHOUT WARRANTY OF ANY KIND.
                </p>
                <h4 className="font-bold mt-3 mb-1">7. Limitation of Liability</h4>
                <p className="mb-2">
                  TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL MEDICAL SYSTEMS INC. BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER.
                </p>
                <p className="mt-4">
                  By proceeding with the installation of Hospital OS, you acknowledge that you have read this License Agreement, understand it, and agree to be bound by its terms and conditions.
                </p>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="accept-license" 
                  checked={licenseAgreementAccepted}
                  onCheckedChange={(checked) => setLicenseAgreementAccepted(checked as boolean)}
                />
                <Label htmlFor="accept-license">
                  I accept the Hospital OS License Agreement
                </Label>
              </div>
              {setupStep === 9 && !licenseAgreementAccepted && (
                <p className="text-sm text-red-500">You must accept the License Agreement to proceed</p>
              )}
            </div>
          )}
          
          {/* Step 10: Setup Summary */}
          {setupStep === 10 && (
            <div className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-md flex items-start space-x-3">
                <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h3 className="font-medium text-green-800">Ready to Install</h3>
                  <p className="text-sm text-green-700">
                    Hospital OS is ready to be installed with your custom configuration. Review the settings below and click "Install" to begin.
                  </p>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="border rounded-md overflow-hidden">
                  <div className="bg-gray-100 px-4 py-2 font-medium">User Information</div>
                  <div className="p-4 space-y-2 text-sm">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Name:</div>
                      <div>{userName || 'Not specified'}</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Department:</div>
                      <div>{userDepartment || 'Not specified'}</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Role:</div>
                      <div>{userRole || 'Not specified'}</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Access Level:</div>
                      <div>{userAccessLevel}</div>
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-md overflow-hidden">
                  <div className="bg-gray-100 px-4 py-2 font-medium">System Configuration</div>
                  <div className="p-4 space-y-2 text-sm">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Automatic Backup:</div>
                      <div>{setupOptions.enableAutoBackup ? 'Enabled' : 'Disabled'}</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Automatic Updates:</div>
                      <div>{setupOptions.setupAutomaticUpdates ? 'Enabled' : 'Disabled'}</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Data Encryption:</div>
                      <div>{setupOptions.setupDataEncryption ? 'Enabled' : 'Disabled'}</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Department Templates:</div>
                      <div>{setupOptions.installDepartmentTemplates ? 'Included' : 'Excluded'}</div>
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-md overflow-hidden">
                  <div className="bg-gray-100 px-4 py-2 font-medium">Installation Details</div>
                  <div className="p-4 space-y-2 text-sm">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Estimated Time:</div>
                      <div>15-20 minutes</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">Disk Space Required:</div>
                      <div>~2.5 GB</div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-muted-foreground">System Restart:</div>
                      <div>Not Required</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Installation Progress */}
          {isInstallingFiles && (
            <div className="space-y-4">
              <div className="p-4 border rounded-md bg-blue-50">
                <h3 className="font-medium text-blue-800 mb-2">Installation in Progress</h3>
                <p className="text-sm text-blue-700 mb-4">
                  Please wait while Hospital OS is being installed. This may take several minutes. Do not close this window or turn off your device.
                </p>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">{currentInstallItem}</span>
                      <span className="text-sm">{installProgress}%</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className={installStage >= 1 ? "text-blue-700" : "text-gray-400"}>
                        <CheckCircle2 className="h-4 w-4" />
                      </div>
                      <span className={installStage >= 1 ? "text-blue-700" : "text-gray-400"}>
                        Installing Core Components
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={installStage >= 2 ? "text-blue-700" : "text-gray-400"}>
                        <CheckCircle2 className="h-4 w-4" />
                      </div>
                      <span className={installStage >= 2 ? "text-blue-700" : "text-gray-400"}>
                        Configuring System
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={installStage >= 3 ? "text-blue-700" : "text-gray-400"}>
                        <CheckCircle2 className="h-4 w-4" />
                      </div>
                      <span className={installStage >= 3 ? "text-blue-700" : "text-gray-400"}>
                        Optimizing Performance
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="text-center text-sm text-gray-500 animate-pulse">
                {installProgress < 30 && "Preparing system files..."}
                {installProgress >= 30 && installProgress < 60 && "Installing components..."}
                {installProgress >= 60 && installProgress < 90 && "Configuring settings..."}
                {installProgress >= 90 && "Finalizing installation..."}
              </div>
            </div>
          )}
        </CardContent>
        
        {/* Footer with buttons */}
        <CardFooter className="flex justify-between border-t p-6">
          {!isInstallingFiles ? (
            <>
              <Button 
                variant="outline" 
                onClick={handlePreviousStep}
                disabled={setupStep === 1}
              >
                Back
              </Button>
              
              <Button 
                onClick={handleNextStep}
                disabled={!isStepValid()}
              >
                {setupStep < 10 ? "Next" : "Install"}
              </Button>
            </>
          ) : (
            <div className="w-full text-center text-sm text-muted-foreground">
              This process may take several minutes. Please do not close this window.
            </div>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}
