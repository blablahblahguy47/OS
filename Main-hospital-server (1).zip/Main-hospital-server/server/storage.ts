import {
  users, type User, type InsertUser,
  patients, type Patient, type InsertPatient,
  appointments, type Appointment, type InsertAppointment,
  inventory, type Inventory, type InsertInventory,
  departments, type Department, type InsertDepartment,
  notifications, type Notification, type InsertNotification
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;

  // Patients
  getPatient(id: number): Promise<Patient | undefined>;
  getPatientByPatientId(patientId: string): Promise<Patient | undefined>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  getPatients(): Promise<Patient[]>;
  updatePatient(id: number, patient: Partial<InsertPatient>): Promise<Patient | undefined>;
  deletePatient(id: number): Promise<boolean>;

  // Appointments
  getAppointment(id: number): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  getAppointments(): Promise<Appointment[]>;
  getAppointmentsByPatient(patientId: number): Promise<Appointment[]>;
  getAppointmentsByDoctor(doctorId: number): Promise<Appointment[]>;
  getAppointmentsByDate(date: Date): Promise<Appointment[]>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: number): Promise<boolean>;

  // Inventory
  getInventoryItem(id: number): Promise<Inventory | undefined>;
  createInventoryItem(item: InsertInventory): Promise<Inventory>;
  getInventory(): Promise<Inventory[]>;
  updateInventoryItem(id: number, item: Partial<InsertInventory>): Promise<Inventory | undefined>;
  deleteInventoryItem(id: number): Promise<boolean>;

  // Departments
  getDepartment(id: number): Promise<Department | undefined>;
  getDepartmentByName(name: string): Promise<Department | undefined>;
  createDepartment(department: InsertDepartment): Promise<Department>;
  getDepartments(): Promise<Department[]>;
  updateDepartment(id: number, department: Partial<InsertDepartment>): Promise<Department | undefined>;
  deleteDepartment(id: number): Promise<boolean>;

  // Notifications
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotifications(): Promise<Notification[]>;
  getNotificationsByUser(userId: number): Promise<Notification[]>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
  deleteNotification(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private patients: Map<number, Patient>;
  private appointments: Map<number, Appointment>;
  private inventoryItems: Map<number, Inventory>;
  private departmentItems: Map<number, Department>;
  private notificationItems: Map<number, Notification>;

  private userId: number;
  private patientId: number;
  private appointmentId: number;
  private inventoryId: number;
  private departmentId: number;
  private notificationId: number;

  constructor() {
    this.users = new Map();
    this.patients = new Map();
    this.appointments = new Map();
    this.inventoryItems = new Map();
    this.departmentItems = new Map();
    this.notificationItems = new Map();

    this.userId = 1;
    this.patientId = 1;
    this.appointmentId = 1;
    this.inventoryId = 1;
    this.departmentId = 1;
    this.notificationId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Add a demo admin user
    this.createUser({
      username: "admin",
      password: "password",
      name: "Admin User",
      role: "admin",
      department: "Administration",
      specialty: "",
      contact: "555-1000",
      email: "admin@hospital.com",
      status: "active"
    });

    // Add a demo doctor user
    this.createUser({
      username: "drthompson",
      password: "password",
      name: "Dr. Thompson",
      role: "doctor",
      department: "General Medicine",
      specialty: "Internal Medicine",
      contact: "555-1001",
      email: "thompson@hospital.com",
      status: "active"
    });

    // Create departments
    const departments = [
      { name: "Emergency Room", capacity: 20, currentLoad: 18, numDoctors: 5, numNurses: 12, status: "high load" },
      { name: "ICU", capacity: 15, currentLoad: 12, numDoctors: 4, numNurses: 10, status: "moderate" },
      { name: "General Medicine", capacity: 60, currentLoad: 42, numDoctors: 8, numNurses: 16, status: "normal" },
      { name: "Pediatrics", capacity: 45, currentLoad: 28, numDoctors: 6, numNurses: 14, status: "normal" },
      { name: "Cardiology", capacity: 30, currentLoad: 22, numDoctors: 5, numNurses: 8, status: "normal" },
      { name: "Neurology", capacity: 25, currentLoad: 15, numDoctors: 4, numNurses: 6, status: "normal" }
    ];

    departments.forEach(dept => {
      this.createDepartment(dept);
    });

    // Create some sample patients
    const patients = [
      { patientId: "P-10234", firstName: "Lisa", lastName: "Turner", dateOfBirth: new Date("1985-05-12"), gender: "Female", contact: "555-1234", status: "critical", admissionDate: new Date("2023-10-22"), roomNumber: "302" },
      { patientId: "P-10235", firstName: "David", lastName: "Chen", dateOfBirth: new Date("1978-11-03"), gender: "Male", contact: "555-2345", status: "stable", admissionDate: new Date("2023-10-23"), roomNumber: "201" },
      { patientId: "P-10236", firstName: "Anna", lastName: "Patel", dateOfBirth: new Date("1992-02-20"), gender: "Female", contact: "555-3456", status: "observation", admissionDate: new Date("2023-10-23"), roomNumber: "105" },
      { patientId: "P-10237", firstName: "James", lastName: "Anderson", dateOfBirth: new Date("1965-09-15"), gender: "Male", contact: "555-4567", status: "stable", admissionDate: new Date("2023-10-24"), roomNumber: "405" },
      { patientId: "P-10238", firstName: "Maria", lastName: "Lopez", dateOfBirth: new Date("1980-07-30"), gender: "Female", contact: "555-5678", status: "treatment", admissionDate: new Date("2023-10-24"), roomNumber: "210" }
    ];

    patients.forEach(patient => {
      this.createPatient(patient as InsertPatient);
    });

    // Create some sample inventory items
    const inventoryItems = [
      { itemName: "Amoxicillin", category: "medication", quantity: 15, unit: "bottles", reorderLevel: 20, supplier: "PharmaCorp", location: "Pharmacy Storage A" },
      { itemName: "Surgical Masks", category: "supplies", quantity: 5000, unit: "pieces", reorderLevel: 1000, supplier: "MedSupplies Inc", location: "General Storage B" },
      { itemName: "Ventilator", category: "equipment", quantity: 12, unit: "units", reorderLevel: 5, supplier: "MedTech Solutions", location: "ICU Storage" },
      { itemName: "Insulin", category: "medication", quantity: 200, unit: "vials", reorderLevel: 50, supplier: "PharmaCorp", location: "Pharmacy Storage B" },
      { itemName: "Saline Solution", category: "supplies", quantity: 320, unit: "bags", reorderLevel: 100, supplier: "MedSupplies Inc", location: "ER Storage" }
    ];

    inventoryItems.forEach(item => {
      this.createInventoryItem(item as InsertInventory);
    });

    // Create sample appointments
    const today = new Date();
    const appointments = [
      { patientId: 1, doctorId: 2, appointmentDate: today, appointmentTime: { hours: 9, minutes: 0 }, department: "Cardiology", status: "confirmed", reasonForVisit: "Chest pain follow-up" },
      { patientId: 2, doctorId: 2, appointmentDate: today, appointmentTime: { hours: 10, minutes: 15 }, department: "Neurology", status: "waiting", reasonForVisit: "Headache assessment" },
      { patientId: 3, doctorId: 2, appointmentDate: today, appointmentTime: { hours: 11, minutes: 30 }, department: "Orthopedics", status: "in progress", reasonForVisit: "Knee pain" },
      { patientId: 4, doctorId: 2, appointmentDate: today, appointmentTime: { hours: 13, minutes: 45 }, department: "Dermatology", status: "confirmed", reasonForVisit: "Skin rash" },
      { patientId: 5, doctorId: 2, appointmentDate: today, appointmentTime: { hours: 15, minutes: 0 }, department: "General Medicine", status: "cancelled", reasonForVisit: "Annual check-up" }
    ];

    appointments.forEach(appointment => {
      this.createAppointment(appointment as unknown as InsertAppointment);
    });

    // Create sample notifications
    const notifications = [
      { title: "Critical patient alert", message: "Patient Lisa Turner (Room 302) needs immediate attention", type: "alert", userId: 2 },
      { title: "Low medication inventory", message: "Amoxicillin stock below threshold (15 units remaining)", type: "warning", userId: null },
      { title: "Staff meeting reminder", message: "Department meeting at 4:00 PM in Conference Room A", type: "info", userId: 2 },
      { title: "New patient admitted", message: "David Chen has been admitted to General Medicine", type: "success", userId: 2 },
      { title: "Lab results available", message: "Blood test results for Anna Patel ready for review", type: "info", userId: 2 }
    ];

    notifications.forEach(notification => {
      this.createNotification(notification as InsertNotification);
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  // Patients
  async getPatient(id: number): Promise<Patient | undefined> {
    return this.patients.get(id);
  }

  async getPatientByPatientId(patientId: string): Promise<Patient | undefined> {
    return Array.from(this.patients.values()).find(
      (patient) => patient.patientId === patientId,
    );
  }

  async createPatient(patient: InsertPatient): Promise<Patient> {
    const id = this.patientId++;
    const newPatient: Patient = { ...patient, id };
    this.patients.set(id, newPatient);
    return newPatient;
  }

  async getPatients(): Promise<Patient[]> {
    return Array.from(this.patients.values());
  }

  async updatePatient(id: number, patientData: Partial<InsertPatient>): Promise<Patient | undefined> {
    const patient = this.patients.get(id);
    if (!patient) return undefined;

    const updatedPatient = { ...patient, ...patientData };
    this.patients.set(id, updatedPatient);
    return updatedPatient;
  }

  async deletePatient(id: number): Promise<boolean> {
    return this.patients.delete(id);
  }

  // Appointments
  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentId++;
    const newAppointment: Appointment = { ...appointment, id };
    this.appointments.set(id, newAppointment);
    return newAppointment;
  }

  async getAppointments(): Promise<Appointment[]> {
    return Array.from(this.appointments.values());
  }

  async getAppointmentsByPatient(patientId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.patientId === patientId,
    );
  }

  async getAppointmentsByDoctor(doctorId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.doctorId === doctorId,
    );
  }

  async getAppointmentsByDate(date: Date): Promise<Appointment[]> {
    const dateString = date.toISOString().split('T')[0];
    return Array.from(this.appointments.values()).filter(
      (appointment) => {
        const appDateStr = new Date(appointment.appointmentDate).toISOString().split('T')[0];
        return appDateStr === dateString;
      }
    );
  }

  async updateAppointment(id: number, appointmentData: Partial<InsertAppointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (!appointment) return undefined;

    const updatedAppointment = { ...appointment, ...appointmentData };
    this.appointments.set(id, updatedAppointment);
    return updatedAppointment;
  }

  async deleteAppointment(id: number): Promise<boolean> {
    return this.appointments.delete(id);
  }

  // Inventory
  async getInventoryItem(id: number): Promise<Inventory | undefined> {
    return this.inventoryItems.get(id);
  }

  async createInventoryItem(item: InsertInventory): Promise<Inventory> {
    const id = this.inventoryId++;
    const newItem: Inventory = { ...item, id };
    this.inventoryItems.set(id, newItem);
    return newItem;
  }

  async getInventory(): Promise<Inventory[]> {
    return Array.from(this.inventoryItems.values());
  }

  async updateInventoryItem(id: number, itemData: Partial<InsertInventory>): Promise<Inventory | undefined> {
    const item = this.inventoryItems.get(id);
    if (!item) return undefined;

    const updatedItem = { ...item, ...itemData };
    this.inventoryItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    return this.inventoryItems.delete(id);
  }

  // Departments
  async getDepartment(id: number): Promise<Department | undefined> {
    return this.departmentItems.get(id);
  }

  async getDepartmentByName(name: string): Promise<Department | undefined> {
    return Array.from(this.departmentItems.values()).find(
      (dept) => dept.name === name,
    );
  }

  async createDepartment(department: InsertDepartment): Promise<Department> {
    const id = this.departmentId++;
    const newDepartment: Department = { ...department, id };
    this.departmentItems.set(id, newDepartment);
    return newDepartment;
  }

  async getDepartments(): Promise<Department[]> {
    return Array.from(this.departmentItems.values());
  }

  async updateDepartment(id: number, departmentData: Partial<InsertDepartment>): Promise<Department | undefined> {
    const department = this.departmentItems.get(id);
    if (!department) return undefined;

    const updatedDepartment = { ...department, ...departmentData };
    this.departmentItems.set(id, updatedDepartment);
    return updatedDepartment;
  }

  async deleteDepartment(id: number): Promise<boolean> {
    return this.departmentItems.delete(id);
  }

  // Notifications
  async getNotification(id: number): Promise<Notification | undefined> {
    return this.notificationItems.get(id);
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const id = this.notificationId++;
    const newNotification: Notification = { 
      ...notification, 
      id, 
      timestamp: new Date(), 
      isRead: false 
    };
    this.notificationItems.set(id, newNotification);
    return newNotification;
  }

  async getNotifications(): Promise<Notification[]> {
    return Array.from(this.notificationItems.values());
  }

  async getNotificationsByUser(userId: number): Promise<Notification[]> {
    return Array.from(this.notificationItems.values()).filter(
      (notification) => notification.userId === userId || notification.userId === null,
    );
  }

  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notificationItems.get(id);
    if (!notification) return undefined;

    const updatedNotification = { ...notification, isRead: true };
    this.notificationItems.set(id, updatedNotification);
    return updatedNotification;
  }

  async deleteNotification(id: number): Promise<boolean> {
    return this.notificationItems.delete(id);
  }
}

export const storage = new MemStorage();
